# MathWorks OA Coding Questions

Each folder contains `question.md` (the full statement, function signature, constraints, samples and approach) and `solution.cpp` (a C++17 solution with `main()` for custom input). Every solution compiles and passes the samples from its statement.

**Tag legend:** `HackerRank` means the source screenshot shows the HackerRank test page (36 questions). `HackerRank?` means a known HackerRank problem whose source is only notes (3). `LeetCode` means it was shared as a LeetCode link (3). – means the platform isn't shown in the source (16).

**Aptitude MCQs:** [2026/Aptitude_MCQs.md](2026/Aptitude_MCQs.md) has all 35 past math/aptitude MCQs with worked answers, plus the 2026 MCQ topics.

Compile and run: `g++ -O2 -std=c++17 solution.cpp -o sol && ./sol < input.txt`

## 2026
| # | Question | Technique | Tag |
|---|---|---|---|
| 01 | [Get Them All](2026/01_Get_Them_All/question.md) | DP over (index, x, y, z) | `HackerRank` |
| 02 | [Project Pair (non-perfect-square pairs)](2026/02_Project_Pair/question.md) | square-free kernel + greedy | `HackerRank` |
| 03 | [K Largest Subarray XORs](2026/03_Kth_Largest_Subarray_XOR/question.md) | binary trie | – |
| 04 | [Sum of Arrays (max Σ i·(arr2−arr1))](2026/04_Maximize_Weighted_Difference/question.md) | rearrangement inequality | `HackerRank` |
| 05 | [String Left/Right Shift](2026/05_String_Left_Right_Shift/question.md) | modular rotation | `HackerRank?` |
| 06 | [Longest Palindromic Substring](2026/06_Longest_Palindromic_Substring/question.md) | Manacher | – |
| 07 | [Sum of Factors](2026/07_Sum_Of_Factors/question.md) | divisor sieve | – |
| 08 | [Active Data Streams](2026/08_Active_Data_Streams/question.md) | sorting + binary search | – |
| 09 | [Security Grouping (minimum groups)](2026/09_Security_Panels_Group_IDs/question.md) | greedy over group size | `HackerRank` |
| 10 | [First Greater Element Index](2026/10_Next_Greater_Index_In_Second_Array/question.md) | prefix max + binary search | – |
| 11 | [Reduce Piles to Equal Height](2026/11_Reduce_Piles_To_Equal_Height/question.md) | sort + rank | – |
| 12 | [Minimize Sum after K Halvings](2026/12_Minimize_Sum_K_Halving_Operations/question.md) | max-heap | `HackerRank?` |
| 13 | [Maximize Min Difference (size-M subsequence)](2026/13_Maximize_Min_Difference_Subsequence/question.md) | binary search on answer | – |
| 14 | [Rearrange Array to Maximize Prefix Score](2026/14_Rearrange_Array_Max_Prefix_Score/question.md) | sort descending | `LeetCode` |
| 15 | [Maximize Sum of Weights after Edge Removals](2026/15_Max_Sum_Weights_After_Edge_Removals/question.md) | tree DP | `LeetCode` |
| 16 | [Beautiful Towers II](2026/16_Beautiful_Towers_II/question.md) | monotonic stack | `LeetCode` |
| 17 | [Rotate Array (left/right shifts)](2026/17_Array_Left_Right_Rotation/question.md) | modular rotation | – |
| 18 | [Max of Subarray Minimums (Disk Space)](2026/18_Max_Of_Subarray_Minimums/question.md) | sliding-window deque | – |
| 19 | [Tree Walk Through All Task Nodes](2026/19_Tree_Shortest_Path_Through_Task_Nodes/question.md) | Steiner subtree, 2E − dist | – |
| 20 | [Count Subarrays in Sync](2026/20_Subarrays_In_Sync/question.md) | prefix mod + hash map | – |
| 21 | [Watchtowers in Contact (online queries)](2026/21_Watchtowers_In_Contact/question.md) | monotonic stack + persistent segment tree | – |
| 22 | [Van Delivery, Min Fuel](2026/22_Van_Delivery_Min_Fuel/question.md) | Dijkstra over (position, 3^k states) | – |

## 2025
| # | Question | Technique | Tag |
|---|---|---|---|
| 01 | [Cool Graph](2025/01_Cool_Graph/question.md) | max-heap BFS | `HackerRank` |
| 02 | [Ancestral Names (Roman numerals)](2025/02_Ancestral_Names/question.md) | custom sort | `HackerRank` |
| 03 | [Slow and Fast Pointers (dualSpeed)](2025/03_Slow_And_Fast_Pointers/question.md) | simulation | `HackerRank` |
| 04 | [Glide Typing](2025/04_Glide_Typing/question.md) | subsequence check | `HackerRank` |
| 05 | [Divisors and Multiples](2025/05_Divisors_And_Multiples/question.md) | harmonic sieve | `HackerRank` |
| 06 | [Subsequence Sort (checkStrings)](2025/06_Subsequence_Sort/question.md) | prefix-count greedy | `HackerRank` |
| 07 | [Ball Collision](2025/07_Ball_Collision/question.md) | stack | `HackerRank` |
| 08 | [I Want to Be Like Her](2025/08_I_Want_To_Be_Like_Her/question.md) | digit differences | `HackerRank` |
| 09 | [Merge Strings](2025/09_Merge_Strings/question.md) | two pointers | `HackerRank` |
| 10 | [Star Removal](2025/10_Star_Removal/question.md) | 26 stacks | – |
| 11 | [Sub-Palindrome (distinct palindromes)](2025/11_Sub_Palindrome/question.md) | Eertree | `HackerRank` |

## 2024
| # | Question | Technique | Tag |
|---|---|---|---|
| 01 | [Merging Palindromes](2024/01_Merging_Palindromes/question.md) | letter counting | `HackerRank` |
| 02 | [Simple Matrix Summation](2024/02_Simple_Matrix_Summation/question.md) | 2-D prefix sum | `HackerRank` |
| 03 | [Shoplifter: Max K Items](2024/03_Shoplifter_Max_K_Items/question.md) | nth_element | – |
| 04 | [Longest Subsequence with Adjacent XOR = K](2024/04_Longest_Subsequence_Adjacent_XOR_K/question.md) | hash-map DP | `HackerRank` |
| 05 | [Optimal Middle Subsequence](2024/05_Optimal_Middle_Subsequence/question.md) | prefix/suffix minimum | `HackerRank?` |
| 06 | [Min Operations: Binary Array to Zero](2024/06_Min_Operations_Binary_Array_To_Zero/question.md) | count blocks | – |
| 07 | [Balanced Words](2024/07_Balanced_Words/question.md) | DP over letters | `HackerRank` |
| 08 | [Dominoes Painting](2024/08_Dominoes_Painting/question.md) | combinatorics | `HackerRank` |
| 09 | [Minimize Path Value (least stress)](2024/09_Minimize_Path_Value/question.md) | Kruskal / DSU | `HackerRank` |
| 10 | [Palindromic Strings after Swaps](2024/10_Palindromic_Strings_After_Swaps/question.md) | greedy pairs | `HackerRank` |
| 11 | [Parade in HackerLand](2024/11_Parade_In_HackerLand/question.md) | one-pass simulation | `HackerRank` |
| 12 | [Shader Loader (min idleness)](2024/12_Shader_Loader_Min_Idleness/question.md) | binary search | `HackerRank` |
| 13 | [Count Length-3 Subsequence](2024/13_Subsequence_Count_Length3/question.md) | DP | `HackerRank` |

## 2023
| # | Question | Technique | Tag |
|---|---|---|---|
| 01 | [Reduced Fraction Sums](2023/01_Reduced_Fraction_Sums/question.md) | gcd | `HackerRank` |
| 02 | [Tom & Jerry in a Maze](2023/02_Tom_And_Jerry_Maze/question.md) | BFS + bitmask | `HackerRank` |
| 03 | [Team Formation](2023/03_Team_Formation/question.md) | two heaps | `HackerRank` |
| 04 | [Maximum Difference in an Array](2023/04_Maximum_Difference_In_Array/question.md) | prefix minimum | `HackerRank` |
| 05 | [String Chains](2023/05_String_Chains/question.md) | DP sorted by length | `HackerRank` |
| 06 | [Intelligent Substring](2023/06_Intelligent_Substring/question.md) | sliding window | `HackerRank` |
| 07 | [Roll the String](2023/07_Roll_The_String/question.md) | suffix counts | `HackerRank` |
| 08 | [Simple Queries](2023/08_Simple_Queries/question.md) | sort + upper_bound | `HackerRank` |
| 09 | [Ascending Binary Sort](2023/09_Ascending_Binary_Sort/question.md) | popcount sort | `HackerRank` |
| 10 | [Beautiful Arrangement](2023/10_Beautiful_Arrangement/question.md) | bitmask DP | `HackerRank` |
| 11 | [Interesting Pairs of Numbers](2023/11_Interesting_Pairs_Of_Numbers/question.md) | max(\|a\|,\|b\|) identity | `HackerRank` |
| 12 | [Distinct Pairs](2023/12_Distinct_Pairs/question.md) | hash map | `HackerRank` |

*Also asked in 2023:* I Want to Be Like Her (see 2025/08) and Slow & Fast Pointers (see 2025/03).

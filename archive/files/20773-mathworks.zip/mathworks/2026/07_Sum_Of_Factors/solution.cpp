#include <bits/stdc++.h>
using namespace std;

vector<long long> sumOfFactors(vector<int> arr) {
    int mx = *max_element(arr.begin(), arr.end());
    vector<long long> res;
    if (mx <= 1000000) {
        // divisor-sum sieve
        vector<long long> sigma(mx + 1, 0);
        for (int d = 1; d <= mx; ++d)
            for (int m = d; m <= mx; m += d) sigma[m] += d;
        for (int a : arr) res.push_back(sigma[a]);
    } else {
        for (int a : arr) {
            long long s = 0;
            for (long long d = 1; d * d <= a; ++d)
                if (a % d == 0) {
                    s += d;
                    if (d != a / d) s += a / d;
                }
            res.push_back(s);
        }
    }
    return res;
}

int main() {
    int n;
    cin >> n;
    vector<int> arr(n);
    for (auto &v : arr) cin >> v;
    vector<long long> res = sumOfFactors(arr);
    long long total = 0;
    for (long long v : res) cout << v << " ", total += v;
    cout << "\ntotal = " << total << "\n";
    return 0;
}

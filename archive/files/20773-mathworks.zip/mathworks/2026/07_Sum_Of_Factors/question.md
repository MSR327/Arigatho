# Sum of All Factors for Each Number in an Array

**Tag:** `Platform not shown`. The statement was rebuilt from notes or a non-HackerRank screenshot.

**Year:** 2026 · **Source:** `mathworks OA.txt` ("sum of all factors for each number in a array"), `MathWorks OA Problems Reference Guide.pdf` (Problem 2). *The statement is reconstructed.*

## Problem

You are given an array of positive integers `arr` of length `n`. For each element `arr[i]`, compute `σ(arr[i])`, the **sum of all its positive divisors**, including 1 and the number itself.

Return an array `res` where `res[i] = σ(arr[i])`. (Some versions ask for the total `Σ σ(arr[i])` instead; the program prints both.)

## Function Description

```cpp
vector<long long> sumOfFactors(vector<int> arr);
```

**Parameters**
- `int arr[n]`: the numbers

**Returns**
- `long long[n]`: the divisor sum of each element

## Constraints (typical)

- `1 ≤ n ≤ 10^5`
- `1 ≤ arr[i] ≤ 10^6` (a sieve works here). If `arr[i]` can be as large as `10^9`, use trial division up to `√arr[i]`.

## Example

```
arr = [6, 10, 1, 12]
```
- 6 → 1+2+3+6 = 12
- 10 → 1+2+5+10 = 18
- 1 → 1
- 12 → 1+2+3+4+6+12 = 28

```
Output: [12, 18, 1, 28]     total = 59
```

## Input Format (custom testing)

```
n
arr[0] ... arr[n-1]
```

## Approach

- **Small values (max ≤ 10^6):** run a divisor-sum sieve. For each `d` from 1 to `M`, add `d` to `σ[d], σ[2d], σ[3d], …`. Precomputation costs `O(M log M)` and each query is `O(1)`.
- **Large values:** for each `x`, loop `d` from 1 to `√x`. If `d | x`, add `d` and `x/d` (adding only once when `d = x/d`). This costs `O(n√max)`.

The solution chooses between the two automatically based on the maximum value.

# Rearrange Array to Maximize Prefix Score

**Tag:** `LeetCode`. Shared as a LeetCode link: LeetCode 2587.

**Year:** 2026 · **Source:** link list shared in chat (Nov 2026): https://leetcode.com/problems/rearrange-array-to-maximize-prefix-score/

## Problem

You are given a 0-indexed integer array `nums`. You can rearrange its elements into **any order**, including the original order.

Let `prefix` be the array of prefix sums of `nums` after rearranging, so `prefix[i]` is the sum of the elements from index 0 to `i`. The **score** of `nums` is the number of **positive** integers in `prefix`.

Return the **maximum score** you can achieve.

## Function Description

```cpp
int maxScore(vector<int> nums);
```

**Parameters**
- `int nums[n]`: the array

**Returns**
- `int`: the maximum number of positive prefix sums

## Constraints

- `1 ≤ n ≤ 10^5`
- `-10^6 ≤ nums[i] ≤ 10^6`

## Example 1

```
nums = [2, -1, 0, 1, -3, 3, -3]
Output: 6
```
Rearrange to `[2, 3, 1, -1, -3, 0, -3]`. The prefix sums are `[2, 5, 6, 5, 2, 2, -1]`, so the score is 6. No arrangement gets a higher score.

## Example 2

```
nums = [-2, -3, 0]
Output: 0
```
Every arrangement has a first prefix sum that is ≤ 0.

## Input Format (custom testing)

```
n
nums[0] ... nums[n-1]
```

## Approach

Sort in **descending** order and count the prefix sums that are > 0. Putting the largest values first makes **every** prefix sum as large as it can possibly be, since the sum of any `i` elements is at most the sum of the `i` largest. The prefix sums only start falling once the negatives begin, so after the first non-positive one you can stop.

Use `long long` for the running sum, which can reach `10^5 · 10^6 = 10^11`.

**Complexity:** `O(n log n)`.

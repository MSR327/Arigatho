#include <bits/stdc++.h>
using namespace std;

int maxScore(vector<int> nums) {
    sort(nums.rbegin(), nums.rend());
    long long s = 0;
    int score = 0;
    for (int v : nums) {
        s += v;
        if (s <= 0) break;
        score++;
    }
    return score;
}

int main() {
    int n;
    cin >> n;
    vector<int> nums(n);
    for (auto &v : nums) cin >> v;
    cout << maxScore(nums) << "\n";
    return 0;
}

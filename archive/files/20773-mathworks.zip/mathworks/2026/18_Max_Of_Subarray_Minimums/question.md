# Maximum of Subarray Minimums (Disk Space Analysis)

**Tag:** `Platform not shown`. The statement was rebuilt from a candidate's notes. This matches the known HackerRank problem "Disk Space Analysis".

**Year:** 2026 · **Source:** candidate notes pasted in chat (Nov 2026): "generate all the subarrays and find the minimum of that subarrays ... give the maximum of these minimums of all subarrays ... based on binary search". *The statement below is reconstructed.*

## Problem

Taken literally, "the maximum of the minimums over **all** subarrays" is just `max(arr)`, because every single element is a subarray of length 1. So the real question must fix the subarray length, which is the standard version:

You are given an array `space` of `n` integers and a segment length `x`. Consider every contiguous subarray (segment) of length exactly `x`, and find the **minimum** of each one. Return the **maximum** of these minimums.

## Function Description

```cpp
int segment(int x, vector<int> space);
```

**Parameters**
- `int x`: the length of each segment
- `int space[n]`: the array

**Returns**
- `int`: the maximum among the minimums of all segments of length `x`

## Constraints (typical)

- `1 ≤ n ≤ 10^6`
- `1 ≤ x ≤ n`
- `1 ≤ space[i] ≤ 10^9`

## Example

```
x = 2, space = [8, 2, 4, 6]
```
The segments of length 2 are `[8,2]`, `[2,4]` and `[4,6]`, with minimums 2, 2 and 4. The maximum is **4**.

```
Output: 4
```

## Example 2

```
x = 3, space = [2, 5, 4, 6, 8]
Segments: [2,5,4] → 2, [5,4,6] → 4, [4,6,8] → 4
Output: 4
```

## Example 3 (the literal "all subarrays" reading)

```
x = 1, space = [1, 3, 2]
Output: 3        (= max(space))
```

## Input Format (custom testing)

```
x
n
space[0] ... space[n-1]
```

## Approach

**Sliding-window minimum with a monotonic deque, `O(n)`.** Keep indices in the deque with increasing values. When you add `i`, pop from the back every index whose value is ≥ `space[i]`. Drop the front index once it falls outside the window. The front then holds the window minimum, and the answer is the largest of these minimums.

**Binary search alternative**, which matches the notes' hint: binary search on the answer `v`. The check asks whether some window of length `x` has every element ≥ `v`, which is the same as asking whether there is a run of at least `x` consecutive elements ≥ `v`. Each check is `O(n)`, so the total is `O(n log max)`.

**Complexity:** `O(n)` with the deque, which is what the solution uses.

#include <bits/stdc++.h>
using namespace std;

// Sliding-window minimum with a monotonic deque; return the largest window minimum.
int segment(int x, vector<int> space) {
    deque<int> dq;
    int best = INT_MIN;
    for (int i = 0; i < (int)space.size(); ++i) {
        while (!dq.empty() && space[dq.back()] >= space[i]) dq.pop_back();
        dq.push_back(i);
        if (dq.front() <= i - x) dq.pop_front();
        if (i >= x - 1) best = max(best, space[dq.front()]);
    }
    return best;
}

int main() {
    int x, n;
    cin >> x >> n;
    vector<int> space(n);
    for (auto &v : space) cin >> v;
    cout << segment(x, space) << "\n";
    return 0;
}

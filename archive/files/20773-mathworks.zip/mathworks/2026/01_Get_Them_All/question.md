# Get Them All

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2026 (MathWorks OA, Oct 2026) · **Source:** `practice/mathworks/WhatsApp Image 2026-10-25 at 9.09.43 PM.jpeg`

## Problem

You are given an array of integers `arr` and three integers `x`, `y` and `z`. They limit how many non-overlapping subarrays of each fixed length you can choose:

- `x` = maximum number of subarrays of length **1**
- `y` = maximum number of subarrays of length **2**
- `z` = maximum number of subarrays of length **3**

Choose non-overlapping subarrays, using **at most** `x` of length 1, `y` of length 2 and `z` of length 3, so that the total sum of all selected elements is as large as possible.

Return this maximum possible sum.

## Function Description

Complete the function `calculateProfit`.

```cpp
int calculateProfit(vector<int> arr, int x, int y, int z);
```

**Parameters**
- `int arr[n]`: the array of integers
- `int x`: maximum number of length-1 subarrays
- `int y`: maximum number of length-2 subarrays
- `int z`: maximum number of length-3 subarrays

**Returns**
- `int`: the maximum possible total sum (the solution uses `long long` internally)

## Constraints

- `1 ≤ n ≤ 200`
- `-10^5 ≤ arr[i] ≤ 10^5`
- `0 ≤ x, y, z ≤ 20`

## Example 1

```
arr = [1, 2, 3, 4, 5], x = 1, y = 1, z = 1
Output: 15
```

- For `x = 1`: you can choose one of `[1]`, `[2]`, `[3]`, `[4]` or `[5]`.
- For `y = 1`: you can choose one of `[1,2]`, `[2,3]`, `[3,4]` or `[4,5]`.
- For `z = 1`: you can choose one of `[1,2,3]`, `[2,3,4]` or `[3,4,5]`.
- Subarrays cannot overlap. The best choice is `[3,4,5]` (sum 12) plus `[1,2]` (sum 3), for a total of **15**.

## Example 2

```
arr = [-7, 4, 0, -7, 0, 1, 0], x = 0, y = 1, z = 0
Output: 4
```

- Because `x = 0` and `z = 0`, no subarray of length 1 or 3 can be chosen.
- For `y = 1`: the options are `[-7,4]`, `[4,0]`, `[0,-7]`, `[-7,0]`, `[0,1]` and `[1,0]`.
- The best choice is `[4,0]`, with sum **4**.

## Input Format (custom testing)

```
n
arr[0]
...
arr[n-1]
x
y
z
```

## Approach

Use DP over the position and the remaining quota of each length:

`f[i][a][b][c]` = best sum obtainable from the suffix `arr[i..]` when we may still pick `a` subarrays of length 1, `b` of length 2 and `c` of length 3.

```
f[i][a][b][c] = max( f[i+1][a][b][c],                          // skip arr[i]
                     arr[i]                     + f[i+1][a-1][b][c]   if a > 0
                     arr[i]+arr[i+1]            + f[i+2][a][b-1][c]   if b > 0
                     arr[i]+arr[i+1]+arr[i+2]   + f[i+3][a][b][c-1]   if c > 0 )
```

Because the quotas are "at most", skipping is always allowed, so the answer is never below 0.

**Complexity:** `O(n · (x+1)(y+1)(z+1))`, about 1.9 million states at worst, with O(1) work per state.

#include <bits/stdc++.h>
using namespace std;

// f[i][a][b][c] = best sum from suffix arr[i..] with a/b/c subarrays of
// length 1/2/3 still allowed.
long long calculateProfit(vector<int> arr, int x, int y, int z) {
    int n = arr.size();
    int X = x + 1, Y = y + 1, Z = z + 1;
    auto id = [&](int a, int b, int c) { return (a * Y + b) * Z + c; };
    vector<vector<long long>> f(n + 4, vector<long long>(X * Y * Z, 0));

    for (int i = n - 1; i >= 0; --i) {
        for (int a = 0; a <= x; ++a)
            for (int b = 0; b <= y; ++b)
                for (int c = 0; c <= z; ++c) {
                    long long best = f[i + 1][id(a, b, c)];
                    if (a > 0)
                        best = max(best, arr[i] + f[i + 1][id(a - 1, b, c)]);
                    if (b > 0 && i + 1 < n)
                        best = max(best, (long long)arr[i] + arr[i + 1] + f[i + 2][id(a, b - 1, c)]);
                    if (c > 0 && i + 2 < n)
                        best = max(best, (long long)arr[i] + arr[i + 1] + arr[i + 2] + f[i + 3][id(a, b, c - 1)]);
                    f[i][id(a, b, c)] = best;
                }
    }
    return f[0][id(x, y, z)];
}

int main() {
    int n;
    cin >> n;
    vector<int> arr(n);
    for (auto &v : arr) cin >> v;
    int x, y, z;
    cin >> x >> y >> z;
    cout << calculateProfit(arr, x, y, z) << "\n";
    return 0;
}

# Reduce Piles to Equal Height

**Tag:** `Platform not shown`. The statement was rebuilt from notes or a non-HackerRank screenshot.

**Year:** 2026 · **Source:** `mathworks OA.txt`. *The statement is reconstructed. It is the same problem as LeetCode 1887.*

## Problem

Alex has `n` piles of boxes, and pile `i` has height `piles[i]`. In one step Alex:

1. picks a pile with the **maximum** height (if several are tied, any one of them), and
2. removes boxes from it until its height equals the **next smaller distinct height** among the piles.

Find the **minimum number of steps** needed to make all piles the same height.

## Function Description

```cpp
long long minSteps(vector<int> piles);
```

**Parameters**
- `int piles[n]`: the pile heights

**Returns**
- `long long`: the number of steps

## Constraints (typical)

- `1 ≤ n ≤ 10^5`
- `1 ≤ piles[i] ≤ 10^9`

## Example 1

```
piles = [5, 2, 1]
```
- Step 1: 5 → 2, giving `[2, 2, 1]`
- Step 2: 2 → 1, giving `[1, 2, 1]`
- Step 3: 2 → 1, giving `[1, 1, 1]`

```
Output: 3
```

## Example 2

```
piles = [1, 1, 2, 2, 3]
Output: 4
```
3 → 2 takes 1 step. Then the three piles of height 2 each go to 1, which takes 3 steps.

## Input Format (custom testing)

```
n
piles[0] ... piles[n-1]
```

## Approach

Sort the heights in ascending order. A pile whose height is the `d`-th distinct value (counting from 0 at the smallest) must step down exactly `d` times. So the answer is `Σ rank(piles[i])`, where `rank` is the number of distinct heights strictly smaller than `piles[i]`.

**Complexity:** `O(n log n)`.

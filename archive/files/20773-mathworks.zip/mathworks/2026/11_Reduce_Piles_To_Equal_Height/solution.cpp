#include <bits/stdc++.h>
using namespace std;

long long minSteps(vector<int> piles) {
    sort(piles.begin(), piles.end());
    long long steps = 0, rank = 0;
    for (size_t i = 1; i < piles.size(); ++i) {
        if (piles[i] != piles[i - 1]) rank++;
        steps += rank;
    }
    return steps;
}

int main() {
    int n;
    cin >> n;
    vector<int> piles(n);
    for (auto &v : piles) cin >> v;
    cout << minSteps(piles) << "\n";
    return 0;
}

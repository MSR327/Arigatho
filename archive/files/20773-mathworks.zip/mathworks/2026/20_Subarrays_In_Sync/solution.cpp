#include <bits/stdc++.h>
using namespace std;

// sum % k == len % k  <=>  sum of (a[i] - 1) over the subarray is 0 mod k.
// Count pairs of prefix positions l <= r - m with equal prefix value mod k.
long long countInSync(vector<long long> a, long long k, int m) {
    int n = a.size();
    vector<long long> P(n + 1, 0);
    for (int i = 0; i < n; ++i) P[i + 1] = ((P[i] + a[i] - 1) % k + k) % k;
    unordered_map<long long, long long> cnt;
    long long ans = 0;
    for (int r = m; r <= n; ++r) {
        cnt[P[r - m]]++;
        auto it = cnt.find(P[r]);
        if (it != cnt.end()) ans += it->second;
    }
    return ans;
}

int main() {
    int n, m;
    long long k;
    cin >> n >> k >> m;
    vector<long long> a(n);
    for (auto &v : a) cin >> v;
    cout << countInSync(a, k, m) << "\n";
    return 0;
}

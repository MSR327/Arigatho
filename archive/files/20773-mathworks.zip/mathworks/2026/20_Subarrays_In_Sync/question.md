# Count Subarrays in Sync

**Tag:** `Platform not shown`. The statement was pasted as text from a candidate.

**Year:** 2026 · **Source:** question text pasted in chat (Nov 2026). The examples, function signature and input format were added here.

## Problem

You are given an array `a` of `n` **non-negative** integers and two integers `k` and `m`. A subarray is **in sync** if:
- its length is **at least `m`**, and
- its sum leaves the **same remainder as its length** when divided by `k`, i.e. `sum % k == length % k`.

Count the subarrays that are in sync.

## Function Description

```cpp
long long countInSync(vector<long long> a, long long k, int m);
```

**Parameters**
- `long a[n]`: the array of non-negative integers
- `long k`: the modulus
- `int m`: the minimum subarray length

**Returns**
- `long long`: the number of subarrays in sync

## Constraints (assumed)

- `1 ≤ n ≤ 2·10^5`
- `0 ≤ a[i] ≤ 10^9`
- `1 ≤ k ≤ 10^9`
- `1 ≤ m ≤ n`

## Example 1

```
a = [2, 1, 3, 1], k = 3, m = 2
Output: 2
```
| subarray | length | sum | sum % 3 | length % 3 | in sync? |
|---|---|---|---|---|---|
| [2, 1] | 2 | 3 | 0 | 2 | no |
| [1, 3] | 2 | 4 | 1 | 2 | no |
| [3, 1] | 2 | 4 | 1 | 2 | no |
| [2, 1, 3] | 3 | 6 | 0 | 0 | **yes** |
| [1, 3, 1] | 3 | 5 | 2 | 0 | no |
| [2, 1, 3, 1] | 4 | 7 | 1 | 1 | **yes** |

## Example 2

```
a = [1, 1, 1], k = 5, m = 1
Output: 6
```
All elements are 1, so every subarray's sum equals its length. All 6 subarrays are in sync.

## Input Format (custom testing)

```
n k m
a[0] ... a[n-1]
```

## Approach

1. **Rewrite the condition.** `sum ≡ length (mod k)` is the same as `Σ (a[i] − 1) ≡ 0 (mod k)` over the subarray, because subtracting 1 from each element subtracts the length.
2. **Prefix sums.** Let `P[0] = 0` and `P[i] = (P[i−1] + a[i−1] − 1) mod k`, kept in `[0, k)`. Subarray `[l, r)` is in sync exactly when `P[l] == P[r]` and `r − l ≥ m`.
3. **Count with a hash map, enforcing the length.** Go through `r = m … n`. Before handling `r`, add `P[r − m]` to the map, since it is the newest left end that is far enough back. Then add `count[P[r]]` to the answer. The map only ever contains left ends at least `m` positions back.

**Complexity:** `O(n)` expected time and `O(n)` memory.

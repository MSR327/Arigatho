# Van Delivery with Load-Dependent Fuel Cost

**Tag:** `Platform not shown`. The statement was pasted as text from a candidate.

**Year:** 2026 · **Source:** question text pasted in chat (Nov 2026). The examples, function signature, input format and the limit on `k` were added here.

## Problem

A city has `n` intersections (numbered `1..n`) connected by **undirected** roads of different lengths, and the depot is at intersection `1`. A van has to move `k` packages. Each package has a **pickup** point, a **drop** point and a **weight**. The van can never carry more than `W` in total.

The fuel cost depends on how much the van is carrying: driving a distance `d` with load `L` costs **`d × (1 + L)`**.

The van starts **empty at the depot**, picks up and delivers every package, and then returns to the depot. Find the **cheapest total fuel cost**, or print **-1** if the job can't be done (a package heavier than `W`, or a point that can't be reached).

## Function Description

```cpp
long long minFuelCost(int n, vector<array<long long,3>> roads, long long W,
                      vector<array<long long,3>> packages);
```

**Parameters**
- `int n`: the number of intersections
- `roads[m]`: each road as `{u, v, length}`
- `long W`: the van's capacity
- `packages[k]`: each package as `{pickup, drop, weight}`

**Returns**
- `long long`: the minimum total fuel cost, or `-1`

## Constraints (assumed)

The original text gives no limits. These are assumed so the state space is manageable:
- `1 ≤ n ≤ 10^4`, `0 ≤ m ≤ 5·10^4`, `1 ≤ length ≤ 10^4`
- `1 ≤ k ≤ 8`
- `1 ≤ weight, W ≤ 10^9`

## Example 1

```
n = 4
roads: 1-2 (2), 2-3 (3), 3-4 (1), 1-4 (4)
W = 5
packages: A = (pickup 2, drop 3, weight 2), B = (pickup 4, drop 2, weight 3)
Output: 30
```
One optimal route:

| leg | load | distance | cost |
|---|---|---|---|
| 1 → 2, pick up A | 0 | 2 | 2 × 1 = 2 |
| 2 → 3, drop A | 2 | 3 | 3 × 3 = 9 |
| 3 → 4, pick up B | 0 | 1 | 1 × 1 = 1 |
| 4 → 3 → 2, drop B | 3 | 4 | 4 × 4 = 16 |
| 2 → 1, home | 0 | 2 | 2 × 1 = 2 |

The total is **30**.

## Example 2

```
n = 3, roads: 1-2 (5), W = 10, packages: (pickup 2, drop 3, weight 1)
Output: -1        (intersection 3 can't be reached)
```

## Input Format (custom testing)

```
n m
m lines: u v length
k W
k lines: pickup drop weight
```

## Approach

1. **Reduce the city to key points.** Only the depot and the `2k` pickup and drop points matter. Along any leg between two of them the load stays the same, so the cheapest way to drive that leg is the **shortest path**. Run **Dijkstra** from each key point to get the `(2k+1) × (2k+1)` distance table.
2. **State-space Dijkstra.** A state is `(current key point, status of every package)`, where each package is waiting, in the van, or delivered. Store the statuses as a base-3 number, which gives at most `(2k+1) · 3^k` states (17 · 6561 for k = 8). From a state:
   - go to the pickup point of a **waiting** package if the load stays ≤ `W`, at cost `dist · (1 + L)`;
   - go to the drop point of a package **in the van**, at cost `dist · (1 + L)`.
3. Once everything is delivered, add the empty trip home, `dist(current, depot) · 1`, and take the minimum. If no such state is ever reached, or some package weighs more than `W`, the answer is `-1`.

**Complexity:** `O((2k+1) · (m log n))` for the distances, plus `O(S · k · log S)` for the search, where `S = (2k+1) · 3^k`.

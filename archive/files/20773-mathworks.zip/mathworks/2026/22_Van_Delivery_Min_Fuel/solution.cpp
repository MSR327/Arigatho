#include <bits/stdc++.h>
using namespace std;

const long long INF = LLONG_MAX / 4;

// Dijkstra on the road graph from one source.
static vector<long long> dijkstra(const vector<vector<pair<int, long long>>> &adj, int src) {
    vector<long long> d(adj.size(), INF);
    priority_queue<pair<long long, int>, vector<pair<long long, int>>, greater<>> pq;
    d[src] = 0;
    pq.push({0, src});
    while (!pq.empty()) {
        auto [du, u] = pq.top();
        pq.pop();
        if (du != d[u]) continue;
        for (auto [v, w] : adj[u])
            if (du + w < d[v]) d[v] = du + w, pq.push({d[v], v});
    }
    return d;
}

// State = (current key point, status of every package: 0 waiting, 1 in van, 2 delivered).
// Moving between key points along a shortest road path with load L costs dist * (1 + L).
long long minFuelCost(int n, vector<array<long long, 3>> roads, long long W,
                      vector<array<long long, 3>> packages) {
    int k = packages.size();
    vector<vector<pair<int, long long>>> adj(n + 1);
    for (auto &r : roads) {
        adj[r[0]].push_back({(int)r[1], r[2]});
        adj[r[1]].push_back({(int)r[0], r[2]});
    }
    for (auto &p : packages)
        if (p[2] > W) return -1;

    // key points: 0 = depot, 1 + 2i = pickup i, 2 + 2i = drop i
    vector<int> key = {1};
    for (auto &p : packages) key.push_back(p[0]), key.push_back(p[1]);
    int K = key.size();
    vector<vector<long long>> dist(K, vector<long long>(K));
    for (int a = 0; a < K; ++a) {
        vector<long long> d = dijkstra(adj, key[a]);
        for (int b = 0; b < K; ++b) dist[a][b] = d[key[b]];
    }

    vector<long long> pw(k + 1, 1);
    for (int i = 1; i <= k; ++i) pw[i] = pw[i - 1] * 3;
    long long S = pw[k];
    auto digit = [&](long long mask, int i) { return (mask / pw[i]) % 3; };
    auto load = [&](long long mask) {
        long long L = 0;
        for (int i = 0; i < k; ++i)
            if (digit(mask, i) == 1) L += packages[i][2];
        return L;
    };

    vector<long long> best(K * S, INF);
    priority_queue<pair<long long, long long>, vector<pair<long long, long long>>, greater<>> pq;
    best[0] = 0;  // at depot, all packages waiting
    pq.push({0, 0});
    long long allDelivered = S - 1;  // every digit = 2
    long long answer = INF;
    while (!pq.empty()) {
        auto [c, id] = pq.top();
        pq.pop();
        if (c != best[id]) continue;
        int at = id / S;
        long long mask = id % S;
        if (mask == allDelivered) {
            if (dist[at][0] < INF) answer = min(answer, c + dist[at][0]);  // empty van back home
            continue;
        }
        long long L = load(mask);
        for (int i = 0; i < k; ++i) {
            int dg = digit(mask, i), to;
            long long nm;
            if (dg == 0 && L + packages[i][2] <= W) to = 1 + 2 * i, nm = mask + pw[i];
            else if (dg == 1) to = 2 + 2 * i, nm = mask + pw[i];
            else continue;
            if (dist[at][to] >= INF) continue;
            long long nc = c + dist[at][to] * (1 + L);
            long long nid = to * S + nm;
            if (nc < best[nid]) best[nid] = nc, pq.push({nc, nid});
        }
    }
    return answer >= INF ? -1 : answer;
}

int main() {
    int n, m;
    cin >> n >> m;
    vector<array<long long, 3>> roads(m);
    for (auto &r : roads) cin >> r[0] >> r[1] >> r[2];
    int k;
    long long W;
    cin >> k >> W;
    vector<array<long long, 3>> packages(k);
    for (auto &p : packages) cin >> p[0] >> p[1] >> p[2];
    cout << minFuelCost(n, roads, W, packages) << "\n";
    return 0;
}

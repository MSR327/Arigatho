# First Greater Element Index

**Tag:** `Platform not shown`. The statement comes from a compiled problem set, not a screenshot.

**Year:** 2026 · **Source:** `Mathworks_2026_OA.pdf` (Question 1), `mathworks OA.txt` ("arr[j] > arr[i] — Find Index in Second Array")

## Problem

You are given two integer arrays `A` and `B`. For every element `A[i]`, find the **first** element in `B` (scanning from the left) whose value is **strictly greater** than `A[i]`, and return the index of that element in `B`.

- If several elements satisfy the condition, return the index of the **first occurrence**.
- If no element in `B` is greater than `A[i]`, return **-1**.

Return an array containing the answer for every element of `A`. Indices are **0-based**, as the example shows.

> **Variant from the candidate notes:** one write-up says to pick the **smallest value** in `B` that is greater than `A[i]` and to return a **1-based** index. Both rules are implemented. `firstGreaterIndex` follows the compiled problem set (and is the one `main` prints), and `smallestGreaterIndex` follows the notes version.

## Function Description

```cpp
vector<int> firstGreaterIndex(vector<int> A, vector<int> B);     // compiled set (0-based, first by position)
vector<int> smallestGreaterIndex(vector<int> A, vector<int> B);  // notes variant (1-based, smallest value)
```

**Parameters**
- `int A[N]`: the query array
- `int B[M]`: the array to search

**Returns**
- `int[N]`: for each `A[i]`, the index into `B`, or `-1`

## Constraints (typical)

- `1 ≤ N, M ≤ 10^5`
- `-10^9 ≤ A[i], B[j] ≤ 10^9`

## Example (compiled set)

```
A = [4, 1, 5]
B = [2, 6, 3, 7]
Output = [1, 0, 1]
```
- `4`: the first element greater than 4 is `6`, at index 1.
- `1`: the first element greater than 1 is `2`, at index 0.
- `5`: the first element greater than 5 is `6`, at index 1.

## Example (notes variant)

```
A = [3, 1, 8, 5], B = [7, 4, 2, 9, 4]
Output = [2, 3, 4, 1]     (smallest greater value, 1-based)
```

## Input Format (custom testing)

```
N
A[0] ... A[N-1]
M
B[0] ... B[M-1]
```
The program prints the compiled-set answer on the first line and the notes-variant answer on the second line.

## Approach

**First by position.** Let `pre[j] = max(B[0..j])`. This prefix maximum never decreases, and the first index where `B[j] > x` is exactly the first index where `pre[j] > x`. So each query is one `upper_bound(pre, x)`. If it reaches the end, the answer is -1.

**Smallest greater value.** Sort the pairs `(B[j], j)` and use `upper_bound` on the value. The secondary key makes ties go to the smallest index.

**Complexity:** `O((N + M) log M)` for both.

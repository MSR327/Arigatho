#include <bits/stdc++.h>
using namespace std;

// First index j (0-based) with B[j] > A[i]: binary search on the prefix maximum of B.
vector<int> firstGreaterIndex(vector<int> A, vector<int> B) {
    vector<int> pre(B.size());
    for (size_t j = 0; j < B.size(); ++j) pre[j] = j ? max(pre[j - 1], B[j]) : B[j];
    vector<int> res;
    for (int a : A) {
        auto it = upper_bound(pre.begin(), pre.end(), a);
        res.push_back(it == pre.end() ? -1 : int(it - pre.begin()));
    }
    return res;
}

// Notes variant: smallest value in B greater than A[i], 1-based index (ties -> lowest index).
vector<int> smallestGreaterIndex(vector<int> A, vector<int> B) {
    vector<pair<int, int>> sb;
    for (int j = 0; j < (int)B.size(); ++j) sb.push_back({B[j], j + 1});
    sort(sb.begin(), sb.end());
    vector<int> res;
    for (int a : A) {
        auto it = upper_bound(sb.begin(), sb.end(), make_pair(a, INT_MAX));
        res.push_back(it == sb.end() ? -1 : it->second);
    }
    return res;
}

int main() {
    int n, m;
    cin >> n;
    vector<int> A(n);
    for (auto &v : A) cin >> v;
    cin >> m;
    vector<int> B(m);
    for (auto &v : B) cin >> v;
    for (int v : firstGreaterIndex(A, B)) cout << v << " ";
    cout << "\n";
    for (int v : smallestGreaterIndex(A, B)) cout << v << " ";
    cout << "\n";
    return 0;
}

# Sum of Arrays (getMaxSumOfArray)

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2026 · **Source:** screenshots of the "Sum of Arrays" question (shared in chat, Nov 2026) and `mathworks OA.txt` ("two arrays arr1 and arr2 ... maximum value of i*(arr2[i]-arr1[i])")

## Problem

You are given two arrays, `arr1` and `arr2`, each of length `n`. In one operation, any two elements of **an** array can be swapped, and this can be done any number of times. So each array can be rearranged **independently**, into any order.

Find the **maximum possible sum** of `i × (arr2[i] − arr1[i])` over all `1 ≤ i ≤ n` after rearranging the arrays.

The maximum possible sum can be large, so return it **modulo (10^9 + 7)**.

## Function Description

```cpp
int getMaxSumOfArray(vector<int> arr1, vector<int> arr2);
```

**Parameters**
- `int arr1[n]`: an array of integers
- `int arr2[n]`: an array of integers

**Returns**
- `int`: the maximum possible sum, modulo `10^9 + 7`

## Constraints

- `1 ≤ n ≤ 10^5`
- `1 ≤ arr1[i] ≤ 10^9`
- `1 ≤ arr2[i] ≤ 10^9`

## Example

```
n = 4
arr1 = [2, 1, 3, 4]
arr2 = [2, 3, 2, 3]
```

Some of the possible rearrangements:

| arr1 (rearranged) | arr2 (rearranged) | i·(arr2[i] − arr1[i]) | sum |
|---|---|---|---|
| [2, 1, 3, 4] | [2, 3, 2, 3] | [0, 4, −3, −4] | −3 |
| [3, 1, 2, 4] | [2, 3, 2, 3] | [−1, 4, 0, −4] | −1 |
| [3, 1, 2, 4] | [3, 2, 2, 3] | [0, 2, 0, −4] | −2 |

The maximum possible sum is **7** (for example `arr1 = [4, 3, 2, 1]`, `arr2 = [2, 2, 3, 3]`), and 7 modulo (10^9+7) = 7.

## Sample Case 0

```
STDIN       FUNCTION
-----       --------
3       →   arr1[] size n = 3
1       →   arr1 = [1, 2, 3]
2
3
3       →   arr2[] size n = 3
10      →   arr2 = [10, 10, 10]
10
10
```

**Sample Output**
```
50
```

**Explanation:** with the arrays as given, `arr3 = i·(arr2[i] − arr1[i]) = [9, 16, 21]`, which sums to 46. If `arr1` is changed to `[3, 2, 1]` and `arr2` stays `[10, 10, 10]`, the values are `[7, 16, 27]`, which sum to **50**.

## Input Format (custom testing)

```
n
arr1[0] ... arr1[n-1]   (one per line)
n
arr2[0] ... arr2[n-1]   (one per line)
```

## Approach

`sum = Σ i·arr2[i] − Σ i·arr1[i]`, and the two arrays are rearranged independently, so maximize each part separately using the **rearrangement inequality**:
- `Σ i·arr2[i]` is largest when `arr2` is sorted **ascending**, because the biggest values get the biggest weights.
- `Σ i·arr1[i]` is smallest when `arr1` is sorted **descending**.

**Overflow:** the true sum can reach about `n² · 10^9 / 2 ≈ 5·10^18`, which is close to the `long long` limit. The solution adds it up exactly in `__int128` and takes the modulo at the end. The modulo is normalized to `[0, MOD)` in case the maximum is negative.

**Complexity:** `O(n log n)`.

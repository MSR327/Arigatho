#include <bits/stdc++.h>
using namespace std;

const long long MOD = 1e9 + 7;

// Rearrangement inequality: arr2 ascending, arr1 descending.
int getMaxSumOfArray(vector<int> arr1, vector<int> arr2) {
    sort(arr2.begin(), arr2.end());
    sort(arr1.rbegin(), arr1.rend());
    __int128 s = 0;
    for (size_t i = 0; i < arr1.size(); ++i)
        s += (__int128)(i + 1) * ((long long)arr2[i] - arr1[i]);
    long long r = (long long)(s % MOD);
    if (r < 0) r += MOD;
    return r;
}

int main() {
    int n;
    cin >> n;
    vector<int> a(n);
    for (auto &v : a) cin >> v;
    cin >> n;
    vector<int> b(n);
    for (auto &v : b) cin >> v;
    cout << getMaxSumOfArray(a, b) << "\n";
    return 0;
}

# String Left Shift and Right Shift

**Tag:** `HackerRank (likely)`. This is a known HackerRank problem, but the source is notes, not a screenshot.

**Year:** 2026 · **Source:** `mathworks OA.txt` ("string left shift and then right shift and then return the string"; reported by two candidates). *The statement is reconstructed from the notes and follows the standard HackerRank "Shifting Strings" problem.*

## Problem

You are given a string `s` and two integers, `leftShifts` and `rightShifts`.

- A **single left shift** moves the first character to the end: `"abcde" → "bcdea"`.
- A **single right shift** moves the last character to the front: `"abcde" → "eabcd"`.

Apply `leftShifts` left shifts, then `rightShifts` right shifts. Return the resulting string.

## Function Description

```cpp
string getShiftedString(string s, int leftShifts, int rightShifts);
```

**Parameters**
- `string s`: the string to shift
- `int leftShifts`: the number of left shifts
- `int rightShifts`: the number of right shifts

**Returns**
- `string`: the string after all shifts

## Constraints

- `1 ≤ |s| ≤ 10^5`
- `0 ≤ leftShifts, rightShifts ≤ 10^9`
- `s` contains lowercase English letters

## Example

```
s = "abcde", leftShifts = 1, rightShifts = 2
```
- After 1 left shift: `"bcdea"`
- After 2 right shifts: `"abcde"`, then `"eabcd"`

```
Output: eabcd
```

## Sample Case

```
Input:
abcdefg
2
4
Output:
fgabcde
```
The net effect is 2 right shifts.

## Input Format (custom testing)

```
s
leftShifts
rightShifts
```

## Approach

The shifts cancel each other out. The net left shift is `L = (leftShifts − rightShifts) mod n`, adjusted to the range `[0, n)`. The answer is `s.substr(L) + s.substr(0, L)`.

**Complexity:** `O(n)`.

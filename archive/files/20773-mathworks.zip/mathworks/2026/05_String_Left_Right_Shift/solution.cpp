#include <bits/stdc++.h>
using namespace std;

string getShiftedString(string s, int leftShifts, int rightShifts) {
    int n = s.size();
    long long net = ((long long)leftShifts - rightShifts) % n;
    if (net < 0) net += n;
    return s.substr(net) + s.substr(0, net);
}

int main() {
    string s;
    int l, r;
    cin >> s >> l >> r;
    cout << getShiftedString(s, l, r) << "\n";
    return 0;
}

# Data Stream Queries: Number of Active Streams

**Tag:** `Platform not shown`. The statement was rebuilt from notes or a non-HackerRank screenshot.

**Year:** 2026 · **Source:** `mathworks OA.txt`. *The statement is reconstructed from a candidate's notes.*

## Problem

You are given `N` data streams. Stream `i` has a `startTime[i]` and a `duration[i]`. You are also given `Q` query times.

For every query time `t`, return the **number of streams active at that exact time**. Stream `i` is active at `t` if

```
startTime[i] ≤ t ≤ startTime[i] + duration[i]
```

The ending time is **inclusive**.

## Function Description

```cpp
vector<int> countActiveStreams(vector<int> startTime, vector<int> duration, vector<int> queries);
```

**Parameters**
- `int startTime[N]`: the start time of each stream
- `int duration[N]`: the duration of each stream
- `int queries[Q]`: the query times

**Returns**
- `int[Q]`: the number of active streams at each query time

## Constraints (typical)

- `1 ≤ N, Q ≤ 10^5`
- `0 ≤ startTime[i], duration[i], queries[j] ≤ 10^9`

## Example

```
startTime = [1, 3, 5]
duration  = [4, 2, 0]
queries   = [0, 3, 5, 6]
```
The streams are active on `[1,5]`, `[3,5]` and `[5,5]`.

| t | active streams | count |
|---|----------------|-------|
| 0 | none | 0 |
| 3 | [1,5], [3,5] | 2 |
| 5 | all three (end is inclusive) | 3 |
| 6 | none | 0 |

```
Output: [0, 2, 3, 0]
```

## Input Format (custom testing)

```
N
startTime[0] ... startTime[N-1]
duration[0]  ... duration[N-1]
Q
queries[0] ... queries[Q-1]
```

## Approach

Build two sorted arrays: `starts` and `ends = start + duration`. The number of streams active at `t` is

```
(#starts ≤ t) − (#ends < t)
```

Each count is one binary search: `upper_bound(starts, t)` and `lower_bound(ends, t)`. Use `long long` for `ends`, since `start + duration` can overflow `int`.

**Complexity:** `O((N + Q) log N)`.

#include <bits/stdc++.h>
using namespace std;

vector<int> countActiveStreams(vector<int> startTime, vector<int> duration, vector<int> queries) {
    int n = startTime.size();
    vector<long long> starts(n), ends(n);
    for (int i = 0; i < n; ++i) {
        starts[i] = startTime[i];
        ends[i] = (long long)startTime[i] + duration[i];
    }
    sort(starts.begin(), starts.end());
    sort(ends.begin(), ends.end());

    vector<int> res;
    for (int t : queries) {
        int started = upper_bound(starts.begin(), starts.end(), (long long)t) - starts.begin();
        int ended = lower_bound(ends.begin(), ends.end(), (long long)t) - ends.begin();  // end < t
        res.push_back(started - ended);
    }
    return res;
}

int main() {
    int n;
    cin >> n;
    vector<int> s(n), d(n);
    for (auto &v : s) cin >> v;
    for (auto &v : d) cin >> v;
    int q;
    cin >> q;
    vector<int> qs(q);
    for (auto &v : qs) cin >> v;
    for (int v : countActiveStreams(s, d, qs)) cout << v << " ";
    cout << "\n";
    return 0;
}

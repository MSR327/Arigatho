# K Largest Subarray XORs

**Tag:** `Platform not shown`. The statement comes from a compiled problem set and from notes, not a screenshot.

**Year:** 2026 · **Source:** `Mathworks_2026_OA.pdf` (Question 2), `mathworks OA.txt` ("find kth largest maximum xor of any subarray")

## Problem

You are given an integer array `A` and an integer `K`. Consider every contiguous subarray of `A` and calculate its XOR. For each starting index `i`, that means the XOR of `A[i..i]`, `A[i..i+1]`, `A[i..i+2]`, …, `A[i..n−1]`.

Collect the XOR values of all `n·(n+1)/2` contiguous subarrays (duplicates count separately) and return the **K largest** XOR values, in descending order.

> The notes version asks only for the **K-th largest** value. That is simply the last element of this list, and the solution provides it as a separate function.

## Function Description

```cpp
vector<long long> kLargestSubarrayXors(vector<int> A, long long K);  // compiled set
long long kthLargestSubarrayXor(vector<int> A, long long K);         // notes variant
```

**Parameters**
- `int A[n]`: the array
- `long long K`: how many of the largest values to return

**Returns**
- `long long[K]`: the K largest subarray XORs in descending order, or, for the notes variant, just the K-th one

## Constraints (typical)

- `1 ≤ n ≤ 10^5`
- `0 ≤ A[i] < 2^30`
- `1 ≤ K ≤ min(n·(n+1)/2, 10^5)`

## Example (compiled set)

```
A = [1, 2, 3, 4], K = 3
```
All subarray XORs:
- start 1: `1`, `1^2 = 3`, `1^2^3 = 0`, `1^2^3^4 = 4`
- start 2: `2`, `2^3 = 1`, `2^3^4 = 5`
- start 3: `3`, `3^4 = 7`
- start 4: `4`

Sorted in descending order: `7, 5, 4, 4, 3, 3, 2, 1, 1, 0`.

```
Output: [7, 5, 4]
```

## Example 2 (notes variant: the K-th largest)

```
A = [1, 2, 3], K = 3
XORs: 1, 2, 3, 3, 1, 0  →  sorted 3, 3, 2, 1, 1, 0
Output: 2
```

## Input Format (custom testing)

```
n
A[0] ... A[n-1]
K
```
The program prints the K largest values on the first line and the K-th largest on the second line.

## Approach

1. **Prefix XOR.** Let `p[0] = 0` and `p[i] = A[0]^…^A[i−1]`. Subarray `(l, r)` has XOR `p[l] ^ p[r+1]`, so the task is about the values `p[i] ^ p[j]` over pairs `i < j`.
2. **K-th largest value `T`.** Put all `n+1` prefixes in a **binary trie** with subtree counts. Ordered pairs count each unordered pair twice, and self-pairs give 0, the smallest possible value, so the K-th largest unordered value is the 2K-th largest ordered one. Walk the bits from high to low with one trie pointer per prefix: at bit `b`, count the ordered pairs that could have a 1 at that bit; if there are at least `K`, set the bit, otherwise subtract the count and keep the bit at 0. This costs `O(n · 30)`.
3. **The K largest.** Every value greater than `T` belongs in the answer, and there are fewer than `K` of them. For each prefix, walk the trie along the path that stays equal to `T`, and whenever a branch makes the XOR bigger than `T`, collect that whole subtree. The ordered pairs give each value twice, so sort the collected values in descending order and keep every second one. Then pad with copies of `T` until there are `K` values.

**Complexity:** `O(n · 30 + K · 30 + K log K)` time and `O(n · 30)` memory.

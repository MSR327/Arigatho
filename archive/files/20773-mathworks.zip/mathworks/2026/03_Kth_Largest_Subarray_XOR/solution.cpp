#include <bits/stdc++.h>
using namespace std;

const int B = 30;

struct Trie {
    vector<array<int, 2>> ch{{-1, -1}};
    vector<long long> sz{0};
    void insert(int v) {
        int u = 0;
        sz[u]++;
        for (int b = B - 1; b >= 0; --b) {
            int bit = (v >> b) & 1;
            if (ch[u][bit] == -1) {
                ch[u][bit] = ch.size();
                ch.push_back({-1, -1});
                sz.push_back(0);
            }
            u = ch[u][bit];
            sz[u]++;
        }
    }
};

static vector<int> prefixes(const vector<int> &A) {
    vector<int> p(A.size() + 1, 0);
    for (size_t i = 0; i < A.size(); ++i) p[i + 1] = p[i] ^ A[i];
    return p;
}

static long long kthWithTrie(const vector<int> &p, const Trie &t, long long k) {
    long long K = 2 * k;  // each unordered pair appears twice among ordered pairs; self pairs are 0
    vector<int> cur(p.size(), 0);
    long long ans = 0;
    for (int b = B - 1; b >= 0; --b) {
        long long cnt = 0;
        for (size_t i = 0; i < p.size(); ++i) {
            if (cur[i] == -1) continue;
            int c = t.ch[cur[i]][((p[i] >> b) & 1) ^ 1];
            if (c != -1) cnt += t.sz[c];
        }
        bool one = cnt >= K;
        if (one) ans |= 1LL << b;
        else K -= cnt;
        for (size_t i = 0; i < p.size(); ++i) {
            if (cur[i] == -1) continue;
            int bit = (p[i] >> b) & 1;
            cur[i] = t.ch[cur[i]][one ? bit ^ 1 : bit];
        }
    }
    return ans;
}

long long kthLargestSubarrayXor(vector<int> A, long long K) {
    vector<int> p = prefixes(A);
    Trie t;
    for (int v : p) t.insert(v);
    return kthWithTrie(p, t, K);
}

// collect every leaf below node u: x = XOR bits fixed so far, b = next bit to fix
static void collectAll(const Trie &t, int u, int b, long long x, int pv, vector<long long> &out) {
    if (b < 0) {
        for (long long c = 0; c < t.sz[u]; ++c) out.push_back(x);
        return;
    }
    for (int bit = 0; bit < 2; ++bit) {
        int c = t.ch[u][bit];
        if (c != -1) collectAll(t, c, b - 1, x | ((long long)(bit ^ ((pv >> b) & 1)) << b), pv, out);
    }
}

vector<long long> kLargestSubarrayXors(vector<int> A, long long K) {
    vector<int> p = prefixes(A);
    Trie t;
    for (int v : p) t.insert(v);
    long long T = kthWithTrie(p, t, K);

    // ordered pairs with XOR strictly greater than T (fewer than 2K of them)
    vector<long long> big;
    for (int pv : p) {
        int u = 0;
        long long x = 0;
        for (int b = B - 1; b >= 0 && u != -1; --b) {
            int pb = (pv >> b) & 1, tb = (T >> b) & 1;
            if (tb == 0) {  // choosing the child that makes this bit 1 beats T
                int c = t.ch[u][pb ^ 1];
                if (c != -1) collectAll(t, c, b - 1, x | (1LL << b), pv, big);
            }
            u = t.ch[u][pb ^ tb];  // stay equal to T on this bit
            x |= (long long)tb << b;
        }
    }
    sort(big.rbegin(), big.rend());
    vector<long long> res;
    for (size_t i = 0; i < big.size(); i += 2) res.push_back(big[i]);
    while ((long long)res.size() < K) res.push_back(T);
    return res;
}

int main() {
    int n;
    cin >> n;
    vector<int> A(n);
    for (auto &v : A) cin >> v;
    long long k;
    cin >> k;
    for (long long v : kLargestSubarrayXors(A, k)) cout << v << " ";
    cout << "\n" << kthLargestSubarrayXor(A, k) << "\n";
    return 0;
}

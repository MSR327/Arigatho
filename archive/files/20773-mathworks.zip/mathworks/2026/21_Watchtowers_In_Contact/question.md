# Watchtowers in Contact (Online Range Queries)

**Tag:** `Platform not shown`. The statement was pasted as text from a candidate.

**Year:** 2026 · **Source:** question text pasted in chat (Nov 2026). The example, function signature and input format were added here.

## Problem

There are `n` watchtowers in a row, and tower `i` has height `h[i]` (1-indexed). Two towers `i < j` are **in contact** if every tower strictly between them is **strictly shorter** than the shorter of the two, i.e. `h[t] < min(h[i], h[j])` for all `i < t < j`. Adjacent towers are always in contact.

You get `q` queries. Each one gives an encoded pair `(l', r')`. To decode it:
1. XOR both numbers with the **previous answer** (use 0 for the first query),
2. take each result **mod n**, and add 1. That gives `l` and `r`.
3. If `l > r`, swap them.

Then count the pairs of towers in contact where **both** towers lie between positions `l` and `r` inclusive. You must answer each query before you can read the next one, so the queries are **online**.

## Function Description

```cpp
vector<long long> answerQueries(vector<long long> h, vector<pair<long long, long long>> queries);
```

**Parameters**
- `long h[n]`: the tower heights
- `pair queries[q]`: the encoded pairs `(l', r')`

**Returns**
- `long long[q]`: the answer to each query in order (decoding uses the previous answer)

## Constraints (assumed)

- `1 ≤ n, q ≤ 2·10^5`
- `1 ≤ h[i] ≤ 10^9`
- `0 ≤ l', r' ≤ 10^9`

## Example

```
h = [3, 1, 2, 5, 2, 2, 4]          (positions 1..7)
```
The pairs in contact are:
`(1,2), (1,3), (1,4), (2,3), (3,4), (4,5), (4,7), (5,6), (6,7)`.
For example, `(1,3)` is in contact because the 1 between them is shorter than min(3, 2). `(4,7)` is in contact because 2, 2 < min(5, 4). `(5,7)` is not, because the 2 between them is not strictly shorter than min(2, 4).

| raw (l', r') | previous answer | decoded (l, r) | answer |
|---|---|---|---|
| (0, 6) | 0 | (1, 7) | 9 |
| (9, 10) | 9 | (1, 4) | 5 |
| (6, 3) | 5 | (4, 7) | 4 |

```
Output: 9 5 4
```

## Input Format (custom testing)

```
n q
h[1] ... h[n]
q lines: l' r'
```

## Approach

1. **There are only O(n) contact pairs.** Scan from left to right with a stack of indices whose heights are **strictly decreasing**. When tower `j` arrives:
   - pop every tower shorter than `h[j]`; each of them is in contact with `j`;
   - if the stack still has a tower, it is in contact with `j` too, and if its height **equals** `h[j]`, pop it as well, because `j` now hides it from everything further right;
   - push `j`.
   This finds every pair in `O(n)`, and there are fewer than `2n` pairs.
2. **Each query is a 2-D dominance count.** Count the pairs `(i, j)` with `l ≤ i` and `j ≤ r` (since `i < j`, both are then inside `[l, r]`). Sort the pairs by `j` and build a **persistent segment tree** over `i`, where version `r` contains every pair with `j ≤ r`. Then the answer is the number of `i ≥ l` in version `r`.
3. Persistence lets every query be answered right away in `O(log n)`, which the online decoding requires.

**Complexity:** `O(n log n)` to build and `O(log n)` per query. Memory is `O(n log n)`.

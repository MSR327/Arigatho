#include <bits/stdc++.h>
using namespace std;

// Persistent segment tree over positions 1..n: version r holds the left ends i of all
// contact pairs (i, j) with j <= r.
struct PST {
    vector<int> L, R, cnt;
    int n;
    PST(int n) : n(n) { L.push_back(0), R.push_back(0), cnt.push_back(0); }
    int add(int prev, int lo, int hi, int pos) {
        int cur = L.size();
        L.push_back(L[prev]), R.push_back(R[prev]), cnt.push_back(cnt[prev] + 1);
        if (lo < hi) {
            int mid = (lo + hi) / 2;
            if (pos <= mid) { int c = add(L[prev], lo, mid, pos); L[cur] = c; }
            else { int c = add(R[prev], mid + 1, hi, pos); R[cur] = c; }
        }
        return cur;
    }
    int query(int node, int lo, int hi, int ql) {  // count of positions >= ql
        if (!node || hi < ql) return 0;
        if (lo >= ql) return cnt[node];
        int mid = (lo + hi) / 2;
        return query(L[node], lo, mid, ql) + query(R[node], mid + 1, hi, ql);
    }
};

// All pairs in contact: the stack stays strictly decreasing; each tower meets the
// shorter towers it pops, an equal tower (which it then hides), or the first taller one.
vector<pair<int, int>> contactPairs(const vector<long long> &h) {
    vector<pair<int, int>> pairs;  // (i, j), 1-based, i < j
    vector<int> st;
    for (int j = 0; j < (int)h.size(); ++j) {
        while (!st.empty() && h[st.back()] < h[j]) pairs.push_back({st.back() + 1, j + 1}), st.pop_back();
        if (!st.empty()) {
            pairs.push_back({st.back() + 1, j + 1});
            if (h[st.back()] == h[j]) st.pop_back();
        }
        st.push_back(j);
    }
    return pairs;
}

vector<long long> answerQueries(vector<long long> h, vector<pair<long long, long long>> queries) {
    int n = h.size();
    vector<vector<int>> byRight(n + 1);
    for (auto [i, j] : contactPairs(h)) byRight[j].push_back(i);

    PST pst(n);
    vector<int> root(n + 1, 0);
    for (int r = 1; r <= n; ++r) {
        root[r] = root[r - 1];
        for (int i : byRight[r]) root[r] = pst.add(root[r], 1, n, i);
    }

    vector<long long> res;
    long long last = 0;
    for (auto [lp, rp] : queries) {
        long long l = ((lp ^ last) % n) + 1, r = ((rp ^ last) % n) + 1;
        if (l > r) swap(l, r);
        last = pst.query(root[r], 1, n, l);
        res.push_back(last);
    }
    return res;
}

int main() {
    int n, q;
    cin >> n >> q;
    vector<long long> h(n);
    for (auto &v : h) cin >> v;
    vector<pair<long long, long long>> qs(q);
    for (auto &p : qs) cin >> p.first >> p.second;
    for (long long v : answerQueries(h, qs)) cout << v << "\n";
    return 0;
}

# Shortest Walk in a Tree Through All Task Nodes

**Tag:** `Platform not shown`. The statement was rebuilt from a candidate's notes.

**Year:** 2026 · **Source:** candidate notes pasted in chat (Nov 2026): "given the edges, start node, end node and task nodes ... output the length of the shortest path from start node to end node such that you are passing by all the task nodes ... the edges will be traversed no more than 2 times." *The statement below is reconstructed.*

## Problem

You are given an unweighted tree with `n` nodes numbered `1` to `n`, a `start` node, an `end` node, and a list of `m` **task nodes**. Find the length (number of edges traversed) of the shortest walk that begins at `start`, visits **every** task node at least once, and finishes at `end`.

You may visit nodes and use edges more than once. In an optimal walk, no edge is used more than twice.

## Function Description

```cpp
long long shortestTaskWalk(int n, vector<vector<int>> edges, int start, int end, vector<int> tasks);
```

**Parameters**
- `int n`: the number of nodes
- `int edges[n−1][2]`: the tree edges
- `int start`: the start node
- `int end`: the end node
- `int tasks[m]`: the nodes that must be visited

**Returns**
- `long long`: the minimum number of edges traversed

## Constraints (typical)

- `1 ≤ n ≤ 10^5`
- `0 ≤ m ≤ n`
- `1 ≤ start, end, tasks[i] ≤ n`

## Example

```
n = 7
edges: 1-2, 1-3, 2-4, 2-5, 3-6, 3-7
start = 4, end = 6, tasks = [5, 7]

        1
      /   \
     2     3
    / \   / \
   4   5 6   7
```
One optimal walk is `4 → 2 → 5 → 2 → 1 → 3 → 7 → 3 → 6`, which uses **8** edges. The tree spanned by `{4, 6, 5, 7}` has 6 edges, the path from 4 to 6 has 4 edges, and `2·6 − 4 = 8`.

```
Output: 8
```

## Example 2

```
n = 4, edges: 1-2, 2-3, 3-4, start = 1, end = 4, tasks = []
Output: 3
```

## Input Format (custom testing)

```
n
n−1 lines: u v
start end
m
tasks[0] ... tasks[m-1]
```

## Approach

1. Let `R = {start, end} ∪ tasks`. The walk must cover the **smallest subtree connecting all of `R`**. Call its edge count `E`.
2. A walk that covers a tree and returns to where it began uses each edge exactly twice, for `2E` steps. Because the walk ends at `end` instead of returning to `start`, the edges on the `start → end` path are walked only once. So the answer is **`2E − dist(start, end)`**, and it can't be done in fewer steps.
3. Root the tree at `start` and use an iterative DFS order to find each node's depth and parent. Going from the leaves upward, mark a node as *needed* if it is in `R` or has a needed child. Every needed node other than the root contributes the edge to its parent, so `E` is the number of needed nodes minus 1, and `dist(start, end) = depth[end]`.

**Complexity:** `O(n + m)`.

#include <bits/stdc++.h>
using namespace std;

// answer = 2 * (edges in the subtree spanning start, end and tasks) - dist(start, end)
long long shortestTaskWalk(int n, vector<vector<int>> edges, int start, int end, vector<int> tasks) {
    vector<vector<int>> adj(n + 1);
    for (auto &e : edges) {
        adj[e[0]].push_back(e[1]);
        adj[e[1]].push_back(e[0]);
    }
    vector<int> parent(n + 1, 0), depth(n + 1, 0), order;
    vector<bool> seen(n + 1, false);
    vector<int> st = {start};
    seen[start] = true;
    while (!st.empty()) {
        int u = st.back();
        st.pop_back();
        order.push_back(u);
        for (int v : adj[u])
            if (!seen[v]) seen[v] = true, parent[v] = u, depth[v] = depth[u] + 1, st.push_back(v);
    }

    vector<bool> need(n + 1, false);
    need[start] = need[end] = true;
    for (int t : tasks) need[t] = true;
    long long edgesNeeded = 0;
    for (int i = n - 1; i >= 1; --i) {  // skip order[0] = start (the root)
        int u = order[i];
        if (need[u]) {
            edgesNeeded++;
            need[parent[u]] = true;
        }
    }
    return 2 * edgesNeeded - depth[end];
}

int main() {
    int n;
    cin >> n;
    vector<vector<int>> edges(n - 1, vector<int>(2));
    for (auto &e : edges) cin >> e[0] >> e[1];
    int s, e, m;
    cin >> s >> e >> m;
    vector<int> tasks(m);
    for (auto &t : tasks) cin >> t;
    cout << shortestTaskWalk(n, edges, s, e, tasks) << "\n";
    return 0;
}

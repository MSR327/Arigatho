# Security Grouping (getMinimumGroups)

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2026 · **Source:** screenshots of the "Security Grouping" question (shared in chat, Nov 2026), `mathworks OA.txt` ("Security Panel — Group Same Security IDs"), `MathWorks OA Problems Reference Guide.pdf` (Problem 1). It is the same problem as LeetCode 2910, "Minimum Number of Groups to Create a Valid Assignment".

## Problem

A network has `n` devices, and `vulnerability[i]` is the vulnerability level of the `i`-th device. The devices must be put into security levels (groups) such that:

- all devices in a security level have the **same vulnerability**, and
- the number of devices in any two security levels **differs by at most 1**.

Devices with the same vulnerability may be split across several security levels.

Find the **minimum number of security levels** needed to protect the network.

## Function Description

```cpp
int getMinimumGroups(vector<int> vulnerability);
```

**Parameters**
- `int vulnerability[n]`: the vulnerabilities of the devices

**Returns**
- `int`: the minimum number of groups required

## Constraints

- `1 ≤ n ≤ 10^5`
- `1 ≤ vulnerability[i] ≤ 10^5`

## Example

```
n = 6, vulnerability = [2, 3, 3, 3, 2, 1]
```
The devices need to be grouped into **4** security levels: `[2, 2]`, `[3, 3]`, `[3]`, `[1]`. The group sizes are 2, 2, 1 and 1, so no two differ by more than 1.

```
Output: 4
```

## Sample Case 0

```
STDIN       FUNCTION
-----       --------
5       →   n = 5
1       →   vulnerability = [1, 7, 7, 7, 1]
7
7
7
1
```

**Sample Output**
```
2
```
The groups are `[1, 1]` and `[7, 7, 7]`, with sizes 2 and 3.

## More examples (from the notes version)

| input | counts | answer |
|---|---|---|
| `[1, 2, 3, 1, 1, 2, 1, 3]` | 1→4, 2→2, 3→2 | 4 (sizes `{2,2}, {2}, {2}`) |
| `[3, 2, 3, 2, 3]` | 3→3, 2→2 | 2 |
| `[10, 10, 10, 3, 1, 1]` | 10→3, 3→1, 1→2 | 4 (sizes in `{1, 2}`) |

## Input Format (custom testing)

```
n
vulnerability[0] ... vulnerability[n-1]   (one per line)
```

## Approach

1. Count how often each value appears. Let `minC` be the smallest count. Every group size is at least `s`, so `s ≤ minC`.
2. Try `s = minC, minC−1, …, 1`. A count `c` can be split into groups of size `s` or `s+1` exactly when `g = ⌈c / (s+1)⌉` groups can hold it, i.e. `g · s ≤ c`. The fewest groups for `c` is that `g`.
3. A larger `s` never needs more groups, so the **first** (largest) valid `s` gives the answer `Σ ⌈c/(s+1)⌉`. `s = 1` always works.

**Complexity:** `O(n + U · minC)`. Since `U · minC ≤ n`, this is `O(n)` overall.

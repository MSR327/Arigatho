#include <bits/stdc++.h>
using namespace std;

int getMinimumGroups(vector<int> vulnerability) {
    unordered_map<int, int> freq;
    for (int v : vulnerability) freq[v]++;
    int minC = INT_MAX;
    for (auto &p : freq) minC = min(minC, p.second);

    for (int s = minC; s >= 1; --s) {
        long long total = 0;
        bool ok = true;
        for (auto &p : freq) {
            int c = p.second;
            int g = (c + s) / (s + 1);  // ceil(c / (s+1))
            if ((long long)g * s > c) { ok = false; break; }
            total += g;
        }
        if (ok) return total;
    }
    return vulnerability.size();
}

int main() {
    int n;
    cin >> n;
    vector<int> v(n);
    for (auto &x : v) cin >> x;
    cout << getMinimumGroups(v) << "\n";
    return 0;
}

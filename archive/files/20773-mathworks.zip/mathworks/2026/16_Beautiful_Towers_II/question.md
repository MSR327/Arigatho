# Beautiful Towers II

**Tag:** `LeetCode`. Shared as a LeetCode link: LeetCode 2866.

**Year:** 2026 · **Source:** link list shared in chat (Nov 2026): https://leetcode.com/problems/beautiful-towers-ii/

## Problem

You are given a 0-indexed array `maxHeights` of `n` integers. Your task is to build `n` towers in a line, where tower `i` has height `heights[i]`.

A configuration of towers is **beautiful** if:
1. `1 ≤ heights[i] ≤ maxHeights[i]` for every `i`, and
2. `heights` is a **mountain** array: there is an index `p` such that
   - `heights[j − 1] ≤ heights[j]` for all `0 < j ≤ p`, and
   - `heights[k + 1] ≤ heights[k]` for all `p ≤ k < n − 1`.

Return the **maximum possible sum of heights** of a beautiful configuration.

## Function Description

```cpp
long long maximumSumOfHeights(vector<int> maxHeights);
```

**Parameters**
- `int maxHeights[n]`: the height limit for each position

**Returns**
- `long long`: the maximum total height of a beautiful configuration

## Constraints

- `1 ≤ n ≤ 10^5`
- `1 ≤ maxHeights[i] ≤ 10^9`

## Example 1

```
maxHeights = [5, 3, 4, 1, 1]
Output: 13
```
`heights = [5, 3, 3, 1, 1]` is a mountain with its peak at index 0, and its sum is 13.

## Example 2

```
maxHeights = [6, 5, 3, 9, 2, 7]
Output: 22
```
`heights = [3, 3, 3, 9, 2, 2]`, with its peak at index 3.

## Example 3

```
maxHeights = [3, 2, 5, 5, 2, 3]
Output: 18
```
`heights = [2, 2, 5, 5, 2, 2]`, with its peak at index 2 (or 3).

## Input Format (custom testing)

```
n
maxHeights[0] ... maxHeights[n-1]
```

## Approach

Once the peak `p` is fixed, the best heights are determined: going left from `p`, `heights[j] = min(maxHeights[j], heights[j+1])`, and the right side is symmetric.

- `left[i]` = the best sum of `heights[0..i]` when `i` is the peak with height `maxHeights[i]`. Use a **monotonic stack** of indices with increasing heights. Pop everything taller than `maxHeights[i]`. If `j` is the new stack top, then `left[i] = left[j] + maxHeights[i] · (i − j)`, because every position after `j` is capped at `maxHeights[i]`. If the stack is empty, `left[i] = maxHeights[i] · (i + 1)`.
- `right[i]` is computed the same way from the right.
- The answer is `max over i of left[i] + right[i] − maxHeights[i]`.

**Complexity:** `O(n)`.

#include <bits/stdc++.h>
using namespace std;

long long maximumSumOfHeights(vector<int> maxHeights) {
    int n = maxHeights.size();
    vector<long long> left(n), right(n);
    vector<int> st;
    for (int i = 0; i < n; ++i) {
        while (!st.empty() && maxHeights[st.back()] > maxHeights[i]) st.pop_back();
        int j = st.empty() ? -1 : st.back();
        left[i] = (j == -1 ? 0 : left[j]) + (long long)maxHeights[i] * (i - j);
        st.push_back(i);
    }
    st.clear();
    for (int i = n - 1; i >= 0; --i) {
        while (!st.empty() && maxHeights[st.back()] > maxHeights[i]) st.pop_back();
        int j = st.empty() ? n : st.back();
        right[i] = (j == n ? 0 : right[j]) + (long long)maxHeights[i] * (j - i);
        st.push_back(i);
    }
    long long best = 0;
    for (int i = 0; i < n; ++i) best = max(best, left[i] + right[i] - maxHeights[i]);
    return best;
}

int main() {
    int n;
    cin >> n;
    vector<int> h(n);
    for (auto &v : h) cin >> v;
    cout << maximumSumOfHeights(h) << "\n";
    return 0;
}

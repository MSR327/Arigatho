# MathWorks OA: Aptitude / Math MCQs

These are all the aptitude and math MCQs in the collected material: the "Math Question" section that opens every MathWorks HackerRank test (usually Q1–Q6). Programming MCQs (C, C++, Python, OS, DB) are left out.

**Why this matters for 2026:** `mathworks OA.txt` says the 2026 OA had **3 coding questions and 5 MCQs**. The MCQs were on probability with P(A ∪ B), time and work, data interpretation, and vector properties (dot and cross product). Those topics are listed first, then every past question grouped by topic.

The answers marked ✅ were checked by computation (brute force or Python).

---

## 0. Topics reported in the 2026 OA (from notes, so the exact questions aren't known)

| # | Reported topic | What to revise |
|---|---|---|
| A | Probability using P(A ∪ B) = P(A) + P(B) − P(A ∩ B) | Inclusion–exclusion, and "divisible by x or y" style questions (see Q8 and Q9 below) |
| B | Time and work: 5 people a, b, c, d, e with their combined and individual work; find which two have the **same rate** | Rates add: if A finishes in `x` days, A's rate is `1/x` per day. Turn every "together in t days" statement into an equation and solve |
| C | Data interpretation | Reading tables and charts, percentages, ratios |
| D | Vector space properties: cross product, dot product | `a·b = |a||b|cosθ`; `a×b` is perpendicular to both `a` and `b`; `a×b = −(b×a)`; `a·(a×b) = 0` (see Q20 below) |
| E | (not remembered) | — |

> The only 2026 MCQ details are these topic names. Every question below is a **real past MathWorks MCQ** taken from the screenshots or PDFs.

---

## 1. Probability

**Q1. Roll of dice** *(IIT Bombay 2024)*
A fair six-sided die is rolled twice. What is the probability that the sum is strictly greater than 9?
Options: 1/6 · 1/9 · 1/12 · 1/18
**Answer: 1/6** ✅. The outcomes are (4,6), (5,5), (6,4), (5,6), (6,5), (6,6): 6 out of 36.

**Q2. Rolling a dice 10 times** *(BITS Goa 2023, IIT Bombay 2024)*
A die is rolled 10 times. What is the probability that 2 appears exactly 4 times?
Options: C(10,4)(1/6)⁴(5/6)⁶ · C(10,2)(1/6)⁴(5/6)⁶ · C(10,2)(1/6)²(5/6)⁶ · C(10,4)(1/6)⁶(5/6)⁴
**Answer: C(10,4)(1/6)⁴(5/6)⁶**. This is a binomial: choose which 4 rolls show a 2.

**Q3. Fair coin flipping** *(IIIT Delhi 2024, IISc 2024, Oct 2025)*
A fair coin is flipped 7 times. What is the probability of getting more heads than tails?
Options: 15/64 · 21/64 · 28/64 · 32/64
**Answer: 32/64** ✅. With an odd number of flips there's never a tie, so by symmetry the probability is exactly 1/2.

**Q4. Probability for a ball selection** *(IIIT Delhi 2024)*
A bag has 3 white and 5 black balls. Two balls are drawn one by one without replacement. What is the probability that the **second** ball is white?
Options: 11/56 · 21/56 · 20/56 · 15/56
**Answer: 21/56** (= 3/8). By symmetry, the second draw is as likely to be white as the first: 3/8.

**Q5. Odd and even Fibonacci numbers** *(IIT Bombay 2024)*
In a lottery, 7 numbers are drawn without replacement from the first 20 Fibonacci numbers. What is the probability that the first number drawn is even and the second is odd?
Options: 0.245 · 0.250 · 0.239 · 0.500
**Answer: 0.239** ✅. Counting from F₀ = 0, the first 20 Fibonacci numbers contain 7 even and 13 odd numbers, so the probability is (7/20)·(13/19) = 91/380 ≈ 0.239.

**Q6. Two dice: 4-sided and 6-sided** *(Oct 2025)*
A 4-sided die and a 6-sided die are rolled. What is the probability that they show the same number?
Options: 1/6 · 1/8 · 1/4 · 1/2
**Answer: 1/6**. 4 matching outcomes out of 24.

**Q7. Defective watches** *(NIT Delhi 2024; the photo is partly unreadable)*
A shopkeeper has 10 different models of watches, some of which are defective. A customer buys 2 watches. What is the probability that both are defective?
Options: 1/15 · 1/10 · 3/20 · 7/15
**Likely answer: 1/15**, if 3 of the 10 are defective: C(3,2)/C(10,2) = 3/45. *The defect count can't be read in the photo.*

**Q8. Divisibility by 7 or 9** *(NIT Delhi 2024, Oct 2025). This is the P(A ∪ B) type from 2026.*
What is the probability that a random integer from 1 to 100 is divisible by 7 or by 9?
Options: 0.15 · 0.20 · 0.24 · 0.30
**Answer: 0.24**. ⌊100/7⌋ + ⌊100/9⌋ − ⌊100/63⌋ = 14 + 11 − 1 = 24.

**Q9. Shared birthday** *(2024 PYQ)*
There are 400 people in a room. What is the probability that at least two share a birthday?
**Answer: 100%**. By the pigeonhole principle, 400 > 366.

---

## 2. Permutations and combinations

**Q10. Committee of 5 members** *(BITS Goa 2024, IIIT Delhi 2024, IIT Bhubaneswar 2024)*
A committee of 5 is formed from 6 men and 4 women. In how many ways can it be formed if it must have at least 2 women?
Options: 145 · 215 · 186 · 340
**Answer: 186** ✅. C(4,2)C(6,3) + C(4,3)C(6,2) + C(4,4)C(6,1) = 120 + 60 + 6.

**Q11. Committee with two people who refuse to serve together** *(2024 PYQ)*
A committee of 5 is chosen from 10 people, and 2 particular people refuse to serve together. How many committees are possible?
**Answer: 196** ✅. C(10,5) − C(8,3) = 252 − 56.

**Q12. Arranging vowels and consonants** *(IIT Bhubaneswar 2024)*
In how many ways can the letters of "ELEPHANT" be arranged so that no two vowels are adjacent?
Options: 720 · None of these · 2880 · 5040
**Answer: None of these (7200)** ✅. Arrange the 5 consonants in 5! = 120 ways. Then place E, E, A in 3 of the 6 gaps: C(6,3) · 3!/2! = 60. That gives 120 × 60 = 7200.

**Q13. Integer solutions** *(Oct 2025)*
How many solutions does x₁ + x₂ + x₃ = 11 have with every xᵢ ≥ 0?
Options: 77 · 78 · 79 · 56
**Answer: 78** ✅. Stars and bars: C(13, 2).

**Q14. Minimum cards drawn** *(BITS Goa 2024)*
How many cards must be drawn from a standard 52-card deck to guarantee at least three cards of the same suit?
Options: 12 · 8 · 9 · 21
**Answer: 9**. Pigeonhole: 2 cards of each of the 4 suits is 8 cards, so the 9th card forces three of one suit.

**Q15. Sets: English and German** *(Oct 2025)*
40 students each take English, German or both. 12 take both, and 22 take German in total. How many take English but not German?
**Answer: 18**. 40 − 22.

---

## 3. Number theory and modular arithmetic

**Q16. Remainder of 2²⁰²¹ ÷ 17** *(IIIT Delhi 2024, Oct 2025)*
Options: 1 · 2 · 7 · 15
**Answer: 15** ✅. 2⁴ ≡ −1, so 2⁸ ≡ 1 (mod 17). Since 2021 mod 8 = 5, the remainder is 2⁵ = 32 ≡ 15.

**Q17. Remainder of 2¹⁰⁰ ÷ 101** *(IISc 2024, Oct 2025)*
**Answer: 1** ✅. 101 is prime, so by Fermat's little theorem 2¹⁰⁰ ≡ 1.

**Q18. 2²⁰ mod 21** *(Oct 2025)* · Options: 1 · 2 · 4 · 8
**Answer: 4** ✅. 2⁶ = 64 ≡ 1 (mod 21) and 20 mod 6 = 2, so the result is 2² = 4.

**Q19. Modulo of a sum of powers** *(IIT Bhubaneswar 2024)*
(5³ + 7² + 3⁴) mod 9 = ? · Options: 0 · 9 · 3 · 7
**Answer: 3** ✅. 125 + 49 + 81 = 255, and 255 = 28·9 + 3.

**Q20. Sum of the digits of 2¹⁰⁰** *(IIT Bombay 2024)* · Options: 5 · 7 · 9 · 11
**Answer: 7** ✅. The literal digit sum is 115, which isn't an option. Repeating the digit sum gives 1+1+5 = 7, which equals 2¹⁰⁰ mod 9 = 7, so the intended answer is the repeated digit sum (digital root), **7**.

**Q21. Largest power of 4 dividing 1000!** *(BITS Goa 2024)*
Options: 124 · 249 · None of these · 995
**Answer: None of these (497)** ✅. The power of 2 in 1000! is 500+250+125+62+31+15+7+3+1 = 994, so n = ⌊994/2⌋ = 497.

**Q22. Integral multiple: aᴾ − a** *(BITS Goa 2024, Oct 2025)*
For what value of P is aᴾ − a an integral multiple of P for every integer a?
Options: 27 · 17 · Both 27 and 17 · Neither
**Answer: 17**. Fermat's little theorem applies because 17 is prime. 27 is neither prime nor a Carmichael number (2²⁷ − 2 is not divisible by 27).

**Q23. Divisible by 3 or 4 between 100 and 999** *(BITS Goa 2023)*
Options: 760 · 600 · 350 · 450
**Answer: 450** ✅. 300 + 225 − 75 (inclusion–exclusion).

**Q24. Fermat's Last Theorem in disguise** *(IIT Bhubaneswar 2024)*
Which natural numbers a, b, c satisfy aⁿ + bⁿ = cⁿ with n > 2?
Options: (3,4,5) · (20,99,101) · (25,50,75) · None of these
**Answer: None of these**. No solutions exist for n > 2.

---

## 4. Series and sequences

**Q25. Sum of an infinite series** *(IIT Bombay 2024, IIT Bhubaneswar 2024, Oct 2025)*
Σ_{i=0}^{∞} (2/7)ⁱ = ? · Options: 7/2 · 5/7 · 2/7 · 7/5
**Answer: 7/5**. 1 / (1 − 2/7).

**Q26. Sum of reciprocals of HP terms** *(IIT Bhubaneswar 2024)*
The sum of the reciprocals of the first 40 terms of an HP is 1600, and of the first 60 terms is 3300. What is the sum of the reciprocals of the first 100 terms?
Options: 9500 · 11200 · 12600 · 10000
**Worked answer: 8500** ✅. The reciprocals form an AP: 20(2a + 39d) = 1600 and 30(2a + 59d) = 3300 give d = 1.5 and 2a = 21.5, so S₁₀₀ = 50(21.5 + 148.5) = 8500. *None of the options match, so either the question has a typo or one of its numbers is shown wrong in the photo.*

**Q27. Series for cos x** *(BITS Goa 2023, BITS Goa 2024)*
Which series computes cos(x)?
(A) Σ (−1)ⁿ x²ⁿ/(2n)! · (B) Σ (−1)ⁿ xⁿ/n! · (C) Σ x²ⁿ/(2n)! · (D) Σ (−x)ⁿ/n!
**Answer: (A)**. (B) and (D) are e⁻ˣ, and (C) is cosh x.

**Q28. Recurrence** *(19 Aug 2025)*
T(1) = 1, T(n) = 2T(n−1) + n. What is T(n)?
**Answer: 2ⁿ⁺¹ − n − 2**. Check: T(2) = 4, T(3) = 11.

---

## 5. Geometry and vectors (the 2026 "vector" topic)

**Q29. Unit vector perpendicular to two vectors** *(IISc 2024)*
a = i + 2j + k, b = j + 2k. Find a unit vector perpendicular to both.
Options: ±(3i−2j+2k)/√2 · ±(3i−2j+k)/√14 · ±(3i+3j+k)/√19 · ±(3i−2j+k)/√2
**Answer: ±(3i − 2j + k)/√14** ✅. a × b = (2·2 − 1·1, 1·0 − 1·2, 1·1 − 2·0) = (3, −2, 1), whose length is √14.

**Q30. Area of a triangle with sides 20, 99, 101** *(Oct 2025)*
Options: 915 · 1217 · 990 · 800
**Answer: 990**. Heron's formula: s = 110, and √(110·90·11·9) = 990.

---

## 6. Graphs and complexity (in the Math section)

**Q31. Minimum edges in a connected graph** *(IIT Bhubaneswar 2024)* · Options: N · 2N · N−1 · 2N−1
**Answer: N − 1**. That is a tree.

**Q32. Edges in a k-regular graph** *(IIIT Delhi 2024)* · Options: n×k · (n×k)/2 · n+k · n²−k²
**Answer: (n × k)/2**. By the handshake lemma, the degrees sum to 2E.

**Q33. Property NOT obeyed by a POSET** *(NIT Delhi 2024)* · Options: Reflexivity · Transitivity · Anti-symmetry · Symmetry
**Answer: Symmetry**. A partial order is reflexive, antisymmetric and transitive.

**Q34. Upper bound of f + g** *(BITS Goa 2024)*
f(n) = O(n) and g(n) = O(n!). What is (f+g)(n)? · Options: O(n) · O(n!) · O(n³) · O(n²)
**Answer: O(n!)**.

**Q35. Asymptotic running time** *(BITS Goa 2023, IIIT Delhi 2024)*
An algorithm splits a problem into 4 subproblems, each half the size, plus linear work. What is its running time?
Options: O(n log n) · O(n² log n) · O(n) · O(n²)
**Answer: O(n²)**. T(n) = 4T(n/2) + n; by the Master theorem, a = 4, b = 2, so n^(log₂4) = n².

---

## Not captured in the photos

These Math-section questions appear in the tests, but their screenshots are missing or cut off:
- BITS Goa 2023: Q1, Q2
- IIT Bombay 2024: Q3
- IISc 2024: Q15, Q17 ("Solving an ODE"), Q18
- NIT Delhi 2024: Q4–Q6

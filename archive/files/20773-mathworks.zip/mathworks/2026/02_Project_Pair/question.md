# Project Pair (Non-Perfect-Square Pairs)

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2026 (MathWorks OA, Oct 2026) · **Source:** `WhatsApp Image 2026-10-25 ... (1).jpeg`, `(2).jpeg`, `mathworks OA.txt`

## Problem

A teacher assigns random numbers to students for a project. Two students can be paired if the **product of their assigned numbers is not a perfect square**, i.e. it is not some integer multiplied by itself. Each student can be in at most one pair.

Find the **maximum number of pairs** that can be formed after changing **at most `k`** numbers to any positive integer.

## Function Description

Complete the function `getNonPerfectPairs`.

```cpp
int getNonPerfectPairs(vector<int> arr, int k);
```

**Parameters**
- `int arr[n]`: the originally assigned numbers
- `int k`: the number of changes that can be made

**Returns**
- `int`: the maximum number of non-perfect-square pairs

## Constraints

- `1 ≤ n ≤ 10^5`
- `1 ≤ arr[i] ≤ 10^6`
- `0 ≤ k ≤ n`

## Example

```
arr = [4, 12, 20, 5, 20, 5, 45], k = 1
Output: 3
```

- 4 and 5 can be paired (product 20 is not a perfect square).
- 12 and 20 can be paired (product 240 is not a perfect square).
- Change one 20 to 11; then 11 and 5 can be paired (product 55 is not a perfect square).

That gives 3 pairs, which is the maximum.

## Sample Case 0

**Input**
```
6
2
18
3
50
8
32
1
```
(`n = 6`, `arr = [2, 18, 3, 50, 8, 32]`, `k = 1`)

**Output**
```
2
```

**Explanation**
- 3 and 2 can be paired, since their product 6 is not a perfect square.
- Change 50 to 1 and pair 1 with 32, since their product 32 is not a perfect square.

## Input Format (custom testing)

```
n
arr[0] ... arr[n-1]   (one per line)
k
```

## Approach

1. **Square-free kernel.** Write every number as `a = s · t²`, where `s` is square-free (its kernel). Then `a·b` is a perfect square **exactly when** `kernel(a) == kernel(b)`. Compute kernels with a smallest-prime-factor sieve up to 10^6.
2. Group the numbers by kernel. Two numbers can be paired only if they come from **different** groups.
3. With `n` items and the largest group of size `M`, the maximum matching across different groups is `min(⌊n/2⌋, n − M)`.
4. A change can turn a number into a brand-new prime, giving it a kernel of its own. The best use of the `k` changes is to shrink the biggest groups. Find the smallest level `L ≥ 1` such that `Σ max(0, cnt − L) ≤ k` (binary search or a direct scan). The answer is then `min(⌊n/2⌋, n − L)`.

Checking the example: the kernels are `4→1, 12→3, 20→5, 5→5, 20→5, 5→5, 45→5`. The group with kernel 5 has 5 items. With `k = 1` we get `L = 4`, so the answer is `min(3, 7−4) = 3` ✓

**Complexity:** `O(MAX log log MAX + n log n)`.

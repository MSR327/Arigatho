#include <bits/stdc++.h>
using namespace std;

// a*b is a perfect square  <=>  squarefree(a) == squarefree(b)
int getNonPerfectPairs(vector<int> arr, int k) {
    int n = arr.size();
    int mx = *max_element(arr.begin(), arr.end());

    vector<int> spf(mx + 1, 0);
    for (int i = 2; i <= mx; ++i)
        if (spf[i] == 0)
            for (long long j = i; j <= mx; j += i)
                if (spf[j] == 0) spf[j] = i;

    unordered_map<int, int> groups;
    for (int a : arr) {
        int kernel = 1;
        while (a > 1) {
            int p = spf[a], e = 0;
            while (a % p == 0) a /= p, ++e;
            if (e & 1) kernel *= p;
        }
        groups[kernel]++;
    }

    vector<int> cnt;
    for (auto &g : groups) cnt.push_back(g.second);

    // smallest max group size L reachable with <= k changes
    auto cost = [&](int L) {
        long long c = 0;
        for (int v : cnt) if (v > L) c += v - L;
        return c;
    };
    int lo = 1, hi = *max_element(cnt.begin(), cnt.end());
    while (lo < hi) {
        int mid = (lo + hi) / 2;
        if (cost(mid) <= k) hi = mid;
        else lo = mid + 1;
    }
    return min(n / 2, n - lo);
}

int main() {
    int n;
    cin >> n;
    vector<int> arr(n);
    for (auto &v : arr) cin >> v;
    int k;
    cin >> k;
    cout << getNonPerfectPairs(arr, k) << "\n";
    return 0;
}

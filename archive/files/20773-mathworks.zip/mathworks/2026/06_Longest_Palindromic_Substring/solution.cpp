#include <bits/stdc++.h>
using namespace std;

// Manacher's algorithm
string longestPalindrome(string s) {
    string t = "#";
    for (char c : s) t += c, t += '#';
    int m = t.size();
    vector<int> rad(m, 0);
    int center = 0, right = 0, bestLen = 0, bestStart = 0;
    for (int i = 0; i < m; ++i) {
        if (i < right) rad[i] = min(right - i, rad[2 * center - i]);
        while (i - rad[i] - 1 >= 0 && i + rad[i] + 1 < m && t[i - rad[i] - 1] == t[i + rad[i] + 1])
            rad[i]++;
        if (i + rad[i] > right) center = i, right = i + rad[i];
        // rad[i] equals the palindrome length in s; start index in s is (i - rad[i]) / 2
        int start = (i - rad[i]) / 2;
        if (rad[i] > bestLen || (rad[i] == bestLen && start < bestStart))
            bestLen = rad[i], bestStart = start;
    }
    return s.substr(bestStart, bestLen);
}

int main() {
    string s;
    cin >> s;
    cout << longestPalindrome(s) << "\n";
    return 0;
}

# Longest Palindromic Substring

**Tag:** `Platform not shown`. The statement was rebuilt from notes or a non-HackerRank screenshot.

**Year:** 2026 · **Source:** `mathworks OA.txt` ("longest palindrome in a string"). *The statement is reconstructed from a candidate's notes.*

## Problem

Given a string `s`, return its **longest substring that is a palindrome**, meaning it reads the same forwards and backwards. If several palindromes share the maximum length, return the one that appears **first**, i.e. has the smallest starting index.

## Function Description

```cpp
string longestPalindrome(string s);
```

**Parameters**
- `string s`: the input string

**Returns**
- `string`: the longest palindromic substring

## Constraints

- `1 ≤ |s| ≤ 10^5`
- `s` consists of lowercase English letters

## Example 1

```
s = "babad"
Output: bab
```
`"aba"` is also length 3, but `"bab"` comes first.

## Example 2

```
s = "cbbd"
Output: bb
```

## Example 3

```
s = "forgeeksskeegfor"
Output: geeksskeeg
```

## Input Format (custom testing)

```
s
```

## Approach

Use **Manacher's algorithm**. Insert a separator between characters (`#a#b#a#`) so that even-length and odd-length palindromes are handled the same way. Then compute the palindrome radius at every center in linear time by reusing the mirror position inside the rightmost palindrome found so far.

(Expanding around each center is `O(n²)`, which is also fine for `n ≤ 5000`.)

**Complexity:** `O(n)`.

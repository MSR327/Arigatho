# Maximize the Minimum Absolute Difference of a Size-M Subsequence

**Tag:** `Platform not shown`. The statement was rebuilt from notes or a non-HackerRank screenshot.

**Year:** 2026 · **Source:** `MathWorks OA Problems Reference Guide.pdf` (Problem 3). *The statement is reconstructed. It is the same problem as LeetCode 1552 and SPOJ "Aggressive Cows".*

## Problem

You are given an integer array `arr` of length `n` and an integer `m`. Choose a subsequence of exactly `m` elements so that the **minimum absolute difference between any two chosen elements** is as **large** as possible.

Return that maximum possible minimum difference.

## Function Description

```cpp
int maxMinDifference(vector<int> arr, int m);
```

**Parameters**
- `int arr[n]`: the array
- `int m`: how many elements to choose

**Returns**
- `int`: the largest achievable minimum pairwise absolute difference

## Constraints (typical)

- `2 ≤ m ≤ n ≤ 10^5`
- `0 ≤ arr[i] ≤ 10^9`

## Example 1

```
arr = [1, 2, 3, 4, 7], m = 3
```
Choose `{1, 4, 7}`. The pairwise differences are 3, 3 and 6, so the minimum is **3**. No choice does better.

```
Output: 3
```

## Example 2

```
arr = [5, 4, 3, 2, 1, 1000000000], m = 2
Output: 999999999
```

## Input Format (custom testing)

```
n
arr[0] ... arr[n-1]
m
```

## Approach

1. **Sort** the array. Only absolute differences matter, so the original order is irrelevant. In sorted order, the minimum pairwise difference of a chosen set is the smallest gap between neighbouring chosen elements.
2. **Binary search on the answer** `d` in `[0, max − min]`.
3. **Greedy check for `d`:** take `arr[0]`, then take every next element that is at least `d` above the last one taken. If this picks at least `m` elements, `d` is feasible.

**Complexity:** `O(n log n + n log(max − min))`.

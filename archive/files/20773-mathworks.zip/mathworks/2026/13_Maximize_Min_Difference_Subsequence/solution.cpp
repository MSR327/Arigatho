#include <bits/stdc++.h>
using namespace std;

int maxMinDifference(vector<int> arr, int m) {
    sort(arr.begin(), arr.end());
    auto canPlace = [&](long long d) {
        int cnt = 1;
        long long last = arr[0];
        for (size_t i = 1; i < arr.size(); ++i)
            if (arr[i] - last >= d) cnt++, last = arr[i];
        return cnt >= m;
    };
    long long lo = 0, hi = (long long)arr.back() - arr[0];
    while (lo < hi) {
        long long mid = (lo + hi + 1) / 2;
        if (canPlace(mid)) lo = mid;
        else hi = mid - 1;
    }
    return lo;
}

int main() {
    int n;
    cin >> n;
    vector<int> arr(n);
    for (auto &v : arr) cin >> v;
    int m;
    cin >> m;
    cout << maxMinDifference(arr, m) << "\n";
    return 0;
}

# Minimize Sum After K Halving Operations

**Tag:** `HackerRank (likely)`. This is a known HackerRank problem, but the source is notes, not a screenshot.

**Year:** 2026 · **Source:** `mathworks OA.txt`. *The statement is reconstructed. It is the same problem as HackerRank "Minimize Sum" and LeetCode 1962.*

## Problem

You are given an integer array `num` and an integer `k`. Perform exactly `k` operations. In each operation:

1. remove any element `x` from the array,
2. divide it by 2, and
3. insert `⌈x / 2⌉` back into the array.

Return the **minimum possible sum** of the array after `k` operations.

## Function Description

```cpp
long long minSum(vector<int> num, int k);
```

**Parameters**
- `int num[n]`: the array
- `int k`: the number of operations

**Returns**
- `long long`: the minimum sum after `k` operations

## Constraints

- `1 ≤ n ≤ 10^5`
- `1 ≤ num[i] ≤ 10^4`
- `1 ≤ k ≤ 10^7`

## Example

```
num = [10, 20, 7], k = 4
```
- Pick 20 → 10, giving `[10, 10, 7]`
- Pick 10 → 5, giving `[5, 10, 7]`
- Pick 10 → 5, giving `[5, 5, 7]`
- Pick 7 → 4, giving `[5, 5, 4]`

The sum is **14**.

```
Output: 14
```

## Input Format (custom testing)

```
n
num[0] ... num[n-1]
k
```

## Approach

Always halve the **current maximum**, because it removes the most from the sum. Keep the values in a **max-heap** and repeat pop → push `(x+1)/2` `k` times. You can stop early once the maximum is 1, since `⌈1/2⌉ = 1` changes nothing.

**Complexity:** `O(n + k log n)`.

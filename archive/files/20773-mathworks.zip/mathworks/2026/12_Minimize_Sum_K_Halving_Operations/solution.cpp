#include <bits/stdc++.h>
using namespace std;

long long minSum(vector<int> num, int k) {
    priority_queue<int> pq(num.begin(), num.end());
    while (k-- > 0 && pq.top() > 1) {
        int x = pq.top();
        pq.pop();
        pq.push((x + 1) / 2);
    }
    long long s = 0;
    while (!pq.empty()) s += pq.top(), pq.pop();
    return s;
}

int main() {
    int n;
    cin >> n;
    vector<int> num(n);
    for (auto &v : num) cin >> v;
    int k;
    cin >> k;
    cout << minSum(num, k) << "\n";
    return 0;
}

# Rotate Array with Left and Right Shifts

**Tag:** `Platform not shown`. The statement was rebuilt from a candidate's notes.

**Year:** 2026 · **Source:** candidate notes pasted in chat (Nov 2026): "It was based on rotating array. You have to do no of leftshift and rightshift operation on an array and output the final array." *The statement below is reconstructed. Compare the string version in [05_String_Left_Right_Shift](../05_String_Left_Right_Shift/question.md).*

## Problem

You are given an integer array `arr` of length `n` and two integers, `leftShifts` and `rightShifts`.

- A **single left shift** moves the first element to the end: `[1,2,3,4,5] → [2,3,4,5,1]`.
- A **single right shift** moves the last element to the front: `[1,2,3,4,5] → [5,1,2,3,4]`.

Perform `leftShifts` left shifts, then `rightShifts` right shifts, and return the final array.

## Function Description

```cpp
vector<int> rotateArray(vector<int> arr, long long leftShifts, long long rightShifts);
```

**Parameters**
- `int arr[n]`: the array
- `long long leftShifts`: the number of left shifts
- `long long rightShifts`: the number of right shifts

**Returns**
- `int[n]`: the array after all the shifts

## Constraints (typical)

- `1 ≤ n ≤ 10^5`
- `0 ≤ leftShifts, rightShifts ≤ 10^9`
- `-10^9 ≤ arr[i] ≤ 10^9`

## Example

```
arr = [1, 2, 3, 4, 5], leftShifts = 3, rightShifts = 1
```
- 3 left shifts: `[2,3,4,5,1] → [3,4,5,1,2] → [4,5,1,2,3]`
- 1 right shift: `[3,4,5,1,2]`

```
Output: [3, 4, 5, 1, 2]
```

## Example 2

```
arr = [10, 20, 30], leftShifts = 0, rightShifts = 4
Output: [30, 10, 20]       (4 mod 3 = 1 right shift)
```

## Input Format (custom testing)

```
n
arr[0] ... arr[n-1]
leftShifts
rightShifts
```

## Approach

Left and right shifts cancel out. The net left shift is `L = (leftShifts − rightShifts) mod n`, brought into `[0, n)`. The result is `arr[L..n−1]` followed by `arr[0..L−1]`, which `std::rotate` does in place. Never simulate the shifts one by one, since the counts can be up to 10^9.

**Complexity:** `O(n)`.

#include <bits/stdc++.h>
using namespace std;

vector<int> rotateArray(vector<int> arr, long long leftShifts, long long rightShifts) {
    long long n = arr.size();
    long long net = ((leftShifts - rightShifts) % n + n) % n;
    rotate(arr.begin(), arr.begin() + net, arr.end());
    return arr;
}

int main() {
    int n;
    cin >> n;
    vector<int> arr(n);
    for (auto &v : arr) cin >> v;
    long long l, r;
    cin >> l >> r;
    for (int v : rotateArray(arr, l, r)) cout << v << " ";
    cout << "\n";
    return 0;
}

#include <bits/stdc++.h>
using namespace std;

// dp0[u]: u may keep k child edges; dp1[u]: u keeps its parent edge, so only k-1 child edges.
long long maximizeSumOfWeights(vector<vector<int>> edges, int k) {
    int n = edges.size() + 1;
    vector<vector<pair<int, int>>> adj(n);
    for (auto &e : edges) {
        adj[e[0]].push_back({e[1], e[2]});
        adj[e[1]].push_back({e[0], e[2]});
    }

    // iterative DFS order from root 0
    vector<int> order, parent(n, -1), parentW(n, 0);
    vector<bool> seen(n, false);
    vector<int> st = {0};
    seen[0] = true;
    while (!st.empty()) {
        int u = st.back();
        st.pop_back();
        order.push_back(u);
        for (auto [v, w] : adj[u])
            if (!seen[v]) seen[v] = true, parent[v] = u, parentW[v] = w, st.push_back(v);
    }

    vector<long long> dp0(n, 0), dp1(n, 0);
    for (int idx = n - 1; idx >= 0; --idx) {
        int u = order[idx];
        long long base = 0;
        vector<long long> gains;
        for (auto [v, w] : adj[u]) {
            if (v == parent[u]) continue;
            base += dp0[v];
            gains.push_back(dp1[v] + w - dp0[v]);
        }
        sort(gains.rbegin(), gains.rend());
        long long take = 0;
        dp1[u] = dp0[u] = base;
        for (int i = 0; i < (int)gains.size() && gains[i] > 0 && i < k; ++i) {
            if (i < k - 1) dp1[u] += gains[i];
            take += gains[i];
        }
        dp0[u] = base + take;
    }
    return dp0[0];
}

int main() {
    int n, k;
    cin >> n >> k;
    vector<vector<int>> edges(n - 1, vector<int>(3));
    for (auto &e : edges) cin >> e[0] >> e[1] >> e[2];
    cout << maximizeSumOfWeights(edges, k) << "\n";
    return 0;
}

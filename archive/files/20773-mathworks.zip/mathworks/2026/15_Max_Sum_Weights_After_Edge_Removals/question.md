# Maximize Sum of Weights after Edge Removals

**Tag:** `LeetCode`. Shared as a LeetCode link: LeetCode 3367.

**Year:** 2026 · **Source:** link list shared in chat (Nov 2026): https://leetcode.com/problems/maximize-sum-of-weights-after-edge-removals/

## Problem

There is an undirected **tree** with `n` nodes numbered `0` to `n − 1`. You are given a 2D array `edges` of length `n − 1`, where `edges[i] = [u, v, w]` means there is an edge between nodes `u` and `v` with weight `w`.

Your task is to remove **zero or more** edges such that:
- each node has an edge with **at most `k`** other nodes, and
- the **sum of the weights** of the remaining edges is as large as possible.

Return the **maximum possible sum** of weights of the remaining edges.

## Function Description

```cpp
long long maximizeSumOfWeights(vector<vector<int>> edges, int k);
```

**Parameters**
- `int edges[n−1][3]`: the tree edges as `[u, v, w]`
- `int k`: the maximum degree allowed for every node

**Returns**
- `long long`: the maximum total weight that can be kept

## Constraints

- `2 ≤ n ≤ 10^5`
- `1 ≤ k ≤ n − 1`
- `edges.length == n − 1`
- `0 ≤ u, v ≤ n − 1`
- `1 ≤ w ≤ 10^6`
- The input is generated such that `edges` form a valid tree.

## Example 1

```
edges = [[0,1,4],[0,2,2],[2,3,12],[2,4,6]], k = 2
Output: 22
```
Node 2 has edges to three other nodes. Remove the edge `[0, 2, 2]`, which has the smallest weight. The remaining weights sum to 4 + 12 + 6 = **22**.

## Example 2

```
edges = [[0,1,5],[1,2,10],[0,3,15],[3,4,20],[3,5,5],[0,6,10]], k = 3
Output: 65
```
No node has edges to more than 3 other nodes, so nothing needs to be removed. The sum is **65**.

## Input Format (custom testing)

```
n k
n−1 lines: u v w
```

## Approach

Use a **tree DP**. Root the tree at 0. For each node `u`, compute:
- `dp0[u]`: the best total inside `u`'s subtree when `u` may keep up to **k** edges to its children (the edge to the parent is removed);
- `dp1[u]`: the same, but `u` may keep only **k − 1** child edges (the edge to the parent is kept).

For a child `v` connected by an edge of weight `w`, start by assuming the edge is cut, which contributes `dp0[v]`. Keeping the edge instead contributes `dp1[v] + w`, a **gain** of `dp1[v] + w − dp0[v]`. Sort the gains in descending order and take the positive ones: the best `k` of them for `dp0[u]` and the best `k − 1` for `dp1[u]`. The answer is `dp0[root]`.

Use an iterative DFS order instead of recursion, since a path-shaped tree is 10^5 levels deep.

**Complexity:** `O(n log n)` because of sorting each node's gains.

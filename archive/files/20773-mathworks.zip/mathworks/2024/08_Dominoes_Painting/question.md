# Dominoes Painting

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2024 (MathWorks OA, NIT Durgapur) · **Source:** `m/Mathworks/Mathworks/MathworksPYQ/Dominos problem*.jpg`

## Problem

You are given a valid domino arrangement, represented by two strings in the array `domino`. All dominoes are unique (each is 1×2 or 2×1), and each domino is represented by one English letter, lowercase or uppercase.

Each domino can be coloured with one of three colours: Red, Green or Blue (RGB). Find the number of distinct ways to colour the dominoes so that **no two adjacent dominoes have the same colour**. The answer can be large, so return it modulo `10^9+7`.

**Note:** both halves of a domino have the same colour.

## Function Description

```cpp
int countDistinctColorings(vector<string> domino);
```

**Parameters**
- `string domino[2]`: two strings of equal length describing the arrangement

**Returns**
- `int`: the total number of distinct valid colourings, modulo `10^9+7`

## Constraints

- `1 ≤ |domino[0]| = |domino[1]| ≤ 52`
- Every `domino[i][j]` is in `'a'–'z'` or `'A'–'Z'`.
- The array has size 2 and both strings have the same length.

## Example

```
domino = ["baa", "bcc"]

    b a a
    b c c
```
`b` is a vertical domino, while `a` and `c` are horizontal dominoes stacked on top of each other.
The valid colourings are `[RGG, RBB]`, `[RBB, RGG]`, `[GRR, GBB]`, `[GBB, GRR]`, `[BGG, BRR]` and `[BRR, BGG]`, so the answer is **6**.

## Sample Case 0

```
Input:
2
xy
xy
Output:
6
```
```
x y
x y
```
The valid colourings are `[RG, RG]`, `[RB, RB]`, `[GR, GR]`, `[GB, GB]`, `[BR, BR]` and `[BG, BG]`.

## Input Format (custom testing)

```
2
domino[0]
domino[1]
```

## Approach

Scan the columns from left to right. Each block is either:
- **V**: a vertical domino that fills one column (`domino[0][i] == domino[1][i]`), or
- **H**: two horizontal dominoes stacked on top of each other, filling two columns.

The number of ways for the first block, and the multiplier for each following block given the previous one:

| first block | ways |
|---|---|
| V | 3 |
| H | 3·2 = 6 |

| previous → current | multiplier |
|---|---|
| V → V | 2 (any colour except the previous one) |
| V → H | 2 (top ≠ V, bottom ≠ V, top ≠ bottom → 2·1) |
| H → V | 1 (it must differ from both previous colours) |
| H → H | 3 (2·2 minus the bad cases → 3 valid pairs) |

Multiply the factors together modulo `10^9+7`. This is the classic AtCoder ABC071-D "Coloring Dominoes".

**Complexity:** `O(N)`.

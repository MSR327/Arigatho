#include <bits/stdc++.h>
using namespace std;

const long long MOD = 1e9 + 7;

int countDistinctColorings(vector<string> domino) {
    int n = domino[0].size();
    long long ways = 1;
    int prev = -1;  // -1 none, 0 vertical, 1 horizontal pair
    for (int i = 0; i < n;) {
        int cur = domino[0][i] == domino[1][i] ? 0 : 1;
        if (prev == -1) ways = cur == 0 ? 3 : 6;
        else if (prev == 0) ways = ways * 2 % MOD;
        else if (cur == 1) ways = ways * 3 % MOD;
        // prev horizontal, cur vertical -> factor 1
        prev = cur;
        i += cur == 0 ? 1 : 2;
    }
    return ways;
}

int main() {
    int k;
    cin >> k;
    vector<string> domino(k);
    for (auto &s : domino) cin >> s;
    cout << countDistinctColorings(domino) << "\n";
    return 0;
}

#include <bits/stdc++.h>
using namespace std;

long long maxSteal(vector<int> prices, int k) {
    k = min<int>(k, prices.size());
    nth_element(prices.begin(), prices.begin() + k, prices.end(), greater<int>());
    return accumulate(prices.begin(), prices.begin() + k, 0LL);
}

int main() {
    int n, k;
    cin >> n >> k;
    vector<int> prices(n);
    for (auto &p : prices) cin >> p;
    cout << maxSteal(prices, k) << "\n";
    return 0;
}

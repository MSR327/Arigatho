# Shoplifter: Maximum Value of K Items

**Tag:** `Platform not shown`. The statement was rebuilt from notes or a non-HackerRank screenshot.

**Year:** 2024 · **Source:** `m/Mathworks/Mathworks/channel/5_6105155625962968488.pdf` (Q1)

## Problem

You are a shoplifter who has broken into a shop. You see `N` items you could take, and you know the price of every item. The problem is that you can only take `K` items. Write a program that outputs the **maximum amount** you can steal.

## Function Description

```cpp
long long maxSteal(vector<int> prices, int k);
```

**Parameters**
- `int prices[N]`: the price of each item
- `int k`: the maximum number of items you can carry

**Returns**
- `long long`: the maximum total price

## Input Format

The first line contains two numbers, `N` and `K`. Each of the next `N` lines contains the price of one item.

## Output Format

Print the result on a single line.

## Constraints (typical)

- `1 ≤ K ≤ N ≤ 10^5`
- `0 ≤ price ≤ 10^9`

## Example

```
Input:
5 2
4
6
3
9
2
Output:
15
```
Take the two most expensive items: 9 + 6 = **15**.

## Approach

Pick the `K` largest prices. `nth_element` moves the K largest to the front in `O(N)`. Sorting in descending order also works, in `O(N log N)`.

**Complexity:** `O(N)` on average with `nth_element`.

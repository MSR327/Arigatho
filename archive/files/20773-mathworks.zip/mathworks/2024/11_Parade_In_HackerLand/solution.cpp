#include <bits/stdc++.h>
using namespace std;

int getSwapTime(string color) {
    int zeros = 0, time = 0;
    for (char ch : color) {
        if (ch == '0') zeros++;
        else if (zeros > 0) time = max(time + 1, zeros);
    }
    return time;
}

int main() {
    string s;
    cin >> s;
    cout << getSwapTime(s) << "\n";
    return 0;
}

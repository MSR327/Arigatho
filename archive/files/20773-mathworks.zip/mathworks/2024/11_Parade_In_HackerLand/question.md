# Parade in HackerLand

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2024 (MathWorks OA) · **Source:** `m/Mathworks/Mathworks/MathworksPYQ/parade in hacker land.jpg`. It is the same problem as LeetCode 2380 with 0 and 1 swapped.

## Problem

The people in HackerLand are getting ready for a parade, and the participants are all mixed up. There should be no place where a red uniform is immediately to the left of a blue one.

You are given a binary string where `0` is a person in a red uniform and `1` is a person in a blue uniform. The goal is to remove every occurrence of `"01"`. Each second, **all** substrings `"01"` in the string are changed to `"10"` at the same time. This repeats until no `"01"` is left.

Find the number of seconds the process takes to stop.

## Function Description

```cpp
int getSwapTime(string color);
```

**Parameters**
- `string color`: the binary string

**Returns**
- `int`: the number of seconds until the process stops

## Constraints (typical)

- `1 ≤ |color| ≤ 10^5`

## Example

```
color = "001011"
```
| t | color |
|---|---|
| 0 | 001011 |
| 1 | 010101 |
| 2 | 101010 |
| 3 | 110100 |
| 4 | 111000 |

The process takes **4** seconds.

## Input Format (custom testing)

```
color
```

## Approach

Each `1` moves left past the `0`s in front of it, one step per second. A `1` that has `z` zeros to its left needs at least `z` seconds. It can also get **blocked** by the `1` just ahead of it, in which case it finishes one second after that `1`.

Scan from left to right:
```
zeros = 0, time = 0
for ch in color:
    if ch == '0': zeros++
    else if zeros > 0: time = max(time + 1, zeros)
```
The answer is `time`.

**Complexity:** `O(n)`.

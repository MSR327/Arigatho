# Merging Palindromes

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2024 (MathWorks OA, IIT Bombay, 12 Oct 2024) · **Source:** `m/Mathworks/Mathworks/IIT Bombay/coding/Screenshot from 2024-10-12 19-29-05/10/15.png`

## Problem

You are given two strings. For each string, find all palindromes that can be formed with its letters. From those palindromes, pick one from each set such that combining and rearranging the two produces the **longest palindrome possible**. If several palindromes have that maximum length, choose the **alphabetically smallest** one.

## Example

```
s1 = 'aabbc'
s2 = 'ddefefq'
```
- All letters of the first string can make a palindrome. The choices using all letters are `[abcba, bacab]`.
- All letters of the second string can make a palindrome. The choices using all letters are `[defqfed, dfeqefd, edfqfde, efdqdfe, fdeqedf, fedqdef]`.
- The two longest results for `s1` have length 5, and the six longest results for `s2` have length 6.
- From the longest results for `s1` and `s2`, merge the two that form the alphabetically lowest merged palindrome. Here that means choosing `abcba` and `defqfed`. They can be combined into a single palindrome if either the `c` or the `q` is discarded. The alphabetically smallest combined palindrome is **`abdefcfedba`**.

## Function Description

```cpp
string mergePalindromes(string s1, string s2);
```

**Parameters**
- `string s1`: a string
- `string s2`: a string

**Returns**
- `string`: the merged palindrome

## Constraints

- `1 ≤ |s1|, |s2| ≤ 10^5`
- `s1` and `s2` contain only lowercase English letters (`ascii[a-z]`).

## Sample Case 0

```
Input:
aab
cca
Output:
acaca
```
The characters `['a','a']` can be picked from the first string to form `'aa'`, and `['c','c','a']` from the second to form `'cac'`. Merged together they give `'acaca'`.

## Sample Case 1

```
Input:
adaab
cac
Output:
aaccaa
```
The characters `['a','a','a']` can be picked from the first string to form `'aaa'`, and `['c','c','a']` from the second to form `'cac'`. Merged together they give `'aaccaa'`.

## Input Format (custom testing)

```
s1
s2
```

## Approach

1. Count the letters `cnt1[26]` and `cnt2[26]`. A longest palindrome from one string uses **every pair** (`cnt/2` pairs of each letter) plus **one centre** letter, if the string has any letter with an odd count. Which odd letter becomes the centre is our choice.
2. In the merged palindrome, all pairs from both strings are kept. The two centres `c1` (from s1) and `c2` (from s2) are then handled like this:
   - If some letter has an **odd count in both strings**, use it as both centres. The two copies form an **extra pair**, which beats a single centre. Choose the **smallest** such letter, since a smaller letter in the half makes the result smaller. No centre is left over.
   - Otherwise, any odd letter from either string can be the centre. Pick the **smallest** odd letter in `odd1 ∪ odd2`.
3. Build the answer as `half + centre + reverse(half)`, where `half` lists every pair's letter in sorted order. That is the alphabetically smallest arrangement.

Checking Sample 0: the pairs are `a` (from s1) and `c` (from s2). The odd letters are `{b}` in s1 and `{a}` in s2, with nothing in common. The centre is `a`, so the result is `ac` + `a` + `ca` = `acaca` ✓

**Complexity:** `O(|s1| + |s2|)`.

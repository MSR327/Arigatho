#include <bits/stdc++.h>
using namespace std;

string mergePalindromes(string s1, string s2) {
    int c1[26] = {0}, c2[26] = {0};
    for (char ch : s1) c1[ch - 'a']++;
    for (char ch : s2) c2[ch - 'a']++;

    long long pairs[26];
    for (int i = 0; i < 26; ++i) pairs[i] = c1[i] / 2 + c2[i] / 2;

    // a letter odd in both strings can serve as both centres -> one extra pair
    int common = -1;
    for (int i = 0; i < 26 && common == -1; ++i)
        if (c1[i] % 2 && c2[i] % 2) common = i;

    char centre = 0;
    if (common != -1) {
        pairs[common]++;
    } else {
        for (int i = 0; i < 26; ++i)
            if (c1[i] % 2 || c2[i] % 2) { centre = 'a' + i; break; }
    }

    string half;
    for (int i = 0; i < 26; ++i) half += string(pairs[i], 'a' + i);
    string res = half;
    if (centre) res += centre;
    res += string(half.rbegin(), half.rend());
    return res;
}

int main() {
    string s1, s2;
    cin >> s1 >> s2;
    cout << mergePalindromes(s1, s2) << "\n";
    return 0;
}

#include <bits/stdc++.h>
using namespace std;

long long getSubsequenceCount(string s1, string s2) {
    long long c0 = 0, c1 = 0, c2 = 0;
    for (char ch : s2) {
        // update in reverse so the same character isn't reused within one match
        if (ch == s1[2]) c2 += c1;
        if (ch == s1[1]) c1 += c0;
        if (ch == s1[0]) c0 += 1;
    }
    return c2;
}

int main() {
    string s1, s2;
    cin >> s1 >> s2;
    cout << getSubsequenceCount(s1, s2) << "\n";
    return 0;
}

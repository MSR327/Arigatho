# Count Occurrences of a Length-3 Subsequence

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2024 (MathWorks OA, IISc Bangalore, Masters in Embedded Systems, 7 Oct 2024) · **Source:** `m/Mathworks/Mathworks/IISC/WhatsApp Image 2024-10-09 at 22.44.22.jpeg` (Q51)

## Problem

Given two strings, determine the number of times the first one appears as a **subsequence** of the second one. A subsequence is formed by deleting any number of characters from a string (possibly 0) without changing the order of the characters that remain.

## Function Description

```cpp
long getSubsequenceCount(string s1, string s2);
```

**Parameters**
- `string s1`: the first string, which always has length 3
- `string s2`: the second string

**Returns**
- `long`: the number of times `s1` appears as a subsequence of `s2`

## Constraints

- `length of s1 = 3`
- `1 ≤ |s2| ≤ 5·10^5` *(this part of the photo is cut off, so the limit is assumed)*
- both strings contain English letters

## Example

```
s1 = "ABC"
s2 = "ABCBABC"
```
`s1` appears 5 times as a subsequence of `s2`, at the 1-indexed positions `(1,2,3)`, `(1,2,7)`, `(1,4,7)`, `(1,6,7)` and `(5,6,7)`. The answer is **5**.

## Input Format (custom testing)

```
s1
s2
```

## Approach

Use a DP over the prefixes of `s1`. Let `c0`, `c1` and `c2` count the ways to match `s1[0]`, `s1[0..1]` and `s1[0..2]`. Scan `s2`, and for each character `ch`, update in **reverse** order so that one character is never used twice in the same match:
```
if ch == s1[2]: c2 += c1
if ch == s1[1]: c1 += c0
if ch == s1[0]: c0 += 1
```
The answer is `c2`. The count can reach about `(5·10^5)^3 / 6 ≈ 2·10^16`, which needs 64-bit integers.

**Complexity:** `O(|s2|)`.

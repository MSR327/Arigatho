#include <bits/stdc++.h>
using namespace std;

long long optimalMiddleSubsequence(vector<int> arr) {
    int n = arr.size();
    if (n < 3) return -1;
    vector<long long> suf(n + 1, LLONG_MAX);
    for (int i = n - 1; i >= 0; --i) suf[i] = min(suf[i + 1], (long long)arr[i]);

    long long best = LLONG_MAX, pre = arr[0];
    for (int j = 1; j + 1 < n; ++j) {
        if (pre < arr[j] && suf[j + 1] < arr[j])
            best = min(best, pre + arr[j] + suf[j + 1]);
        pre = min(pre, (long long)arr[j]);
    }
    return best == LLONG_MAX ? -1 : best;
}

int main() {
    int n;
    cin >> n;
    vector<int> arr(n);
    for (auto &v : arr) cin >> v;
    cout << optimalMiddleSubsequence(arr) << "\n";
    return 0;
}

# Optimal Middle Subsequence (Minimum-Sum Mountain Triplet)

**Tag:** `HackerRank (likely)`. This is a known HackerRank problem, but the source is notes, not a screenshot.

**Year:** 2024 · **Source:** `m/Mathworks/Mathworks/channel/5_6105155625962968488.pdf` (Q3). It is the same problem as LeetCode 2909.

## Problem

An intern at HackerRank is assigned to find the **optimal middle subsequence**.

An optimal middle subsequence is a subsequence of length 3 chosen from an array `arr` such that `chosen[0] < chosen[1] > chosen[2]` and the **sum of its elements is as small as possible**.

Given an array, return the sum of the values of the optimal middle subsequence. If there is none, return **-1**.

## Function Description

```cpp
long long optimalMiddleSubsequence(vector<int> arr);
```

**Parameters**
- `int arr[n]`: the array

**Returns**
- `long long`: the minimum sum, or -1

## Constraints (typical)

- `3 ≤ n ≤ 10^5`
- `1 ≤ arr[i] ≤ 10^9`

## Example 1

```
arr = [8, 6, 1, 5, 3]
```
Choose indices `(2, 3, 4)`, with values `1 < 5 > 3`. The sum is **9**, the smallest possible.

```
Output: 9
```

## Example 2

```
arr = [5, 4, 8, 7, 10, 2]
Output: 13         // 4 < 7 > 2
```

## Example 3

```
arr = [6, 5, 4, 3, 4, 5]
Output: -1
```

## Input Format (custom testing)

```
n
arr[0] ... arr[n-1]
```

## Approach

Fix the middle index `j`. The best left element is the **minimum** of `arr[0..j-1]`, and the best right element is the **minimum** of `arr[j+1..n-1]`. If even the minimum is not below `arr[j]`, nothing else on that side is. So precompute the prefix minimums and suffix minimums, and for each `j` with `leftMin < arr[j] > rightMin`, update the answer with `leftMin + arr[j] + rightMin`.

**Complexity:** `O(n)`.

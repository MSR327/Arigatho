#include <bits/stdc++.h>
using namespace std;

int findMinimumIdleness(string shader, int switchCount) {
    int n = shader.size();

    // L = 1: the string must alternate
    int mis = 0;
    for (int i = 0; i < n; ++i) mis += shader[i] != (i % 2 ? 'b' : 'a');
    if (min(mis, n - mis) <= switchCount) return 1;

    vector<int> runs;
    for (int i = 0; i < n;) {
        int j = i;
        while (j < n && shader[j] == shader[i]) ++j;
        runs.push_back(j - i);
        i = j;
    }
    auto flipsNeeded = [&](int L) {
        long long f = 0;
        for (int r : runs) f += r / (L + 1);
        return f;
    };

    int lo = 2, hi = n;
    while (lo < hi) {
        int mid = (lo + hi) / 2;
        if (flipsNeeded(mid) <= switchCount) hi = mid;
        else lo = mid + 1;
    }
    return lo;
}

int main() {
    string s;
    int k;
    cin >> s >> k;
    cout << findMinimumIdleness(s, k) << "\n";
    return 0;
}

# Shader Loader (Minimum Idleness)

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2024 (MathWorks OA, 30 Jul 2024) · **Source:** `m/Mathworks/Mathworks/MathworksPYQ/shadder loader*.jpg`. It is the same problem as LeetCode 3399, "Smallest Substring With Identical Characters II".

## Problem

A game's shaders are rendered by two GPUs, `a` and `b`. A string `shader` records which GPU renders each shader:
- if `shader[i] = 'a'`, GPU `a` renders the `i`-th shader;
- if `shader[i] = 'b'`, GPU `b` renders it.

The **idleness** of this dual-GPU system is the largest number of consecutive shaders rendered by the same GPU. For example, for `shader = "aabbba"`, GPU `a` is used for the first 2 seconds, GPU `b` for the next 3 and GPU `a` for 1 more, so the idleness is 3.

To reduce the idleness, you may apply the following operation **at most `switchCount` times**:
- Pick any index `i` of `shader`. If `shader[i] = 'a'`, change it to `'b'`, and vice versa.

Find the **minimum possible idleness** that can be achieved by applying the operations optimally.

## Function Description

```cpp
int findMinimumIdleness(string shader, int switchCount);
```

**Parameters**
- `string shader`: the GPU used for each shader
- `int switchCount`: the maximum number of operations allowed

**Returns**
- `int`: the minimum possible idleness

## Constraints

- `1 ≤ |shader| ≤ 2·10^5`
- `1 ≤ switchCount ≤ |shader|`
- `shader` consists only of the characters `'a'` and `'b'`.

## Example

```
shader = "aabbbaaaa", switchCount = 2
```
One optimal solution:
- Switch `shader[4]` (1-based) to get `"aababaaaa"`.
- Switch `shader[7]` to get `"aabababaa"`.

The idleness is now **2**.

## Sample Case 0

```
Input:
aaaaa
1
Output:
2
```
Flip `shader[3]` from `'a'` to `'b'`, giving `"aabaa"`.

## Input Format (custom testing)

```
shader
switchCount
```

## Approach

**Binary search on the answer `L`**, the target maximum run length:
- **L ≥ 2:** a run of length `r` needs `⌊r / (L+1)⌋` flips: flip every `(L+1)`-th character inside the run. Add this up over all maximal runs and check that the total is at most `k`.
- **L = 1:** the string must alternate, so the cost is `min(mismatches with "abab…", mismatches with "baba…")`. This case needs separate handling, because a flip at a run boundary can merge with the neighbouring run.

Return the smallest feasible `L`.

**Complexity:** `O(n log n)`.

#include <bits/stdc++.h>
using namespace std;

int countPalindromes(vector<string> arr) {
    long long cnt[26] = {0};
    vector<int> lens;
    for (auto &s : arr) {
        for (char c : s) cnt[c - 'a']++;
        lens.push_back(s.size());
    }
    long long pairs = 0;
    for (long long c : cnt) pairs += c / 2;

    sort(lens.begin(), lens.end());
    int res = 0;
    for (int L : lens) {
        if (pairs < L / 2) break;
        pairs -= L / 2;
        res++;
    }
    return res;
}

int main() {
    int n;
    cin >> n;
    vector<string> arr(n);
    for (auto &s : arr) cin >> s;
    cout << countPalindromes(arr) << "\n";
    return 0;
}

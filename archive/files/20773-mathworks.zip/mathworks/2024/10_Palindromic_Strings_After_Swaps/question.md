# Palindromic Strings (Maximum Palindromes After Swaps)

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2024 (MathWorks OA, NIT Durgapur) · **Source:** `m/Mathworks/Mathworks/MathworksPYQ/Palindrome string*.jpg`. It is the same problem as LeetCode 3035.

## Problem

A string is a palindrome if its reverse is the same as the original string. An analyst at HackerRank is analysing an array of `n` strings made of lowercase English letters.

In one operation, the analyst chooses 4 integers `x, y, i, j` such that `1 ≤ x, y ≤ n`, `1 ≤ i ≤ length(arr[x])` and `1 ≤ j ≤ length(arr[y])`, then swaps `arr[x][i]` and `arr[y][j]` (1-based indexing). Note that `x` may equal `y`.

The analyst wants the **maximum number of palindromic strings** that can be obtained by performing the operation any number of times, possibly 0.

## Function Description

```cpp
int countPalindromes(vector<string> arr);
```

**Parameters**
- `string arr[n]`: the strings to consider

**Returns**
- `int`: the maximum number of palindromic strings possible

## Constraints

- `1 ≤ n ≤ 1000`
- `1 ≤ length(arr[i]) ≤ 1000`
- All strings consist of lowercase English letters only.

## Example

```
n = 4, arr = ["pass", "sas", "asps", "df"]
```
An optimal solution produces 3 palindromes:
- Select `x=1, y=3, i=3, j=1` and swap `arr[1][3]` with `arr[3][1]`. Now `arr = ["paas", "sas", "ssps", "df"]`.
- Select `x=1, y=3, i=4, j=3` and swap `arr[1][4]` with `arr[3][3]`. Now `arr = ["paap", "sas", "ssss", "df"]`.

Return **3**, the number of palindromic strings.

## Sample Case 0

```
Input:
3
xy
tz
abab
Output:
2
```
Starting from `arr = ["xy", "tz", "abab"]`:
- Swap `arr[1][1]` with `arr[3][1]`, giving `["ay", "tz", "xbab"]`.
- Swap `arr[1][2]` with `arr[3][3]`, giving `["aa", "tz", "xbyb"]`.
- Swap `arr[2][1]` with `arr[3][2]`, giving `["aa", "bz", "xtyb"]`.
- Swap `arr[2][2]` with `arr[3][4]`, giving `["aa", "bb", "xtyz"]`.

Now `"aa"` and `"bb"` are palindromes.

## Input Format (custom testing)

```
n
arr[0]
...
arr[n-1]
```

## Approach

Swaps can move any character anywhere, so only the **global letter counts** matter.
- Total available pairs: `P = Σ_c ⌊cnt[c] / 2⌋`.
- A string of length `L` needs `⌊L/2⌋` pairs to be a palindrome. If `L` is odd it also needs one centre character, and any leftover character can serve as that centre.
- Greedily make the **shortest** strings palindromes first. Sort the lengths in ascending order and subtract `⌊L/2⌋` from `P` while it stays non-negative. The number of strings handled this way is the answer.

**Complexity:** `O(total length + n log n)`.

# Minimize Path Value (Least Stressful Path)

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2024 (MathWorks OA, NIT Durgapur) · **Source:** `m/Mathworks/Mathworks/MathworksPYQ/Minimise path stress*.jpg`

## Problem

There is a weighted undirected graph with `N` nodes and `M` edges. The **stress level** of a path between two nodes is the weight of the heaviest edge on that path. Given a `source` node and a `destination` node, find a path with the **minimum stress level**. If no path exists, report **-1**.

## Function Description

```cpp
int leastStressfulPath(int graph_nodes, vector<int> graph_from, vector<int> graph_to,
                       vector<int> graph_weight, int source, int destination);
```

**Parameters**
- `int graph_nodes`: the number of nodes
- `int graph_from[m]`: one end of each edge
- `int graph_to[m]`: the other end of each edge
- `int graph_weight[m]`: the weights of the edges
- `int source`: the source node
- `int destination`: the destination node

**Returns**
- `int`: the stress level of the least stressful path, or -1 if no path exists

**Note:** even though the endpoints are called `graph_from[i]` and `graph_to[i]`, the graph is undirected.

## Constraints

- `1 ≤ graph_nodes ≤ 10^5`
- `1 ≤ |graph_from| = |graph_to| = |graph_weight| ≤ 10^5`
- `1 ≤ graph_from[i], graph_to[i], source, destination ≤ graph_nodes`
- `0 ≤ graph_weight[i] ≤ 10^9`

## Example

```
source = 1, destination = 3
edges: 1-2 (100), 2-3 (200), 1-4 (10), 4-3 (20)
```
There are two paths from node 1 to node 3:
1. `1 → 2 → 3` has a heaviest edge (stress level) of 200.
2. `1 → 4 → 3` has a stress level of 20.

Return **20**, the lower stress level.

## Sample Case 0

```
Input:
5 6
1 2 10
2 3 5
1 4 3
4 3 2
1 5 4
5 3 6
1
3
Output:
3
```
There are three paths from node 1 to node 3:
- `1→2→3` has edges 10 and 5, so its stress level is 10.
- `1→4→3` has edges 3 and 2, so its stress level is **3**.
- `1→5→3` has edges 4 and 6, so its stress level is 6.

## Input Format (custom testing)

```
graph_nodes m
m lines: from to weight
source
destination
```

## Approach

This is a **minimax path** problem. Sort the edges by weight and add them one at a time to a **DSU** (union-find), as in Kruskal's algorithm. The first time `source` and `destination` end up in the same component, the weight of the edge just added is the answer. If that never happens, return -1. If `source == destination`, return 0.

(An alternative is a modified Dijkstra where the cost of a path is `max(dist[u], w)`.)

**Complexity:** `O(M log M)`.

#include <bits/stdc++.h>
using namespace std;

struct DSU {
    vector<int> p, r;
    DSU(int n) : p(n + 1), r(n + 1, 0) { iota(p.begin(), p.end(), 0); }
    int find(int x) { return p[x] == x ? x : p[x] = find(p[x]); }
    void unite(int a, int b) {
        a = find(a), b = find(b);
        if (a == b) return;
        if (r[a] < r[b]) swap(a, b);
        p[b] = a;
        if (r[a] == r[b]) r[a]++;
    }
};

// Kruskal-style: the first edge that connects source and destination is the answer
int leastStressfulPath(int graph_nodes, vector<int> graph_from, vector<int> graph_to,
                       vector<int> graph_weight, int source, int destination) {
    if (source == destination) return 0;
    int m = graph_from.size();
    vector<int> order(m);
    iota(order.begin(), order.end(), 0);
    sort(order.begin(), order.end(), [&](int a, int b) { return graph_weight[a] < graph_weight[b]; });

    DSU dsu(graph_nodes);
    for (int e : order) {
        dsu.unite(graph_from[e], graph_to[e]);
        if (dsu.find(source) == dsu.find(destination)) return graph_weight[e];
    }
    return -1;
}

int main() {
    int n, m;
    cin >> n >> m;
    vector<int> f(m), t(m), w(m);
    for (int i = 0; i < m; ++i) cin >> f[i] >> t[i] >> w[i];
    int s, d;
    cin >> s >> d;
    cout << leastStressfulPath(n, f, t, w, s, d) << "\n";
    return 0;
}

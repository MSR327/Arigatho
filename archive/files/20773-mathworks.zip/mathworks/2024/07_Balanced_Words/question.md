# Balanced Words

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2024 (MathWorks OA, NIT Durgapur) · **Source:** `m/Mathworks/Mathworks/MathworksPYQ/Balanced Words.jpg`

## Problem

A word processor produces random words of lowercase English letters, which can be used for data analysis, puzzles and so on. The **difference** between two characters `x` and `y` is the absolute difference between their positions in the alphabet. For example, the difference between `'a'` and `'z'` is 25, and the difference between `'f'` and `'c'` is 3.

A word is **balanced** if the difference between any two **adjacent** characters does not exceed `d`.

Given two integers `n` and `d`, find the number of balanced words of length `n` that the word processor can produce. The answer can be large, so return it modulo `10^9 + 7`.

## Function Description

```cpp
int countBalancedWords(int n, int d);
```

**Parameters**
- `int n`: the length of the word
- `int d`: the maximum allowed difference between adjacent characters

**Returns**
- `int`: the number of balanced words, modulo `10^9+7`

## Constraints (typical)

- `1 ≤ n ≤ 10^5`
- `0 ≤ d ≤ 25`

## Example

```
n = 2, d = 3
```

| Produced word | Balanced? | Remarks |
|---|---|---|
| "ad" | Yes | the difference between 'a' and 'd' is 3, which is ≤ 3 |
| "za" | No | the difference between 'z' and 'a' is 25, which is > 3 |
| "zx" | Yes | the difference between 'z' and 'x' is 2, which is ≤ 3 |
| "rk" | No | the difference between 'r' and 'k' is 7, which is > 3 |
| "yy" | Yes | the difference between 'y' and 'y' is 0, which is ≤ 3 |

Counting every pair: for each first letter `c`, the number of valid second letters is the number of letters within distance 3 of `c`. That is `4, 5, 6` for a, b, c, then `7` for each of d…w (20 letters), then `6, 5, 4` for x, y, z. The total is 4+5+6+140+6+5+4 = **170**.

```
Output: 170
```

## Input Format (custom testing)

```
n
d
```

## Approach

Let `dp[c]` be the number of balanced words of the current length that end in letter `c`.
- Length 1: `dp[c] = 1` for every `c`.
- Each extra letter: `new[c] = Σ dp[c']` over `|c − c'| ≤ d`. A prefix sum over the 26 letters gives each window sum in O(1).

The answer is `Σ dp[c]` after `n` letters.

**Complexity:** `O(26 · n)`.

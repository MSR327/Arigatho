#include <bits/stdc++.h>
using namespace std;

const long long MOD = 1e9 + 7;

int countBalancedWords(int n, int d) {
    vector<long long> dp(26, 1);
    for (int len = 2; len <= n; ++len) {
        vector<long long> pre(27, 0), nd(26);
        for (int c = 0; c < 26; ++c) pre[c + 1] = (pre[c] + dp[c]) % MOD;
        for (int c = 0; c < 26; ++c) {
            int lo = max(0, c - d), hi = min(25, c + d);
            nd[c] = (pre[hi + 1] - pre[lo] + MOD) % MOD;
        }
        dp = nd;
    }
    long long total = 0;
    for (long long v : dp) total = (total + v) % MOD;
    return total;
}

int main() {
    int n, d;
    cin >> n >> d;
    cout << countBalancedWords(n, d) << "\n";
    return 0;
}

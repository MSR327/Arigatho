#include <bits/stdc++.h>
using namespace std;

// b is the 2-D prefix sum of a
vector<vector<long long>> findMatrix(vector<vector<int>> a) {
    int n = a.size(), m = a[0].size();
    vector<vector<long long>> b(n, vector<long long>(m, 0));
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < m; ++j) {
            b[i][j] = a[i][j];
            if (i) b[i][j] += b[i - 1][j];
            if (j) b[i][j] += b[i][j - 1];
            if (i && j) b[i][j] -= b[i - 1][j - 1];
        }
    return b;
}

int main() {
    int n, m;
    cin >> n >> m;
    vector<vector<int>> a(n, vector<int>(m));
    for (auto &row : a)
        for (auto &v : row) cin >> v;
    for (auto &row : findMatrix(a)) {
        for (size_t j = 0; j < row.size(); ++j) cout << row[j] << (j + 1 < row.size() ? " " : "\n");
    }
    return 0;
}

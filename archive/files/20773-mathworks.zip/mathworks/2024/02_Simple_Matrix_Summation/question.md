# Simple Matrix Summation

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2024 (MathWorks OA, IIT Bombay, 12 Oct 2024) · **Source:** `m/Mathworks/Mathworks/IIT Bombay/coding/Screenshot from 2024-10-12 19-29-20 … 28.png`

## Problem

You are given an `n × m` matrix `a`, where `a(i, j)` is the value in the cell at row `i` and column `j`. Create another `n × m` matrix `b`, setting each `b(x, y)` (zero-based indexing) with the following algorithm:

```
s = 0;
for (i = 0; i <= x; i += 1) {
    for (j = 0; j <= y; j += 1) {
        s = s + a(i, j);
    }
}
b(x, y) = s;
```

The algorithm sets a single `b(x, y)` per execution, with `0 ≤ x < n` and `0 ≤ y < m`. Run it for every element of `b` and return the completed `n × m` matrix `b`.

## Function Description

```cpp
vector<vector<int>> findMatrix(vector<vector<int>> a);
```
(The C template is `int** findMatrix(int a_rows, int a_columns, int** a, int* result_rows, int* result_columns)`.)

**Parameters**
- `int a[n][m]`: a 2-dimensional array of integers

**Returns**
- `int[n][m]`: the computed 2-dimensional array `b`

## Constraints

- `1 ≤ n, m ≤ 10^3`
- `0 ≤ a(i, j) ≤ 10^3`

## Example

```
a = 1 2 3
    4 5 6
```

| b(x,y) | Equation | Value |
|---|---|---|
| b(0,0) | a(0,0) | 1 |
| b(0,1) | a(0,0)+a(0,1) | 3 |
| b(0,2) | a(0,0)+a(0,1)+a(0,2) | 6 |
| b(1,0) | a(0,0)+a(1,0) | 5 |
| b(1,1) | a(0,0)+a(0,1)+a(1,0)+a(1,1) | 12 |
| b(1,2) | everything | 21 |

```
b = 1  3  6
    5 12 21
```

## Sample Case 0

```
Input:
2
2
1 2
3 4
Output:
1 3
4 10
```

## Sample Case 1

```
Input:
3
3
1 2 3
4 5 6
7 8 9
Output:
1 3 6
5 12 21
12 27 45
```

## Input Format (custom testing)

```
n
m
n lines, each containing m integers
```

## Approach

`b` is the **2-D prefix sum** of `a`:

```
b[i][j] = a[i][j] + b[i-1][j] + b[i][j-1] − b[i-1][j-1]
```

Running the given algorithm directly would cost `O(n²m²)`, which is about 10^12 operations and too slow.

The largest value is `10^6 · 10^3 = 10^9`, which fits in `int`, but `long long` is used to be safe.

**Complexity:** `O(n·m)`.

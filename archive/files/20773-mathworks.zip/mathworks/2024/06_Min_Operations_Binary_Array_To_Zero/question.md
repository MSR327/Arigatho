# Minimum Operations to Make a Binary Array All Zero

**Tag:** `Platform not shown`. The statement was rebuilt from notes or a non-HackerRank screenshot.

**Year:** 2024 · **Source:** `m/Mathworks/Mathworks/channel/5_6105155625962968488.pdf` (Q4)

## Problem

You are given an array of `N` elements, each either `1` or `0`. You need to make every element `0` using the following operation:

- Pick an element that is `1` and change it to `0`. Then:
  - if the **next consecutive** element is `1`, it is automatically converted to `0`, and the effect keeps cascading to the right through consecutive 1s;
  - if the next consecutive element is already `0`, nothing more happens.

Find the **minimum number of operations** needed to make all elements `0`.

## Function Description

```cpp
int minOperations(vector<int> arr);
```

**Parameters**
- `int arr[N]`: an array of 0s and 1s

**Returns**
- `int`: the minimum number of operations

## Constraints (typical)

- `1 ≤ N ≤ 10^5`

## Example 1

```
arr = [1, 1, 0, 0, 1, 1, 1, 0, 0, 1]
Output: 3
```
The blocks of 1s are `[1,1]`, `[1,1,1]` and `[1]`. One operation on the first element of each block clears that block.

## Example 2

```
arr = [1, 1, 1, 1]
Output: 1
```

## Input Format (custom testing)

```
N
arr[0] ... arr[N-1]
```

## Approach

Starting an operation at the first `1` of a maximal block of consecutive 1s clears the whole block, and one operation can never clear two separate blocks. So the answer is the **number of maximal blocks of 1s**: count the indices `i` where `arr[i] == 1` and either `i == 0` or `arr[i-1] == 0`.

**Complexity:** `O(N)`.

#include <bits/stdc++.h>
using namespace std;

// one operation per maximal block of consecutive 1s
int minOperations(vector<int> arr) {
    int ops = 0;
    for (size_t i = 0; i < arr.size(); ++i)
        if (arr[i] == 1 && (i == 0 || arr[i - 1] == 0)) ops++;
    return ops;
}

int main() {
    int n;
    cin >> n;
    vector<int> arr(n);
    for (auto &v : arr) cin >> v;
    cout << minOperations(arr) << "\n";
    return 0;
}

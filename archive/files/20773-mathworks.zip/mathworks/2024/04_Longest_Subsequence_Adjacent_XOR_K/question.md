# Longest Subsequence with Adjacent XOR Equal to K

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2024 · **Source:** `m/Mathworks/Mathworks/channel/5_6105155625962968488.pdf` (Q2). The same question appears as "Bit xor subsequence" in `MathworksPYQ`.

## Problem

You are given an array `arr[]` of `N` non-negative integers and an integer `K`. Find the length of the **longest subsequence** in which the XOR of **every pair of adjacent elements** equals `K`.

## Function Description

```cpp
int longestXorSubsequence(vector<int> arr, int k);
```

**Parameters**
- `int arr[N]`: the array
- `int k`: the required XOR of adjacent elements

**Returns**
- `int`: the maximum length (a single element counts as length 1)

## Constraints (typical)

- `1 ≤ N ≤ 10^5`
- `0 ≤ arr[i], K ≤ 10^9`

## Example 1

```
N = 5, arr = [3, 2, 4, 3, 5], K = 1
Output: 3
```
The subsequences whose adjacent elements XOR to K are `{3, 2}`, `{2, 3}`, `{4, 5}` and `{3, 2, 3}`. The longest has length **3**.

## Example 2

```
N = 8, arr = [4, 5, 4, 7, 3, 5, 4, 6], K = 2
Output: 3
```
The subsequences whose adjacent elements XOR to K are `{4, 6}`, `{5, 7}`, `{7, 5}` and `{5, 7, 5}`. The longest has length **3**.

## Example 3 (HackerRank version "51. Bitwise XOR Subsequences", function `maxSubsequenceLength(n, arr, k)`)

```
n = 5, arr = [2, 1, 3, 5, 2], k = 2
Output: 2
```
`[1, 3]` is valid because 1 XOR 3 = 2. `[2, 1, 3]` is not valid because 2 XOR 1 ≠ 2. Any subsequence of length 1 is always valid.

## Input Format (custom testing)

```
N K
arr[0] ... arr[N-1]
```

## Approach

`dp[i]` is the longest valid subsequence that ends at `arr[i]`. Its previous element must have the value `arr[i] ^ K`, so:

```
dp[i] = 1 + best[arr[i] ^ K]       (best[v] = max dp ending with value v so far)
best[arr[i]] = max(best[arr[i]], dp[i])
```

Use a hash map for `best`. The answer is `max dp[i]`.

**Complexity:** `O(N)` expected.

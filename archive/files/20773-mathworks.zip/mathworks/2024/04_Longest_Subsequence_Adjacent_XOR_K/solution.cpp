#include <bits/stdc++.h>
using namespace std;

int longestXorSubsequence(vector<int> arr, int k) {
    unordered_map<int, int> best;  // best length of a subsequence ending with value v
    int ans = 0;
    for (int v : arr) {
        auto it = best.find(v ^ k);
        int cur = 1 + (it == best.end() ? 0 : it->second);
        best[v] = max(best[v], cur);
        ans = max(ans, cur);
    }
    return ans;
}

int main() {
    int n, k;
    cin >> n >> k;
    vector<int> arr(n);
    for (auto &v : arr) cin >> v;
    cout << longestXorSubsequence(arr, k) << "\n";
    return 0;
}

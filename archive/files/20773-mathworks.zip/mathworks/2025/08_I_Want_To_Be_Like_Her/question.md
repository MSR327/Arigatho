# I Want to Be Like Her (minimumMoves)

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2025 (MathWorks OA, 19 Aug 2025). It was also asked in 2023. · **Source:** `Mathwork 1/OA set 1 19 aug/IMG-20250819-WA0146–0151, 0154, 0157, 0159.jpg`, `m3/Mathworks/8 I Want to be like her/`

## Problem

Alexis and Mlexis are sisters, and Alexis is the younger one. Their parents gave each of them a box with `n` integers. Alexis always looked up to her sister and wanted her box of numbers to be the same as hers.

Alexis's box is the array `a`, with elements `a_i`, and Mlexis's box is the array `m`, with elements `m_i`. In **one move**, Alexis can increase or decrease a **single digit** of one integer in her array by 1. For example, if `a_i = 143` and `m_i = 333`, it takes Alexis 3 moves: `143 → 243 → 343 → 333`.

Return the **minimum number of moves** Alexis needs to convert each `a_i` into `m_i` (for `0 ≤ i < n`) so that array `a` matches array `m`.

## Function Description

```cpp
int minimumMoves(vector<int> a, vector<int> m);
```

**Parameters**
- `int a[n]`: Alexis's array
- `int m[n]`: Mlexis's array

**Returns**
- `int`: the minimum number of moves

## Constraints

- `1 ≤ n ≤ 10^5`
- `1 ≤ a_i, m_i ≤ 10^9`
- For every `i`, `a_i` and `m_i` have the **same number of digits**.

## Input Format

```
n
a[0]
...
a[n-1]
n
m[0]
...
m[n-1]
```

## Sample Input 0

```
2
1234
4321
2
2345
3214
```

## Sample Output 0

```
10
```

## Explanation 0

Here `a = [1234, 4321]` and `m = [2345, 3214]`.

- `a_0 → m_0` takes 4 moves:
  1. Increment the first digit: `1234 → 2234`
  2. Increment the second digit: `2234 → 2334`
  3. Increment the third digit: `2334 → 2344`
  4. Increment the fourth digit: `2344 → 2345`
- `a_1 → m_1` takes 6 moves:
  1. Decrement the first digit: `4321 → 3321`
  2. Decrement the second digit: `3321 → 3221`
  3. Decrement the third digit: `3221 → 3211`
  4. Increment the fourth digit three times: `3211 → 3212 → 3213 → 3214`

The total is `4 + 6 =` **10**.

## Approach

Each digit changes independently and there is no wraparound (9 → 0 is not one move). So the cost for each pair is `Σ |digit_a − digit_m|` over matching digit positions. Peel off digits with `% 10` and `/ 10`.

The answer can be as large as `10^5 · 9 · 9 ≈ 8.1·10^6`, so it fits in an `int`.

**Complexity:** `O(n · digits)`.

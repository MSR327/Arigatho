#include <bits/stdc++.h>
using namespace std;

int minimumMoves(vector<int> a, vector<int> m) {
    int moves = 0;
    for (size_t i = 0; i < a.size(); ++i) {
        int x = a[i], y = m[i];
        while (x > 0 || y > 0) {
            moves += abs(x % 10 - y % 10);
            x /= 10;
            y /= 10;
        }
    }
    return moves;
}

int main() {
    int n;
    cin >> n;
    vector<int> a(n);
    for (auto &v : a) cin >> v;
    cin >> n;
    vector<int> m(n);
    for (auto &v : m) cin >> v;
    cout << minimumMoves(a, m) << "\n";
    return 0;
}

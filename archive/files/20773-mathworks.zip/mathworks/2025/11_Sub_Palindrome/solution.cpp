#include <bits/stdc++.h>
using namespace std;

// Palindromic tree (Eertree): one node per distinct palindromic substring.
int palindrome(string s) {
    int n = s.size();
    vector<array<int, 26>> next(n + 2);
    vector<int> len(n + 2), link(n + 2);
    for (auto &a : next) a.fill(0);
    // node 0: imaginary root (len -1), node 1: empty root (len 0)
    len[0] = -1, link[0] = 0;
    len[1] = 0, link[1] = 0;
    int nodes = 2, last = 1;

    for (int i = 0; i < n; ++i) {
        int c = s[i] - 'a';
        int cur = last;
        while (true) {
            int l = len[cur];
            if (i - l - 1 >= 0 && s[i - l - 1] == s[i]) break;
            cur = link[cur];
        }
        if (next[cur][c]) { last = next[cur][c]; continue; }

        int node = nodes++;
        len[node] = len[cur] + 2;
        if (len[node] == 1) {
            link[node] = 1;
        } else {
            int p = link[cur];
            while (true) {
                int l = len[p];
                if (i - l - 1 >= 0 && s[i - l - 1] == s[i]) break;
                p = link[p];
            }
            link[node] = next[p][c];
        }
        next[cur][c] = node;
        last = node;
    }
    return nodes - 2;
}

int main() {
    string s;
    getline(cin, s);
    cout << palindrome(s) << "\n";
    return 0;
}

# Sub-Palindrome (Count Distinct Palindromic Substrings)

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2025 (MathWorks OA, 7 Oct 2025) · **Source:** `mathworks.pdf` (pages 17, 43, 44, 54, 55)

## Problem

A palindrome is a string that reads the same forwards and backwards, such as `121` or `tacocat`. A substring is a contiguous sequence of characters within a string.

Given a string `s`, how many **unique** substrings of `s` are palindromes?

## Function Description

```cpp
int palindrome(string s);
```

**Parameters**
- `string s`: a string

**Returns**
- `int`: the number of distinct palindromes

## Constraints

- `1 ≤ |s| ≤ 5000`
- Each character `s[i]` is in the range `ascii[a-z]`

## Example

```
s = "mokkori"
```
Some of its substrings are `[m, o, k, r, i, mo, ok, mok, okk, kk, okko]`. There are **7** distinct palindromes: `[m, o, k, r, i, kk, okko]`.

## Sample Case 0

```
Input:  aabaa
Output: 5
```
The palindromic substrings are `['a', 'aa', 'aabaa', 'aba', 'b']`. The substring `'a'` occurs 4 times but is counted once. Likewise `'aa'` occurs twice but counts as one distinct palindrome. That gives **5**.

## Sample Case 1

```
Input:  abcddcbabcdcdaadcdcbabcdddcb
Output: 27
```
The distinct palindromes are: `a, b, c, d, aa, dd, cddc, bab, cbabc, abcddcba, bcddcb, dcbabcd, cdc, dcd, ddd, cdddc, bcdddcb, daad, cdaadc, dcdaadcd, cdcdaadcdc, bcdcdaadcdcb, abcdcdaadcdcba, babcdcdaadcdcbab, cbabcdcdaadcdcbabc, dcbabcdcdaadcdcbabcd, ddcbabcdcdaadcdcbabcdd`.

## Input Format (custom testing)

```
s
```

## Approach

**Palindromic tree (Eertree)**, in `O(n)`. A string of length `n` has at most `n` distinct palindromic substrings, and each new character adds at most one new one. The Eertree keeps one node per distinct palindrome:
- two roots, one of length −1 and one of length 0
- for each node, its suffix link (the longest proper palindromic suffix) and its transitions by character

When character `s[i]` is appended, follow suffix links from the last node until you reach a palindrome `X` with `s[i − len(X) − 1] == s[i]`. If `cXc` doesn't exist yet, create it. The answer is the number of nodes created.

**Alternative (also passes for n ≤ 5000):** expand around each center (`O(n²)` palindromes) and insert each one's rolling hash into a set.

**Complexity:** `O(n · σ)` with σ = 26.

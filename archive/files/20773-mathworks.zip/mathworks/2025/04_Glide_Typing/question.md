# Glide Typing

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2025 (MathWorks OA, Aug 2025) · **Source:** `m4/.../IMG-20250802-WA0029.jpg`

## Problem

You are building a basic prototype of glide typing: the user swipes a finger from key to key, and the service detects the word they meant. A user usually intends to type a **subsequence** of the characters they swiped over.

Given an input string `s` and an array of `n` strings, `dictionary`, find the **lexicographically smallest** word in the dictionary that is a **subsequence** of `s`. If no such word exists, return the string `"-1"`.

**Note:** a string `x` is lexicographically smaller than a string `y` if `x` would appear before `y` in dictionary order.

## Function Description

```cpp
string getValidWord(string s, vector<string> dictionary);
```

**Parameters**
- `string s`: the string given by the user
- `string dictionary[n]`: the list of valid words

**Returns**
- `string`: the lexicographically smallest valid word, or `"-1"`

## Constraints (typical)

- `1 ≤ |s| ≤ 10^5`
- `1 ≤ n ≤ 10^4`, and the total length of the dictionary is at most `10^5`
- lowercase English letters only

## Example

```
s = "hgferyjkllkop"
dictionary = ["coffee", "coding", "happy", "hello", "hop"]
```
The only words that are subsequences of `s` are `"hello"` and `"hop"`. `"hello"` is lexicographically smaller.

```
Output: hello
```

## Sample Case 0 (from the 2024 OA, `MathworksPYQ/Mathworks1-2.jpeg`)

```
Input:
ocbms
5
rdnothix
obms
qhlrpiaiv
ms
jaupx
Output:
ms
```
The valid subsequence words are `"ms"` and `"obms"`, and `"ms"` is smaller.

Constraints from the 2024 version: `1 ≤ |s| ≤ 20`, `1 ≤ n ≤ 10^5`, `1 ≤ |word[i]| ≤ 20`.

> This question was also asked in **2024**, and Cool Graph (2025/01) was also asked in 2024.

## Input Format (custom testing)

```
s
n
dictionary[0]
...
dictionary[n-1]
```

## Approach

For each word, check whether it is a subsequence of `s` with a two-pointer scan. Among the words that pass, keep the smallest.

To handle big inputs faster, precompute `next[i][c]`, the first position `≥ i` where character `c` appears in `s`. Each word can then be checked in `O(|word|)`.

**Complexity:** `O(n · |s|)` for the simple version, or `O(26|s| + Σ|word|)` with the `next` table (the version implemented).

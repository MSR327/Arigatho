#include <bits/stdc++.h>
using namespace std;

string getValidWord(string s, vector<string> dictionary) {
    int n = s.size();
    // nxt[i][c] = first index >= i where s[index] == c, or n if none
    vector<array<int, 26>> nxt(n + 1);
    nxt[n].fill(n);
    for (int i = n - 1; i >= 0; --i) {
        nxt[i] = nxt[i + 1];
        nxt[i][s[i] - 'a'] = i;
    }

    string best = "";
    bool found = false;
    for (auto &w : dictionary) {
        int pos = 0;
        bool ok = true;
        for (char c : w) {
            if (pos > n || nxt[pos][c - 'a'] == n) { ok = false; break; }
            pos = nxt[pos][c - 'a'] + 1;
        }
        if (ok && (!found || w < best)) best = w, found = true;
    }
    return found ? best : "-1";
}

int main() {
    string s;
    int n;
    cin >> s >> n;
    vector<string> dict(n);
    for (auto &w : dict) cin >> w;
    cout << getValidWord(s, dict) << "\n";
    return 0;
}

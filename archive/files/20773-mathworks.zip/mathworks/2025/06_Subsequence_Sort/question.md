# Subsequence Sort (checkStrings)

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2025 (MathWorks OA, Aug 2025) · **Source:** `m4/.../IMG-20250802-WA0017, 0035, 0036, 0038, 0039, 0047, 0050–0053.jpg`

## Problem

You are given a binary string `binary` made only of the characters `'0'` and `'1'`. You may perform the following operation **0 or more times**:

- Choose any subsequence, sort it, and replace the original subsequence with the sorted sequence.

You are also given an array of strings `arr` of length `n`. Each string has length `|binary|` and consists of the characters `'0'`, `'1'` and `'?'`, where each `'?'` can be replaced by either `'0'` or `'1'`.

For each string in `arr`, decide whether, after replacing every `'?'` with `'0'` or `'1'`, it is possible to rearrange `binary` with the operation above so that it equals that string. Store `"YES"` if it is possible and `"NO"` otherwise, both without quotes.

**Note:**
- A string `a` is a subsequence of a string `b` if `a` can be obtained by deleting some characters of `b` (possibly zero or all) without changing the order of the remaining characters.
- Each computation is independent of the others: `binary` is back in its original state at the start of each array element.

## Function Description

```cpp
vector<string> checkStrings(string binary, vector<string> arr);
```

**Parameters**
- `string binary`: the string to alter
- `string arr[n]`: the strings to match

**Returns**
- `string[n]`: each `i`-th string is `"YES"` or `"NO"` and relates to the `i`-th element of `arr`

## Constraints

- `1 ≤ |binary| ≤ 3000`
- `1 ≤ n ≤ 3000`
- `|arr[i]| = |binary|`
- `binary` contains only `'0'` and `'1'`; each `arr[i]` contains only `'0'`, `'1'` and `'?'`

## Example

```
binary = "110100", arr = ["?110?1", "111???"]
```
- `arr[0] = "?110?1"` can become `"011001"`, which can be reached from `binary`:
  - Sort the subsequence at indices `{0, 2}`: binary becomes `"011100"`.
  - Sort the subsequence at indices `{3, 4, 5}`: binary becomes `"011001"`, which equals `arr[0]`. The answer is `"YES"`.
- `binary` cannot be turned into any version of `arr[1]`, so the answer is `"NO"`.

```
Output: ["YES", "NO"]
```

## Sample Case 0

```
Input:
101011
2
???111
001101
Output:
YES
NO
```
`arr[0]` can become `"100111"`: sort indices `{2, 3}` of `binary`. Choosing `"001111"` also works.
`arr[1]` has only three 1s while `binary` has four, so it is impossible.

## Sample Case 1

```
Input:
0011
3
0?10
0011
????
Output:
NO
YES
YES
```
`arr[0]` could be `"0010"` or `"0110"`, and neither can be obtained from `binary`.

## Input Format (custom testing)

```
binary
n
arr[0]
...
arr[n-1]
```

## Approach

**What the operation can do.** Sorting a subsequence of a binary string moves 1s **to the right** and 0s **to the left**, and it can never move a 1 to the left. A target `t` can be reached from `b` **if and only if**:
1. `t` has the same number of 1s as `b`, and
2. for every prefix length `p`, `ones_t(p) ≤ ones_b(p)`. Every 1 in `t` must come from a 1 at or before that position in `b`.

The condition is also sufficient: match the 1s in order and sort each pair (`b`'s 1 … `t`'s position) to slide it right.

**Filling the `'?'`.** Let `K = ones(b) − (fixed 1s in t)`. If `K < 0` or `K > #'?'`, the answer is `NO`. Otherwise, turn the **rightmost `K`** question marks into 1s. Putting 1s as late as possible keeps every prefix count as small as possible, which is the best way to satisfy condition 2. Then check the prefix condition.

**Complexity:** `O(n · |binary|)`, about 9 million operations.

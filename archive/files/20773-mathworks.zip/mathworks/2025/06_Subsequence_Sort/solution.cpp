#include <bits/stdc++.h>
using namespace std;

// Sorting subsequences only moves 1s rightwards, so t is reachable from b iff
// both have the same number of 1s and every prefix of t has <= as many 1s as b.
vector<string> checkStrings(string binary, vector<string> arr) {
    int L = binary.size();
    int onesB = count(binary.begin(), binary.end(), '1');
    vector<string> res;
    for (string t : arr) {
        int fixedOnes = count(t.begin(), t.end(), '1');
        int q = count(t.begin(), t.end(), '?');
        int need = onesB - fixedOnes;
        if (need < 0 || need > q) { res.push_back("NO"); continue; }

        // rightmost `need` question marks become 1, the rest 0
        for (int i = L - 1; i >= 0; --i)
            if (t[i] == '?') t[i] = need-- > 0 ? '1' : '0';

        int pb = 0, pt = 0;
        bool ok = true;
        for (int i = 0; i < L && ok; ++i) {
            pb += binary[i] == '1';
            pt += t[i] == '1';
            if (pt > pb) ok = false;
        }
        res.push_back(ok ? "YES" : "NO");
    }
    return res;
}

int main() {
    string binary;
    int n;
    cin >> binary >> n;
    vector<string> arr(n);
    for (auto &s : arr) cin >> s;
    for (auto &s : checkStrings(binary, arr)) cout << s << "\n";
    return 0;
}

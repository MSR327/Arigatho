# Cool Graph

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2025 (MathWorks OA, Aug 2025) · **Source:** `m4/Mathworks OA 2025/IMG-20250802-WA0006, 0008, 0009, 0011, 0014.jpg`

## Problem

You are given an undirected **connected** graph with `g_nodes` nodes and `M` connections. Traverse all of the nodes at least once and store the order of traversal in array `A`. Then build array `B` with the following algorithm:

```cpp
for (int i = 0; i < A.size(); i++) {
    bool found = 0;
    for (int j = 0; j < B.size(); j++) {
        if (A[i] == B[j]) {
            found = 1;
            break;
        }
    }
    if (!found) {
        B.push_back(A[i]);
    }
}
```

In other words, `B` lists the nodes in the order they are **first visited**.

Choose the traversal `A` that produces the **lexicographically largest** array `B`. Return the resulting array `B`.

## Function Description

```cpp
vector<int> coolGraph(int g_nodes, vector<int> g_from, vector<int> g_to);
```

**Parameters**
- `int g_nodes`: the number of nodes
- `int g_from[M]`: one end of each connected pair of nodes
- `int g_to[M]`: the other end of each connected pair of nodes

**Returns**
- `int[]`: the array `B`

## Constraints

- `1 ≤ g_nodes ≤ 10^5`
- `1 ≤ M ≤ 2·10^5`
- `1 ≤ g_from[i], g_to[i] ≤ 2·10^5`
- `g_from[i] ≠ g_to[i]`

## Example

```
g_nodes = 5, M = 5
g_from = [4, 5, 1, 4, 3]
g_to   = [5, 1, 4, 3, 2]
edges: (4,5), (5,1), (1,4), (4,3), (3,2)
```

The optimal traversal is `5 → 4 → 3 → 2 → 3 → 4 → 1`, so `A = [5, 4, 3, 2, 3, 4, 1]`.
Applying the algorithm gives `B = [5, 4, 3, 2, 1]`, which is the largest possible.

## Sample Case 0

```
Input:
3 2
3 1
3 2
Output:
3 2 1
```
`g_nodes = 3`, edges `(3,1)` and `(3,2)`.

## Sample Case 1

```
Input:
4 5
1 2
2 3
3 4
2 4
1 4
Output:
4 3 2 1
```
Traversal `4 → 3 → 2 → 1`, so `A = [4,3,2,1]` and `B = [4,3,2,1]`.

## Input Format (custom testing)

```
g_nodes M
g_from[0] g_to[0]
...
g_from[M-1] g_to[M-1]
```

## Approach

Revisiting nodes is free, so after visiting any set of nodes we can walk back to any of them. The next **new** node can therefore be **any unvisited node adjacent to the visited set**.

To make `B` lexicographically largest:
1. Start at the **largest** node `g_nodes`.
2. Repeatedly visit the **largest** frontier node. This is a "max-priority BFS" (Prim-style) using a max-heap.

Each choice is greedy-optimal, because the first position where two `B` arrays differ decides the comparison.

**Complexity:** `O((N + M) log N)`.

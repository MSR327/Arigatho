#include <bits/stdc++.h>
using namespace std;

// Max-priority BFS: always step to the largest unvisited node adjacent to the visited set.
vector<int> coolGraph(int g_nodes, vector<int> g_from, vector<int> g_to) {
    int maxNode = g_nodes;
    for (size_t i = 0; i < g_from.size(); ++i) maxNode = max({maxNode, g_from[i], g_to[i]});
    vector<vector<int>> adj(maxNode + 1);
    for (size_t i = 0; i < g_from.size(); ++i) {
        adj[g_from[i]].push_back(g_to[i]);
        adj[g_to[i]].push_back(g_from[i]);
    }

    vector<bool> seen(maxNode + 1, false);
    priority_queue<int> pq;
    pq.push(g_nodes);
    seen[g_nodes] = true;
    vector<int> B;
    while (!pq.empty()) {
        int u = pq.top();
        pq.pop();
        B.push_back(u);
        for (int v : adj[u])
            if (!seen[v]) seen[v] = true, pq.push(v);
    }
    return B;
}

int main() {
    int n, m;
    cin >> n >> m;
    vector<int> f(m), t(m);
    for (int i = 0; i < m; ++i) cin >> f[i] >> t[i];
    for (int v : coolGraph(n, f, t)) cout << v << " ";
    cout << "\n";
    return 0;
}

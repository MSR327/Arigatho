#include <bits/stdc++.h>
using namespace std;

vector<int> findRemainingBalls(vector<int> direction, vector<int> strength) {
    vector<int> st;
    for (int i = 0; i < (int)direction.size(); ++i) {
        if (direction[i] == 1) { st.push_back(i); continue; }
        bool alive = true;
        while (alive && !st.empty() && direction[st.back()] == 1) {
            int top = st.back();
            if (strength[top] < strength[i]) st.pop_back();
            else if (strength[top] == strength[i]) st.pop_back(), alive = false;
            else alive = false;
        }
        if (alive) st.push_back(i);
    }
    return st;
}

int main() {
    int n;
    cin >> n;
    vector<int> d(n), s(n);
    for (auto &v : d) cin >> v;
    cin >> n;
    for (auto &v : s) cin >> v;
    for (int v : findRemainingBalls(d, s)) cout << v << "\n";
    return 0;
}

# Ball Collision

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2025 (MathWorks OA, Aug 2025) · **Source:** `m4/.../IMG-20250802-WA0049, 0054, 0055.jpg`

## Problem

There are `n` balls on a 1-dimensional axis, all moving with the same non-zero speed. `direction[i]` is the direction of the `i`-th ball: `-1` means it moves **left** and `1` means it moves **right**. The strength of the `i`-th ball is `strength[i]`.

When 2 balls collide, the one with **higher strength destroys** the weaker one. If they have the **same strength, both are destroyed**.

Return a list of the indices of the balls that remain after all collisions, in **ascending order**.

The arrays `direction` and `strength` are 0-indexed, and the balls are listed in order of position from left to right.

## Function Description

```cpp
vector<int> findRemainingBalls(vector<int> direction, vector<int> strength);
```

**Parameters**
- `int direction[n]`: the direction of each ball, in order of starting position
- `int strength[n]`: the strength of each ball

**Returns**
- `int[]`: the indices of the remaining balls, in ascending order

## Constraints

- `1 ≤ n ≤ 10^5`
- `direction[i]` is either `1` or `-1`
- `1 ≤ strength[i] ≤ 10^9`

## Example

```
direction = [1, -1], strength = [2, 1]
```
Ball 0 is to the left of ball 1. Ball 0 moves right and ball 1 moves left, so they collide. Ball 0 is stronger and remains.

```
Output: [0]
```

## Sample Case 0

```
Input:
3
1
-1
1
3
5
3
1
Output:
0
2
```
Balls 0 and 2 move right and ball 1 moves left. Balls 0 and 1 collide and ball 0, the stronger one, remains. Ball 2 never collides with anything.

## Input Format (custom testing)

```
n
direction[0] ... direction[n-1]     (one per line)
n
strength[0] ... strength[n-1]       (one per line)
```

## Approach

This is the classic **stack** solution to LeetCode 735, "Asteroid Collision". Scan from left to right, keeping a stack of surviving ball indices:

- A **right-moving** ball is pushed onto the stack.
- A **left-moving** ball fights the right-movers on top of the stack:
  - If the top is weaker, pop it and keep fighting.
  - If they are equal, pop it and destroy the current ball as well.
  - If the top is stronger, the current ball is destroyed.
  - If it survives every fight, which happens when the stack is empty or its top moves left, push it.

The stack is already in ascending index order.

**Complexity:** `O(n)`.

# Slow and Fast Pointers (dualSpeed)

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2025 (MathWorks OA, Aug 2025). It was also asked in 2023. · **Source:** `m4/.../IMG-20250802-WA0025–0028.jpg`, `m3/Mathworks/13 Slow & Fast Pointers/`

## Problem

Process an array `arr` using two pointers, `P1` and `P2`, and an integer `segSize`.

Pick a value to test for `segSize`, then start with `P1 = 0` and `P2 = 1`. Compare the value at `arr[P1]` with every element of a subarray. The subarray starts at `arr[P2]` and contains `segSize` elements, or fewer if it reaches the end of `arr`.

If `arr[P1]` is **greater than or equal to** all of them, increment `P1` by 1, increment `P2` by `segSize`, and repeat. Continue until the subarray that contains the last element of `arr` has been processed.

Determine the **minimum value of `segSize`** that lets the entire array be processed. Return this minimum value, or **-1** if no value works.

## Function Description

```cpp
int dualSpeed(vector<int> arr);
```

**Parameters**
- `int arr[n]`: an array of integers

**Returns**
- `int`: the minimum `segSize`, or -1

## Constraints

- `1 < n ≤ 5000`
- `1 ≤ arr[i] ≤ 10^9`

## Example

```
arr = [11, 9, 10, 8, 10, 9]
```

| segSize | P1 | P2 | arr[P1] | subarray | continue? |
|---|---|---|---|---|---|
| 1 | 0 | 1 | 11 | [9] | y |
|   | 1 | 2 | 9 | [10] | **n** (10 > 9) |
| 2 | 0 | 1 | 11 | [9, 10] | y |
|   | 1 | 3 | 9 | [8, 10] | **n** (10 > 9) |
| 3 | 0 | 1 | 11 | [9, 10, 8] | y |
|   | 1 | 4 | 9 | [10, 9] | **n** (10 > 9) |
| 4 | 0 | 1 | 11 | [9, 10, 8, 10] | y |
|   | 1 | 5 | 9 | [9] | y |

All elements were processed, so the minimum `segSize` is **4**.

```
Output: 4
```

## Sample Case 0

```
Input:
7
11
9
7
7
7
6
5
Output:
1
```
The array is in non-increasing order, so a `segSize` of 1 works.

## Sample Case 1

```
Input:
7
13
6
6
1
3
3
5
Output:
2
```
- `segSize = 1`: P1=0 (13) vs [6] y · P1=1 (6) vs [6] y · P1=2 (6) vs [1] y · P1=3 (1) vs [3] **n** (3 > 1)
- `segSize = 2`: P1=0 (13) vs [6, 6] y · P1=1 (6) vs [1, 3] y · P1=2 (6) vs [3, 5] y. All elements are processed, so the answer is **2**.

> Note: P1 always moves by **1**, not by segSize. Several candidates in the Oct 2025 photos used `p1 += segSize` and failed hidden tests (6/15 passed).

## Input Format (custom testing)

```
n
arr[0] ... arr[n-1]
```

## Approach

Try every `segSize` from 1 to `n−1`, which always reaches the end in one step. For a fixed `segSize`, simulate the process: check that every block `arr[P2 .. P2+segSize−1]` has all values ≤ `arr[P1]`. One simulation touches each element at most once, so it costs `O(n)`. The first `segSize` that succeeds is the answer. If even `n−1` fails (because `arr[0]` is smaller than something after it), return `-1`.

**Complexity:** `O(n²)`, about 25 million operations for `n = 5000`, which is fine.

#include <bits/stdc++.h>
using namespace std;

int dualSpeed(vector<int> arr) {
    int n = arr.size();
    for (int seg = 1; seg < n; ++seg) {
        bool ok = true;
        int p1 = 0;
        for (int p2 = 1; p2 < n && ok; p2 += seg, ++p1) {
            int end = min(n, p2 + seg);
            for (int k = p2; k < end; ++k)
                if (arr[k] > arr[p1]) { ok = false; break; }
        }
        if (ok) return seg;
    }
    return -1;
}

int main() {
    int n;
    cin >> n;
    vector<int> arr(n);
    for (auto &v : arr) cin >> v;
    cout << dualSpeed(arr) << "\n";
    return 0;
}

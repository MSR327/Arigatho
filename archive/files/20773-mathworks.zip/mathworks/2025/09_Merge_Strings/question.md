# Merge Strings

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2025 (MathWorks OA, 19 Aug 2025) · **Source:** `Mathwork 1/OA set 1 19 aug/IMG-20250819-WA0156, 0158, 0160, 0161.jpg`

## Problem

Complete the `mergeStrings` function, which has 2 parameters: a string `a` and a string `b`. It must **merge** `a` and `b` and return a single merged string.

A merge works like this:
- Append characters from `a` and `b` alternately, starting with `a`, to a new string `mergedString`.
- Once all the characters of one string have been used, append the remaining characters of the other string to `mergedString`.

## Function Description

```cpp
string mergeStrings(string a, string b);
```

**Parameters**
- `string a`: the first string
- `string b`: the second string

**Returns**
- `string`: the merged string

## Input Format

The locked stub code reads two strings, `a` and `b`, from stdin and passes them to your function.

## Constraints

- `1 ≤ |a|, |b| ≤ 25000`

## Sample Input 1

```
abc
def
```

## Sample Output 1

```
adbecf
```

## Sample Input 2

```
ab
zsd
```

## Sample Output 2

```
azbsd
```

## Explanation

- Sample Case 1: `a = abc`, `b = def`. Taking characters from the two strings alternately gives `adbecf`.
- Sample Case 2: `a = ab`, `b = zsd`. Alternating gives `azbs`, then the leftover `d` is appended, giving `azbsd`.

## Approach

Use two pointers. While both strings still have characters, append `a[i]` then `b[i]`. After that, append whatever is left of the longer string. Reserve `|a| + |b|` characters up front.

**Complexity:** `O(|a| + |b|)`.

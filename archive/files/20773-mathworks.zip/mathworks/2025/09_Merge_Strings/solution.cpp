#include <bits/stdc++.h>
using namespace std;

string mergeStrings(string a, string b) {
    string res;
    res.reserve(a.size() + b.size());
    size_t i = 0;
    for (; i < a.size() && i < b.size(); ++i) {
        res += a[i];
        res += b[i];
    }
    res += a.substr(min(i, a.size()));
    res += b.substr(min(i, b.size()));
    return res;
}

int main() {
    string a, b;
    cin >> a >> b;
    cout << mergeStrings(a, b) << "\n";
    return 0;
}

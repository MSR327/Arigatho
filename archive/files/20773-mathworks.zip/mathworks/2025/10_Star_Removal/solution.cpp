#include <bits/stdc++.h>
using namespace std;

// Each '*' deletes the rightmost copy of the smallest letter to its left.
string starRemoval(string A) {
    int n = A.size();
    vector<vector<int>> pos(26);
    vector<bool> removed(n, false);
    for (int i = 0; i < n; ++i) {
        if (A[i] != '*') {
            pos[A[i] - 'a'].push_back(i);
            continue;
        }
        removed[i] = true;
        for (int c = 0; c < 26; ++c)
            if (!pos[c].empty()) {
                removed[pos[c].back()] = true;
                pos[c].pop_back();
                break;
            }
    }
    string res;
    for (int i = 0; i < n; ++i)
        if (!removed[i]) res += A[i];
    return res;
}

int main() {
    string A;
    cin >> A;
    cout << starRemoval(A) << "\n";
    return 0;
}

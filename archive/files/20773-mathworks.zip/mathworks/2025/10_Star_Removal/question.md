# Star Removal

**Tag:** `Platform not shown`. The statement was rebuilt from notes or a non-HackerRank screenshot.

**Year:** 2025 · **Source:** `Mathwork 1/OA set 1 19 aug/IMG-20250819-WA0152, 0153.jpg`. The screenshot's header reads "Selection Test 2025", so this question was probably shared alongside the MathWorks set. It is the same problem as LeetCode 3170.

## Problem

You are given a string `A` that may contain any number of `'*'` characters. Your task is to remove every `'*'`.

While there is a `'*'`, do the following operation:
- Delete the **leftmost** `'*'` and the **smallest** letter to its left. If several smallest letters tie, you may delete any one of them.

Return the **lexicographically smallest** string that can remain after all `'*'` characters have been removed.

## Function Description

```cpp
string starRemoval(string A);
```

**Parameters**
- `string A`: the input string

**Returns**
- `string`: the string after the removal operations

## Constraints

- `1 ≤ |A| ≤ 10^5`
- `A` consists only of lowercase English letters and `'*'`.
- The input is generated so that it is always possible to delete every `'*'`.

## Example Input / Output

| Input | Output |
|-------|--------|
| `A = "aaba*"` | `"aab"` |
| `A = "abc"` | `"abc"` |
| `A = "aab*d*zd*"` | `"dzd"` |

## Explanation

- `"aaba*"`: the smallest letter to the left of `*` is `'a'`. Deleting the **rightmost** `'a'` (index 3) leaves `"aab"`, which is the smallest possible result.
- `"abc"`: there are no stars, so nothing changes.
- `"aab*d*zd*"`:
  - The first `*` deletes an `'a'`, leaving `a b`.
  - The second `*` deletes the other `'a'`, leaving `b d`.
  - The last `*` deletes `'b'`, the smallest among `b d z d`. The result is `"dzd"`.

## Approach

**Which copy to delete.** When several equal smallest letters are candidates, always delete the **rightmost** one. Deleting a later copy keeps the earlier copy of the small letter near the front, and keeping small letters early gives a lexicographically smaller string.

**Implementation.** Keep 26 stacks of indices, one per letter. Scan from left to right:
- For a letter `c`, push its index onto `stack[c]`.
- For a `'*'`, find the smallest `c` whose stack is non-empty, pop its top (the rightmost occurrence) and mark that index as deleted.

Finally, output the letters that were not deleted, in their original order.

**Complexity:** `O(26 · n)`.

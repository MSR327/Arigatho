#include <bits/stdc++.h>
using namespace std;

int romanToInt(const string &r) {
    map<char, int> v = {{'I', 1}, {'V', 5}, {'X', 10}, {'L', 50}, {'C', 100}, {'D', 500}, {'M', 1000}};
    int total = 0;
    for (size_t i = 0; i < r.size(); ++i) {
        if (i + 1 < r.size() && v[r[i]] < v[r[i + 1]]) total -= v[r[i]];
        else total += v[r[i]];
    }
    return total;
}

vector<string> sortRoman(vector<string> names) {
    vector<tuple<string, int, string>> items;
    for (auto &s : names) {
        size_t sp = s.find(' ');
        items.push_back({s.substr(0, sp), romanToInt(s.substr(sp + 1)), s});
    }
    sort(items.begin(), items.end());
    vector<string> res;
    for (auto &t : items) res.push_back(get<2>(t));
    return res;
}

int main() {
    int n;
    cin >> n;
    cin.ignore();
    vector<string> names(n);
    for (auto &s : names) getline(cin, s);
    for (auto &s : sortRoman(names)) cout << s << "\n";
    return 0;
}

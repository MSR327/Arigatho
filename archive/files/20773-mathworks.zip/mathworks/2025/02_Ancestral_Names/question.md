# Ancestral Names (Sort by Name, then Roman Numeral)

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2025 (MathWorks OA, Aug 2025) · **Source:** `m4/.../IMG-20250802-WA0021, 0032, 0033.jpg`

## Problem

You are given a list of strings, each made of a **name** and a **Roman numeral**. Sort the list first by **name**, then by the **decimal value** of the Roman numeral.

In Roman numerals, a symbol is not repeated more than three times. Beyond that, a smaller value placed before a larger one means subtraction. For example, `I` is 1 and `V` is 5. The values 1 to 10 are formed like this:

- `I, II, III, IV, V, VI, VII, VIII, IX, X` represent 1 through 10.
- `XX, XXX, XL, L` are 20, 30, 40 and 50.
- Any other two-digit number below 50 is the numeral for its tens followed by the numeral for its units. For example, 43 is 40 + 3 = `'XL' + 'III'` = `'XLIII'`.

## Function Description

```cpp
vector<string> sortRoman(vector<string> names);
```

**Parameters**
- `string names[n]`: strings made of a name and a Roman numeral

**Returns**
- `string[n]`: the strings sorted first by given name, then by ordinal

## Constraints

- `1 ≤ n ≤ 50`
- Each `names[i]` consists of 2 space-separated values: `givenName` and `romanNumeral`.
- `romanNumeral` represents a number between 1 and 50, inclusive.
- `1 ≤ |givenName| ≤ 20`
- Each `givenName` starts with an uppercase letter `[A-Z]` followed by lowercase letters `[a-z]`.
- There is a space between `givenName` and `romanNumeral`.
- Each `names[i]` is distinct.

## Example

```
names = ['Steven XL', 'Steven XVI', 'David IX', 'Mary XV', 'Mary XIII', 'Mary XX']
```
In decimal and sorted, they are `['David 9', 'Mary 13', 'Mary 15', 'Mary 20', 'Steven 16', 'Steven 40']`.

```
Output: ['David IX', 'Mary XIII', 'Mary XV', 'Mary XX', 'Steven XVI', 'Steven XL']
```

## Input Format (custom testing)

```
n
names[0]
...
names[n-1]
```
Each line is a full `"Name ROMAN"` string.

## Approach

1. Split each string at the space into `(name, roman)`.
2. Convert the Roman numeral to an integer: scan from left to right, adding each symbol's value, but subtract it instead when the next symbol is larger (as in `IV`, `IX`, `XL`).
3. Sort with the key `(name, value)`. Plain string comparison of names is correct, because every name has the same capitalisation pattern.

**Complexity:** `O(n log n · L)`.

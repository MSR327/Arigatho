#include <bits/stdc++.h>
using namespace std;

vector<int> getCount(vector<int> arr) {
    int mx = *max_element(arr.begin(), arr.end());
    vector<long long> freq(mx + 1, 0), cnt(mx + 1, 0);
    for (int a : arr) freq[a]++;

    for (int d = 1; d <= mx; ++d) {
        if (!freq[d]) continue;
        cnt[d] += freq[d] - 1;  // other copies of the same value
        for (int m = 2 * d; m <= mx; m += d) {
            if (!freq[m]) continue;
            cnt[m] += freq[d];  // d divides m
            cnt[d] += freq[m];  // m is a multiple of d
        }
    }

    vector<int> res;
    for (int a : arr) res.push_back(cnt[a]);
    return res;
}

int main() {
    int n;
    cin >> n;
    vector<int> arr(n);
    for (auto &v : arr) cin >> v;
    for (int v : getCount(arr)) cout << v << "\n";
    return 0;
}

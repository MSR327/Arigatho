# Divisors and Multiples

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2025 (MathWorks OA, Aug 2025) · **Source:** `m4/.../IMG-20250802-WA0031, 0034, 0044, 0048, 0056.jpg`

## Problem

Given an array `arr` of length `n`, for each index `i` from 1 to `n`, count the indices `j` (with `j ≠ i`) such that **either** `arr[j]` is a divisor of `arr[i]` **or** `arr[j]` is a multiple of `arr[i]`.

**Note:**
- `x` is a **divisor** of `y` if `y` is divisible by `x`.
- `x` is a **multiple** of `y` if `x` is divisible by `y`.

## Function Description

```cpp
vector<int> getCount(vector<int> arr);
```
(The C template is `int* getCount(int arr_count, int* arr, int* result_count)`.)

**Parameters**
- `int arr[n]`: an array of integers

**Returns**
- `int[n]`: the answer for each index

## Constraints

- `1 ≤ n ≤ 10^5`
- `1 ≤ arr[i] ≤ 10^5`

## Example

```
arr = [1, 3, 4, 2, 6]
```
- i = 1 (value 1): divisors = 0, multiples = 4, so **4**
- i = 2 (value 3): divisors = 1 (the 1), multiples = 1 (the 6), so **2**
- i = 3 (value 4): divisors = 2 (1 and 2), multiples = 0, so **2**
- i = 4 (value 2): divisors = 1, multiples = 2 (4 and 6), so **3**
- i = 5 (value 6): divisors = 3 (1, 3 and 2), multiples = 0, so **3**

```
Output: [4, 2, 2, 3, 3]
```

## Sample Case 0

```
Input:
5
5
2
4
3
7
Output:
0
1
1
0
0
```
5, 3 and 7 have no divisors or multiples in the array. 2 and 4 each have one.

## Sample Case 1

```
Input:
4
2
4
8
16
Output:
3
3
3
3
```
Every element is a divisor or a multiple of every other element.

## Input Format (custom testing)

```
n
arr[0]
...
arr[n-1]
```

## Approach

`n` and the values are both up to `10^5`, so comparing every pair (`O(n²)`) is too slow. Use a **harmonic sieve** over the value range instead:

1. Build `freq[v]`, the number of times each value occurs.
2. For every value `d` with `freq[d] > 0`, visit its multiples `m = 2d, 3d, …, ≤ MAX`:
   - `cnt[m] += freq[d]`, because each copy of `d` is a divisor of `m`
   - `cnt[d] += freq[m]`, because each copy of `m` is a multiple of `d`
3. Equal values divide each other, so add `freq[v] − 1` to `cnt[v]` (the other copies). Each index is counted once even though it is both a divisor and a multiple.
4. The answer for index `i` is `cnt[arr[i]]`.

**Complexity:** `O(MAX log MAX + n)`.

#include <bits/stdc++.h>
using namespace std;

long long arrangements(int N) {
    vector<long long> dp(1 << N, 0);
    dp[0] = 1;
    for (int mask = 0; mask < (1 << N); ++mask) {
        if (!dp[mask]) continue;
        int pos = __builtin_popcount(mask) + 1;
        for (int x = 1; x <= N; ++x) {
            if (mask >> (x - 1) & 1) continue;
            if (x % pos == 0 || pos % x == 0) dp[mask | 1 << (x - 1)] += dp[mask];
        }
    }
    return dp[(1 << N) - 1];
}

int main() {
    int n;
    cin >> n;
    cout << arrangements(n) << "\n";
    return 0;
}

# Beautiful Arrangement

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2023 (MathWorks OA) · **Source:** `m3/Mathworks/11 Beautiful Arrangements/*.png`. It is the same problem as LeetCode 526.

## Problem

Julia has `N` numbers from `1` to `N`. An arrangement of those numbers is called **beautiful** if, for **every** position `i` (1-based), at least one of the following is true:

- The number at the `i`-th position is divisible by `i`.
- `i` is divisible by the number at the `i`-th position.

Return the number of possible beautiful arrangements.

## Function Description

```cpp
int arrangements(int N);
```

**Parameters**
- `int N`: the count of numbers

**Returns**
- `int`: the total number of beautiful arrangements

## Constraints

- `1 < N < 20`

## Input Format

The first line contains an integer `N`.

## Sample Input 1

```
2
```

## Sample Output 1

```
2
```

## Explanation 1

The beautiful arrangements for `N = 2` are `[1, 2]` and `[2, 1]`.
- In `[1, 2]`, position 1 holds 1, which is divisible by 1, and position 2 holds 2, which is divisible by 2.
- In `[2, 1]`, position 1 holds 2, which is divisible by 1, and position 2 holds 1, which divides 2.

## More values

| N | answer |
|---|---|
| 3 | 3 |
| 4 | 8 |
| 5 | 10 |
| 15 | 24679 |
| 19 | 449586 |

## Approach

Use a **bitmask DP**. `dp[mask]` is the number of ways to fill positions `1..popcount(mask)` with exactly the numbers in `mask`. To extend, let `pos = popcount(mask) + 1`, and for each unused number `x` with `x % pos == 0 || pos % x == 0`, add `dp[mask]` to `dp[mask | bit(x)]`. The answer is `dp[full]`.

**Complexity:** `O(2^N · N)`, about 10^7 for N = 19.

# Interesting Pairs of Numbers

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2023 (MathWorks OA, Oct 2023) · **Source:** `m3/Mathworks/12 Interesting Pair Of Numbers/*.png`

## Problem

A mathematics professor at a senior secondary school decides to evaluate students for the *Teachers Assessment* based on their problem-solving skills.

Given an array of integers `arr` and an integer `sumVal`, pair the elements of `arr` into **interesting pairs** and count them. An unordered pair `(i, j)` is **interesting** if

```
|arr[i] − arr[j]| + |arr[i] + arr[j]| = sumVal
```

In other words, the absolute difference plus the absolute sum of the two values equals `sumVal`. Find the number of interesting pairs in the array.

## Function Description

```cpp
long findInterestingPairs(vector<int> arr, int sumVal);
```

**Parameters**
- `int arr[n]`: an array of integers
- `int sumVal`: an integer

**Returns**
- `long`: the number of interesting pairs

## Constraints

- `1 ≤ n ≤ 10^5`
- `−10^6 ≤ arr[i] ≤ 10^6`
- `1 ≤ sumVal ≤ 10^6`

## Example

```
arr = [1, 4, -1, 2], sumVal = 4
```
There are two interesting pairs, `(1, 4)` and `(3, 4)` (1-based indices), because:
- `|arr1 − arr4| + |arr1 + arr4| = |1 − 2| + |1 + 2| = 4`
- `|arr3 − arr4| + |arr3 + arr4| = |−1 − 2| + |−1 + 2| = 4`

```
Output: 2
```

## Input Format (custom testing)

```
n
arr[0] ... arr[n-1]
sumVal
```

## Approach

**Key identity:** `|a − b| + |a + b| = 2 · max(|a|, |b|)`.

So a pair is interesting exactly when `max(|a|, |b|) = sumVal / 2`.
- If `sumVal` is odd, the answer is 0.
- Otherwise let `h = sumVal / 2`, `c` = the number of elements with `|x| == h`, and `l` = the number of elements with `|x| < h`. Then
```
answer = C(c, 2) + c · l
```

Check: `h = 2`, `c = 1` (the 2), `l = 2` (1 and −1), so the answer is 0 + 2 = **2** ✓

**Complexity:** `O(n)`.

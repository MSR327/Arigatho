#include <bits/stdc++.h>
using namespace std;

// |a-b| + |a+b| == 2 * max(|a|, |b|)
long long findInterestingPairs(vector<int> arr, int sumVal) {
    if (sumVal % 2) return 0;
    long long h = sumVal / 2, eq = 0, less = 0;
    for (int x : arr) {
        long long a = llabs(x);
        if (a == h) eq++;
        else if (a < h) less++;
    }
    return eq * (eq - 1) / 2 + eq * less;
}

int main() {
    int n;
    cin >> n;
    vector<int> arr(n);
    for (auto &v : arr) cin >> v;
    int s;
    cin >> s;
    cout << findInterestingPairs(arr, s) << "\n";
    return 0;
}

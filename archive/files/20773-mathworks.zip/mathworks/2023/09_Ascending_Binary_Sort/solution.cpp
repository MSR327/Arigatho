#include <bits/stdc++.h>
using namespace std;

vector<int> rearrange(vector<int> elements) {
    sort(elements.begin(), elements.end(), [](int a, int b) {
        int pa = __builtin_popcount(a), pb = __builtin_popcount(b);
        return pa != pb ? pa < pb : a < b;
    });
    return elements;
}

int main() {
    int n;
    cin >> n;
    vector<int> e(n);
    for (auto &v : e) cin >> v;
    for (int v : rearrange(e)) cout << v << "\n";
    return 0;
}

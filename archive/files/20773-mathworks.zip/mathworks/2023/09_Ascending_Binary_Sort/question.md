# Ascending Binary Sort

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2023 (MathWorks OA) · **Source:** `m3/Mathworks/10 Ascending Binary Sort/*.png`

## Problem

Consider an array of `n` decimal integers named `elements`. Rearrange `elements` according to the following rules:

- Sort the integers in ascending order by the **number of 1s in their binary representations**. For example, `7 → 111₂` and `8 → 1000₂`, so 8 (one 1 in binary) comes before 7 (three 1s).
- Integers with the same number of 1s are ordered by **increasing decimal value**. For example, `5 → 101₂` and `6 → 110₂` both contain two 1s, so 5 comes before 6 because it is smaller.

## Function Description

```cpp
vector<int> rearrange(vector<int> elements);
```

**Parameters**
- `int elements[n]`: the integers to sort

**Returns**
- `int[n]`: the sorted array

## Constraints

- `1 ≤ n ≤ 10^5`
- `1 ≤ elements[i] ≤ 10^9`

## Input Format

The first line contains an integer `n`. Each of the next `n` lines contains one integer of `elements`.

## Sample Input 0

```
3
1
2
3
```

## Sample Output 0

```
1
2
3
```

## Explanation 0

`1 → 1₂` and `2 → 10₂` each have one 1, so they are ordered by value: 1, 2. `3 → 11₂` has two 1s, so it comes last.

## Example 2

```
elements = [5, 3, 7, 10, 14]
popcounts:  2  2  3  2   3
Output:    [3, 5, 10, 7, 14]
```

## Approach

Sort with the key `(popcount(x), x)`, using `__builtin_popcount`.

**Complexity:** `O(n log n)`.

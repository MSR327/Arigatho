#include <bits/stdc++.h>
using namespace std;

int maxDifference(vector<int> a) {
    int best = -1, mn = a[0];
    for (size_t j = 1; j < a.size(); ++j) {
        if (a[j] > mn) best = max(best, a[j] - mn);
        mn = min(mn, a[j]);
    }
    return best;
}

int main() {
    int n;
    cin >> n;
    vector<int> a(n);
    for (auto &v : a) cin >> v;
    cout << maxDifference(a) << "\n";
    return 0;
}

# Maximum Difference in an Array

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2023 (MathWorks OA, 3 Oct 2023) · **Source:** `m3/Mathworks/4. Maximum Difference in an Array/4.jpeg`

## Problem

You are given an array of integers and must compute the maximum difference between any item and any **lower-indexed smaller** item, over all possible pairs. That is, for an array `a`, find the maximum value of `a[j] − a[i]` over all `i, j` with `0 ≤ i < j < n` and `a[i] < a[j]`. If no item has a lower-indexed smaller item, return **-1**.

For example, take `[1, 2, 6, 4]`. Compare 2 with the elements to its left: 1 is smaller, so the difference is 2 − 1 = 1. 6 is bigger than 2 and 1, giving differences 4 and 5. 4 is bigger than only 2 and 1, giving differences 2 and 3. The largest difference is 6 − 1 = **5**.

## Function Description

```cpp
int maxDifference(vector<int> a);
```

**Parameters**
- `int a[n]`: an array of integers

**Returns**
- `int`: the maximum difference, or -1

## Constraints

- `1 ≤ n ≤ 2·10^5`
- `−10^6 ≤ a[i] ≤ 10^6`

## Example

```
a = [1, 2, 6, 4]   → 5
a = [5, 4, 3]      → -1
a = [7, 9, 5, 6, 3, 2] → 2
```

## Input Format (custom testing)

```
n
a[0] ... a[n-1]
```

## Approach

Scan from left to right while tracking the minimum of the prefix seen so far. For each `a[j]` greater than that minimum, update the answer with `a[j] − min`. If no update happens, return -1. The difference must be **strictly positive**, because equal values do not count.

**Complexity:** `O(n)`.

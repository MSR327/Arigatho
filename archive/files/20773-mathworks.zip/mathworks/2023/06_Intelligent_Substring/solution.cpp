#include <bits/stdc++.h>
using namespace std;

int getSpecialSubstring(string s, int k, string charValue) {
    auto isNormal = [&](char c) { return charValue[c - 'a'] == '0'; };
    int best = 0, normals = 0;
    for (int l = 0, r = 0; r < (int)s.size(); ++r) {
        normals += isNormal(s[r]);
        while (normals > k) normals -= isNormal(s[l++]);
        best = max(best, r - l + 1);
    }
    return best;
}

int main() {
    string s, cv;
    int k;
    cin >> s >> k >> cv;
    cout << getSpecialSubstring(s, k, cv) << "\n";
    return 0;
}

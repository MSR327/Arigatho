# Intelligent Substring

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2023 (MathWorks OA, 3 Oct 2023) · **Source:** `m3/Mathworks/6 Intelligent Substring/IMG_20231003_191305/312.jpg`

## Problem

You are exploring a new language with two types of characters: **special** and **normal**. A character is special if its value is 1 and normal if its value is 0.

Given a string `s` and an integer `k`, determine the length of the longest possible substring that contains **at most `k` normal characters**. You are also given a 26-digit bit string `charValue`, where each position gives the special or normal nature (the value) of the corresponding letter of the English alphabet.

For example, let `s = "abcde"` and `k = 2`, with this `charValue`:

```
alphabet  = abcdefghijklmnopqrstuvwxyz
charValue = 10101111111111111111111111
```
The normal characters are `{b, d}`. Since `k` is 2 and only two normal characters appear in the string, every substring meets the criteria, so the longest substring is the whole string, with length **5**. If instead `k = 1`, the possible substrings include `['b', 'd', 'ab', 'bc', 'cd', 'de', 'abc', 'cde']`, and the longest ones have **3** characters.

## Function Description

```cpp
int getSpecialSubstring(string s, int k, string charValue);
```

**Parameters**
- `string s`: the input string
- `int k`: the maximum number of normal characters allowed in a substring
- `string charValue`: a string giving special or normal for each letter of the alphabet, `ascii[a-z]`

**Returns**
- `int`: the length of the longest substring of `s` with at most `k` normal characters

## Constraints

- `1 ≤ |s| ≤ 10^5`
- `1 ≤ k ≤ |s|`
- `|charValue| = 26`
- `charValue[i] ∈ {0, 1}`

## Input Format (custom testing)

```
s
k
charValue
```

## Approach

Use a **sliding window**. Extend `r` and count the normal characters in the window. While the count exceeds `k`, move `l` forward. Track the largest `r − l + 1`.

**Complexity:** `O(|s|)`.

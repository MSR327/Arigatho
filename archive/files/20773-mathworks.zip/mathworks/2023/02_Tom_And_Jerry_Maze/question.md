# Tom & Jerry in a Maze

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2023 (MathWorks OA) · **Source:** `m3/Mathworks/2. Tom and Jerry in a maze/1_1…1_4.jpeg`

## Problem

After decades of chasing Jerry, Tom wants to make peace. Jerry is sceptical and hides in an `n × n` maze. Tom decides the best way to make Jerry take him seriously is to collect **all of the cheese pieces** in the maze and give them to Jerry as a gift. A **move** is a single step from the current position to an adjacent position in the maze. Tom can move in all four directions within the maze: up, down, left and right.

Each cell in `maze` is labelled as follows:
- `0`: a path cell.
- `1`: a blocked cell (wall).
- `2`: a cheese cell. Tom can move through a cheese cell just as he would a regular path cell.

Tom starts at `(0, 0)`. Return the **minimum number of moves** it takes him to collect all the cheese and deliver it to Jerry at `(x, y)`. If that is not possible, return **-1**.

## Function Description

```cpp
int minMoves(vector<vector<int>> maze, int x, int y);
```

**Parameters**
- `int maze[n][n]`: the maze where Jerry is hiding
- `int x`: the row coordinate of Jerry's location
- `int y`: the column coordinate of Jerry's location

**Returns**
- `int`: the minimum number of moves Tom must make to collect all the cheese and reach Jerry, or `-1` if that is not possible

## Constraints

- `1 ≤ n ≤ 100`
- `0 ≤ number of cheese pieces ≤ 10`
- `0 ≤ x, y < n` (the coordinates are 0-based, as the sample shows)

## Input Format

```
n                 (number of rows)
n                 (number of columns)
n lines, each with n space-separated integers
x
y
```

## Sample Input 0

```
maze = {{0, 2, 0}, {0, 0, 1}, {1, 1, 1}}
x = 1
y = 1
```

## Sample Output 0

```
2
```

## Explanation 0

`(0,0) → (0,1)` picks up the cheese, then `(0,1) → (1,1)` reaches Jerry. That is 2 moves.

## Sample Input 1

```
maze = {{0, 1, 0}, {1, 0, 1}, {0, 2, 2}}
x = 1
y = 1
```

## Sample Output 1

```
-1
```
Tom can't leave `(0, 0)`, so he can't reach Jerry.

## Sample Input 2

```
maze = {{0, 2, 0}, {1, 1, 2}, {1, 0, 0}}
x = 2
y = 1
```

## Sample Output 2

```
5
```
The shortest path is `(0,0) → (0,1) → (0,2) → (1,2) → (2,2) → (2,1)`, which is 5 moves.

## Approach

Run a **BFS over the state (row, col, mask of collected cheese)**. There are at most `100·100·2^10 ≈ 10^7` states, which is fine with a compact visited array. Collecting the cheese at `(0,0)` (if there is any) counts as part of the start state. The answer is the BFS distance of the first state equal to `(x, y, fullMask)`.

An alternative is to BFS from each cheese, from the start and from Jerry, then run a TSP bitmask DP. That is faster when the grid is large and there are few cheeses.

**Complexity:** `O(n² · 2^K)`, where K is the number of cheese pieces.

#include <bits/stdc++.h>
using namespace std;

// BFS over (row, col, collected-cheese mask)
int minMoves(vector<vector<int>> maze, int x, int y) {
    int n = maze.size(), m = maze[0].size();
    if (maze[0][0] == 1 || maze[x][y] == 1) return -1;

    vector<vector<int>> id(n, vector<int>(m, -1));
    int k = 0;
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < m; ++j)
            if (maze[i][j] == 2) id[i][j] = k++;
    int full = (1 << k) - 1;

    auto enc = [&](int r, int c, int mask) { return ((long long)mask * n + r) * m + c; };
    vector<int> dist((size_t)n * m << k, -1);
    int startMask = id[0][0] >= 0 ? 1 << id[0][0] : 0;
    queue<long long> q;
    dist[enc(0, 0, startMask)] = 0;
    q.push(enc(0, 0, startMask));

    int dr[4] = {1, -1, 0, 0}, dc[4] = {0, 0, 1, -1};
    while (!q.empty()) {
        long long s = q.front();
        q.pop();
        int c = s % m, r = (s / m) % n, mask = s / ((long long)n * m);
        if (r == x && c == y && mask == full) return dist[s];
        for (int d = 0; d < 4; ++d) {
            int nr = r + dr[d], nc = c + dc[d];
            if (nr < 0 || nr >= n || nc < 0 || nc >= m || maze[nr][nc] == 1) continue;
            int nm = id[nr][nc] >= 0 ? mask | (1 << id[nr][nc]) : mask;
            long long t = enc(nr, nc, nm);
            if (dist[t] == -1) {
                dist[t] = dist[s] + 1;
                q.push(t);
            }
        }
    }
    return -1;
}

int main() {
    int n, m;
    cin >> n >> m;
    vector<vector<int>> maze(n, vector<int>(m));
    for (auto &row : maze)
        for (auto &v : row) cin >> v;
    int x, y;
    cin >> x >> y;
    cout << minMoves(maze, x, y) << "\n";
    return 0;
}

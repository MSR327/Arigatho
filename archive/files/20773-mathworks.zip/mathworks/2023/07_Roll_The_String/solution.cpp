#include <bits/stdc++.h>
using namespace std;

string rollTheString(string s, vector<int> roll) {
    int n = s.size();
    vector<long long> cnt(n + 1, 0);
    for (int r : roll) cnt[r - 1]++;
    long long shift = 0;
    for (int i = n - 1; i >= 0; --i) {
        shift += cnt[i];  // number of rolls covering position i
        s[i] = 'a' + (s[i] - 'a' + shift) % 26;
    }
    return s;
}

int main() {
    string s;
    int n;
    cin >> s >> n;
    vector<int> roll(n);
    for (auto &r : roll) cin >> r;
    cout << rollTheString(s, roll) << "\n";
    return 0;
}

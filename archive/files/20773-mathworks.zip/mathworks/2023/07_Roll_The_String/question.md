# Roll the String

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2023 (MathWorks OA) · **Source:** `m3/Mathworks/7 Roll The String/7_1.png, 7_2.png`

## Problem

A single **roll** operation on a string increments each character by one, circularly: each character is rolled forward and overwritten with the next letter of the alphabet. For characters in the range `ascii[a-z]`, `a` becomes `b`, `b` becomes `c`, and `z` becomes `a`.

You are given an array of integers named `roll`. For each element `i` of the array, perform a roll operation on the first `roll[i]` characters of `s`. The string is zero-indexed, so operation `roll[i]` affects the characters at positions `0` through `roll[i] − 1`.

For example, with `s = "abz"` and `roll = [3, 2, 1]`:
- `roll[0] = 3`: roll all three characters, so `abz` becomes `bca`.
- `roll[1] = 2`: roll the first two characters, so `bca` becomes `cda`.
- `roll[2] = 1`: roll the first character, so `cda` becomes `dda`.

After all the operations, the final value of `s` is **`dda`**.

## Function Description

```cpp
string rollTheString(string s, vector<int> roll);
```

**Parameters**
- `string s`: the string to operate on
- `int roll[n]`: the number of characters of `s` to roll in each operation

**Returns**
- `string`: the resulting string after all roll operations have been performed

## Constraints

- Each character in `s` is in the range `ascii[a-z]`.
- `1 ≤ |s| ≤ 10^5`
- `1 ≤ n ≤ 10^5`
- `1 ≤ roll[i] ≤ |s|`, where `0 ≤ i < n`.

## Sample Input 0

```
abz
1
3
```

## Sample Output 0

```
bca
```

## Explanation 0

There is a single operation, `roll = [3]`. It rolls every character in `s[0] … s[2]`, which is the whole string, so `abz` becomes `bca`.

## Input Format (custom testing)

```
s
n
roll[0] ... roll[n-1]
```

## Approach

Rolling the prefix `[0, r)` adds 1 to every position before `r`. Count how many operations cover each position using a **difference array / suffix count**: `cnt[r−1]++` for each operation, then take suffix sums, so position `i` is shifted by the number of rolls with `roll ≥ i+1`. The new character is `'a' + (s[i] − 'a' + shift) % 26`.

**Complexity:** `O(|s| + n)`.

#include <bits/stdc++.h>
using namespace std;

int longestChain(vector<string> words) {
    sort(words.begin(), words.end(), [](const string &a, const string &b) { return a.size() < b.size(); });
    unordered_map<string, int> dp;
    int best = 0;
    for (auto &w : words) {
        int cur = 1;
        for (size_t i = 0; i < w.size(); ++i) {
            string prev = w.substr(0, i) + w.substr(i + 1);
            auto it = dp.find(prev);
            if (it != dp.end()) cur = max(cur, it->second + 1);
        }
        dp[w] = max(dp[w], cur);
        best = max(best, cur);
    }
    return best;
}

int main() {
    int n;
    cin >> n;
    vector<string> words(n);
    for (auto &w : words) cin >> w;
    cout << longestChain(words) << "\n";
    return 0;
}

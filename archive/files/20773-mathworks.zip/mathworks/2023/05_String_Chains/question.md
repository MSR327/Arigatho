# String Chains

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2023 (MathWorks OA, 3 Oct 2023) · **Source:** `m3/Mathworks/5 String Chain/IMG_20231003_191234/45/53.jpg`

## Problem

You are given an array `words` of `n` word strings (`words[0], words[1], …, words[n−1]`). Choose a word from it and, in each step, remove a single letter from the chosen word **if and only if** doing so yields another word that is already in the library. Each successive character removal is performed on the result of the previous removal, and you cannot remove a character if the resulting string is not an element of `words`.

The **length of a string chain** is the maximum number of strings in a chain of successive character removals.

Return a single integer: the length of the longest possible string chain in `words`.

## Function Description

```cpp
int longestChain(vector<string> words);
```

**Parameters**
- `string words[n]`: the words

**Returns**
- `int`: the length of the longest chain of character removals possible

## Constraints

- `1 ≤ n ≤ 50000`
- `1 ≤ |words[i]| ≤ 60`
- Each string in `words` consists of lowercase ASCII letters.

## Input Format

The first line contains an integer `n`, the size of `words`. Each of the next `n` lines contains one string of `words`.

## Sample Input 1

```
6
a
b
ba
bca
bda
bdca
```

## Sample Output 1

```
4
```

## Explanation 1

- `"a"` and `"b"` are single-character words. Removing a character from them would give the empty string, which is not in `words`, so each of these chains has length 1.
- `"ba"` gives two chains of length 2: `"ba" → "a"` and `"ba" → "b"`.
- `"bca"` gives chains of length 3: `"bca" → "ba" → "a"` and `"bca" → "ba" → "b"`.
- `"bda"` likewise gives chains of length 3.
- `"bdca"` gives four chains of length 4, for example `"bdca" → "bda" → "ba" → "a"`.

The longest chain has length **4**.

## Approach

**Sort the words by length** and run a DP with a hash map:
```
dp[w] = 1 + max over i of dp[w with character i removed]   (only if that string is in the map)
```
Shorter words are processed first, so their values are ready when needed. The answer is the maximum `dp`.

**Complexity:** `O(n · L²)` with L ≤ 60 (L deletions, each building a string of length L).

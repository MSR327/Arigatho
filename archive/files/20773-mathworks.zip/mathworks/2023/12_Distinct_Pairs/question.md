# Distinct Pairs

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2023 (MathWorks OA) · **Source:** `m3/Mathworks/14 Distinct Pairs/Screenshot 2023-10-31 at 7.12.00 PM.png`

## Problem

You are given an array of integers and a target value. Determine the number of **distinct** pairs of elements in the array that sum to the target. Two pairs `(a, b)` and `(c, d)` are distinct if and only if their values, in sorted order, do not match. So `(1, 9)` and `(9, 1)` are the same pair, but `(1, 9)` and `(9, 2)` are distinct.

For example, given the array `[1, 2, 3, 6, 7, 8, 9, 1]` and a target of `10`, the seven pairs `(1,9), (2,8), (3,7), (8,2), (9,1), (9,1)` and `(1,9)` all sum to 10, but there are only three distinct pairs: `(1, 9)`, `(2, 8)` and `(3, 7)`.

## Function Description

```cpp
int numberOfPairs(vector<int> a, long k);
```

**Parameters**
- `int a[n]`: an array of integers
- `long k`: the target value

**Returns**
- `int`: the total number of distinct pairs of elements in the array that sum to the target

## Constraints (typical)

- `1 ≤ n ≤ 5·10^5`
- `0 ≤ a[i] ≤ 10^9`
- `0 ≤ k ≤ 5·10^9`

## Example

```
a = [1, 2, 3, 6, 7, 8, 9, 1], k = 10   → 3
a = [1, 3, 46, 1, 3, 9], k = 47          → 1   (1, 46)
a = [6, 6, 3, 9, 3, 5, 1], k = 12        → 2   (6, 6), (3, 9)
```

## Input Format (custom testing)

```
n
a[0] ... a[n-1]
k
```

## Approach

Count how many times each value occurs. For each distinct value `x` with `x ≤ k − x`:
- if `x < k − x` and `k − x` is present, count 1;
- if `x == k − x` and `x` occurs at least twice, count 1.

**Complexity:** `O(n)` expected.

#include <bits/stdc++.h>
using namespace std;

int numberOfPairs(vector<int> a, long long k) {
    unordered_map<long long, int> cnt;
    for (int x : a) cnt[x]++;
    int res = 0;
    for (auto &p : cnt) {
        long long x = p.first, y = k - x;
        if (x < y && cnt.count(y)) res++;
        else if (x == y && p.second >= 2) res++;
    }
    return res;
}

int main() {
    int n;
    cin >> n;
    vector<int> a(n);
    for (auto &v : a) cin >> v;
    long long k;
    cin >> k;
    cout << numberOfPairs(a, k) << "\n";
    return 0;
}

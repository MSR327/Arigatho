#include <bits/stdc++.h>
using namespace std;

vector<string> reducedFractionSums(vector<string> expressions) {
    vector<string> res;
    for (auto &e : expressions) {
        long long a, b, c, d;
        sscanf(e.c_str(), "%lld/%lld+%lld/%lld", &a, &b, &c, &d);
        long long num = a * d + c * b, den = b * d;
        long long g = __gcd(num, den);
        res.push_back(to_string(num / g) + "/" + to_string(den / g));
    }
    return res;
}

int main() {
    int n;
    cin >> n;
    vector<string> ex(n);
    for (auto &s : ex) cin >> s;
    for (auto &s : reducedFractionSums(ex)) cout << s << "\n";
    return 0;
}

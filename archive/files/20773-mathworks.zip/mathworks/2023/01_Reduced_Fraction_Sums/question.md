# Reduced Fraction Sums

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2023 (MathWorks OA) · **Source:** `m3/Mathworks/1. Reduced Fraction Sums/1_1…1_5.jpeg`

## Problem

Consider two fractions of the form `a/b` and `c/d`, where `a`, `b`, `c` and `d` are integers. You are given a string describing an arithmetic expression that adds these two fractions, in the format `a/b+c/d`. Compute the sum, **fully reduce** the resulting fraction `e/f`, and save the reduced fraction as a string in the form `e/f`.

- The expression `1/2+1/6` evaluates to `4/6`, which reduces to the string `2/3`.
- The expression `7/10+13/10` evaluates to `20/10`, which reduces to the string `2/1`.

## Function Description

```cpp
vector<string> reducedFractionSums(vector<string> expressions);
```

**Parameters**
- `string expressions[n]`: an array of arithmetic expressions in the form `a/b+c/d`

**Returns**
- `string[n]`: element `i` is the fully reduced form of the fraction produced by evaluating `expressions[i]`

## Constraints

- `1 ≤ n ≤ 500`
- `1 ≤ a, b, c, d ≤ 2000`

## Input Format

The first line contains an integer `n`, the number of strings in `expressions`. Each of the next `n` lines contains one string in the form `a/b+c/d`.

## Sample Input 0

```
5
722/148+360/176
978/1212+183/183
358/472+301/417
780/309+684/988
258/840+854/686
```

## Sample Output 0

```
2818/407
365/202
145679/98412
4307/1339
1521/980
```

## Explanation 0

0. `722/148+360/176` evaluates to the reduced fraction `2818/407`.
1. `978/1212+183/183` evaluates to `365/202`.
2. `358/472+301/417` evaluates to `145679/98412`.
3. `780/309+684/988` evaluates to `4307/1339`.
4. `258/840+854/686` evaluates to `1521/980`.

## Approach

Parse `a, b, c, d`. Then compute `num = a·d + c·b` and `den = b·d`, and divide both by `g = gcd(num, den)`. The values reach at most `2000·2000·2 = 8·10^6`, which fits in an int, but `long long` is used to be safe.

**Complexity:** `O(n · log(max))`.

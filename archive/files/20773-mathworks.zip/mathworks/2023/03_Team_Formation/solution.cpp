#include <bits/stdc++.h>
using namespace std;

long long teamFormation(vector<int> score, int team, int m) {
    int n = score.size();
    // (score, -index) so ties prefer the lower index
    priority_queue<pair<int, int>> left, right;
    int l = 0, r = n - 1;
    for (int i = 0; i < m && l <= r; ++i, ++l) left.push({score[l], -l});
    for (int i = 0; i < m && l <= r; ++i, --r) right.push({score[r], -r});

    long long sum = 0;
    while (team-- > 0 && (!left.empty() || !right.empty())) {
        bool takeLeft;
        if (right.empty()) takeLeft = true;
        else if (left.empty()) takeLeft = false;
        else takeLeft = left.top() >= right.top();

        if (takeLeft) {
            sum += left.top().first;
            left.pop();
            if (l <= r) left.push({score[l], -l}), ++l;
        } else {
            sum += right.top().first;
            right.pop();
            if (l <= r) right.push({score[r], -r}), --r;
        }
    }
    return sum;
}

int main() {
    int n;
    cin >> n;
    vector<int> s(n);
    for (auto &v : s) cin >> v;
    int team, m;
    cin >> team >> m;
    cout << teamFormation(s, team, m) << "\n";
    return 0;
}

# Team Formation

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2023 (MathWorks OA, 3 Oct 2023) · **Source:** `m3/Mathworks/3. Team Formation/3.jpeg`

## Problem

Hacker Industries has a number of employees. The company gives each employee a numeric evaluation `score` and keeps these scores in a list. A manager is putting together a team for a new project by selecting employees from the list as follows:

1. In each selection, the manager picks the employee with the **highest score** among either the **first `m`** available employees or the **last `m`** available employees in the list. The selected employee is removed from the list and added to the team.
2. If several employees share that highest score among the first or last `m` available employees, the manager picks the one with the **lowest index** in the list of scores.
3. If fewer than `m` employees are available, the manager picks the employee with the highest score among all available employees.

The function must return the **sum of the scores** of all members selected for the team.

## Function Description

```cpp
long teamFormation(vector<int> score, int team, int m);
```

**Parameters**
- `int score[n]`: the score of each employee
- `int team`: the number of team members required
- `int m`: the size of the segments to select from

**Returns**
- `long`: the sum of the scores of the selected team members

## Constraints (typical)

- `1 ≤ n ≤ 10^5`
- `1 ≤ score[i] ≤ 10^9`
- `1 ≤ team ≤ n`, `1 ≤ m ≤ n`

## Example (illustrative: the photo doesn't show the official sample)

```
score = [17, 12, 10, 2, 7, 2, 11, 20, 8], team = 3, m = 4
```
- The first 4 are `[17,12,10,2]` and the last 4 are `[2,11,20,8]`. The best is **20**, so it is removed.
- The first 4 are `[17,12,10,2]` and the last 4 are `[7,2,11,8]`. The best is **17**, so it is removed.
- The first 4 are `[12,10,2,7]` and the last 4 are `[7,2,11,8]`. The best is **12**.

The sum is 20 + 17 + 12 = **49**.

## Input Format (custom testing)

```
n
score[0] ... score[n-1]
team
m
```

## Approach

Use **two max-heaps** with two pointers. The left heap holds the first `m` elements and the right heap holds the last `m` elements, with no overlap: pointers `l` and `r` mark the next unused element on each side. In each round, take the heap whose top is larger. On a tie, take the **left** heap, because its index is lower. Then refill that heap from its pointer if `l ≤ r`.

To break ties correctly *within* a heap, store pairs `(score, -index)`.

**Complexity:** `O((m + team) log m)`.

# Simple Queries

**Tag:** `HackerRank`. The source screenshot shows the HackerRank test page.

**Year:** 2023 (MathWorks OA) · **Source:** `m3/Mathworks/9  Simple Queries/*.png`

## Problem

You are given two arrays of positive integers. For each element in the second array, find the total number of elements in the first array that are **less than or equal to** that element. Store these counts in an array.

For example, if the first array is `[1, 2, 3]` and the second array is `[2, 4]`, then 2 elements of the first array are ≤ 2 and 3 elements are ≤ 4. The answer is `[2, 3]`.

## Function Description

```cpp
vector<int> counts(vector<int> nums, vector<int> maxes);
```

**Parameters**
- `int nums[n]`: the first array of positive integers
- `int maxes[m]`: the second array of positive integers

**Returns**
- `int[m]`: for each `maxes[i]`, the number of elements `nums[j]` with `nums[j] ≤ maxes[i]`, in the given order

## Constraints

- `2 ≤ n, m ≤ 10^5`
- `1 ≤ nums[j] ≤ 10^9`
- `1 ≤ maxes[i] ≤ 10^9`

## Sample Input 0

```
4
1
4
2
4
2
3
5
```
(`nums = [1, 4, 2, 4]`, `maxes = [3, 5]`)

## Sample Output 0

```
2
4
```

## Explanation 0

- `maxes[0] = 3`: `nums[0] = 1` and `nums[2] = 2` are ≤ 3, so the count is 2.
- `maxes[1] = 5`: all four elements are ≤ 5, so the count is 4.

## Input Format (custom testing)

```
n
nums[0] ... nums[n-1]
m
maxes[0] ... maxes[m-1]
```

## Approach

Sort `nums`. For each query, `upper_bound(nums, maxes[i])` gives the count.

**Complexity:** `O((n + m) log n)`.

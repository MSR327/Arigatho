#include <bits/stdc++.h>
using namespace std;

vector<int> counts(vector<int> nums, vector<int> maxes) {
    sort(nums.begin(), nums.end());
    vector<int> res;
    for (int q : maxes) res.push_back(upper_bound(nums.begin(), nums.end(), q) - nums.begin());
    return res;
}

int main() {
    int n, m;
    cin >> n;
    vector<int> nums(n);
    for (auto &v : nums) cin >> v;
    cin >> m;
    vector<int> maxes(m);
    for (auto &v : maxes) cin >> v;
    for (int v : counts(nums, maxes)) cout << v << "\n";
    return 0;
}
